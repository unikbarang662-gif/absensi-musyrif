import express from "express";
import fs from "fs/promises";
import path from "path";
import { createServer as createViteServer } from "vite";

const STATE_FILE = path.join(process.cwd(), "app_state.json");

async function initDb() {
  try {
    try {
      await fs.access(STATE_FILE);
    } catch {
      await fs.writeFile(STATE_FILE, JSON.stringify({})); // empty initially
    }
  } catch (err) {
    console.error("DB Init Error:", err);
  }
}

async function startServer() {
  await initDb();
  
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "50mb" }));

  // API endpoints
  app.get("/api/state", async (req, res) => {
    try {
      const data = await fs.readFile(STATE_FILE, "utf-8");
      res.json(JSON.parse(data || "{}"));
    } catch (err) {
      res.status(500).json({ error: "Failed to read state" });
    }
  });

  app.post("/api/state", async (req, res) => {
    try {
      await fs.writeFile(STATE_FILE, JSON.stringify(req.body));
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: "Failed to save state" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
