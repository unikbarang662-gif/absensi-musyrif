import re

with open('src/components/MusyrifDashboard.tsx', 'r') as f:
    content = f.read()

option_pattern = r'<option key=\{s\.id\} value=\{`\$\{s\.title\} ⏰ \$\{s\.time\}`\}>'
option_replacement = """<option key={s.id} value={s.title}>"""

content = re.sub(option_pattern, option_replacement, content, flags=re.DOTALL)

# And now we don't need to split by ⏰ in riwayat
# wait, old data might still have ⏰. So we should do item.kegiatan.replace(/ ⏰ .*/, '') + the suffix if it's there.
# actually if we change submit to just append, old data might be weird. But for now we just change rendering.

rendering_pattern = r'\{item\.kegiatan\.split\(\' ⏰ \'\)\[0\]\}'
rendering_replacement = """{item.kegiatan.replace(/ ⏰ [0-9:-]+/, '')}"""

content = re.sub(rendering_pattern, rendering_replacement, content, flags=re.DOTALL)

with open('src/components/MusyrifDashboard.tsx', 'w') as f:
    f.write(content)
