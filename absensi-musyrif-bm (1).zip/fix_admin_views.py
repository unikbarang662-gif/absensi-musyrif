import re

with open('src/components/AdminDashboard.tsx', 'r') as f:
    content = f.read()

santri_view_pattern = r'\{\/\* DATA SANTRI VIEW \*\/\}.*?\{\/\* DATA KEGIATAN VIEW \*\/\}'
match = re.search(santri_view_pattern, content, re.DOTALL)
if not match:
    print("Could not find santri view")
    exit(1)

old_santri_view = match.group(0)

# Create new santri view
new_santri_view = old_santri_view.replace(
    "santris.filter(s => s.status && s.status !== 'Reguler').length > 0 ?",
    "santris.length > 0 ?"
).replace(
    "santris.filter(s => s.status && s.status !== 'Reguler').map((santri, idx) => (",
    "santris.map((santri, idx) => ("
).replace(
    "Belum ada data santri yatim/piatu",
    "Belum ada data santri"
)

# Create yatim view
yatim_view = old_santri_view.replace(
    "{/* DATA SANTRI VIEW */}",
    "{/* DATA YATIM VIEW */}"
).replace(
    "expandedZone === 'santri'",
    "expandedZone === 'yatim'"
).replace(
    "✨</span> Data Santri",
    "✨</span> Data Santri Yatim/Piatu"
).replace(
    "Manajemen data santri lengkap",
    "Manajemen data santri yatim/piatu"
).replace(
    "{/* DATA KEGIATAN VIEW */}",
    ""
)

# Create musyrif view
musyrif_view = """            {/* DATA MUSYRIF VIEW */}
            {expandedZone === 'musyrifs' && (
              <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
                <div className="p-6 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <h2 className="text-xl font-bold text-[#0B4A3F] flex items-center gap-2">
                      <Users className="w-5 h-5" /> Data Kamar & Musyrif Kamar
                    </h2>
                    <p className="text-slate-500 text-sm mt-1">Kelola data musyrif dan kamar</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <button onClick={() => setShowMusyrifModal(true)} className="bg-[#4F46E5] text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-indigo-600 transition flex items-center gap-2">
                      <PlusCircle className="w-4 h-4" /> Tambah Musyrif
                    </button>
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm border-collapse">
                    <thead>
                      <tr className="bg-white border-b border-slate-100 text-slate-700 font-bold uppercase tracking-wide text-xs">
                        <th className="py-4 px-6 text-center w-16">NO</th>
                        <th className="py-4 px-6">NAMA LENGKAP</th>
                        <th className="py-4 px-6">ASRAMA</th>
                        <th className="py-4 px-6">KAMAR</th>
                        <th className="py-4 px-6 text-center">STATUS</th>
                        <th className="py-4 px-6 text-center">AKSI</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50">
                      {musyrifs.length > 0 ? (
                        musyrifs.map((item, idx) => (
                          <tr key={item.id} className="hover:bg-slate-50 transition">
                            <td className="py-4 px-6 text-center text-slate-500 font-medium">{idx + 1}</td>
                            <td className="py-4 px-6 font-bold text-[#0B4A3F]">{item.name}</td>
                            <td className="py-4 px-6 text-slate-600">{item.asrama}</td>
                            <td className="py-4 px-6 text-slate-600 font-bold">{item.kamar}</td>
                            <td className="py-4 px-6 text-center">
                              <span className={`px-2 py-1 rounded text-xs font-bold ${item.isActive ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}`}>
                                {item.isActive ? 'Aktif' : 'Nonaktif'}
                              </span>
                            </td>
                            <td className="py-4 px-6">
                              <div className="flex justify-center gap-2">
                                <button onClick={() => updateMusyrif(item.id, { isActive: !item.isActive })} className="p-1.5 text-emerald-600 hover:bg-emerald-50 rounded-lg transition" title="Toggle Status">
                                  {item.isActive ? <ToggleRight className="w-4 h-4" /> : <ToggleLeft className="w-4 h-4" />}
                                </button>
                                <button onClick={() => setEditingMusyrif(item)} className="p-1.5 text-blue-500 hover:bg-blue-50 rounded-lg transition" title="Edit Data">
                                  <Edit className="w-4 h-4" />
                                </button>
                                <button onClick={() => {
                                  if (window.confirm('Hapus musyrif ini?')) {
                                    deleteMusyrif(item.id);
                                  }
                                }} className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition" title="Hapus Data">
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={6} className="py-10 text-center text-slate-500 font-medium">Belum ada data musyrif</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
"""

final_replacement = musyrif_view + yatim_view + new_santri_view

content = content.replace(old_santri_view, final_replacement)

with open('src/components/AdminDashboard.tsx', 'w') as f:
    f.write(content)

print("Replaced successfully!")
