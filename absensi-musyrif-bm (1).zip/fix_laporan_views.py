import re

with open('src/components/AdminDashboard.tsx', 'r') as f:
    content = f.read()

# We need to find where to insert these views.
# Let's insert them right after `expandedZone === 'laporan'`

laporan_pattern = r'\{\/\* LAPORAN ABSENSI VIEW \*\/\}.*?\{\/\* WHATSAPP REMINDER VIEW \*\/\}'

match = re.search(laporan_pattern, content, re.DOTALL)
if not match:
    print("Could not find LAPORAN ABSENSI VIEW")
    exit(1)

# Currently, the Laporan Absensi View is rendering SCHEDULES instead of Santris!
# Let's write proper views.

proper_views = """            {/* LAPORAN ABSENSI VIEW */}
            {expandedZone === 'laporan' && (
              <div className="space-y-6">
                <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
                  <div className="p-6 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <h2 className="text-xl font-bold text-[#0B4A3F]">Laporan Rekapitulasi Santri</h2>
                      <p className="text-slate-500 text-sm mt-1">Rekapitulasi kehadiran dan kedisiplinan santri</p>
                    </div>
                  </div>
                  <div className="overflow-x-auto relative p-6">
                    <table className="w-full text-left text-sm border-collapse">
                      <thead>
                        <tr className="text-slate-500 font-bold uppercase tracking-wide text-[11px]">
                          <th className="pb-4 border-b border-slate-100">NO</th>
                          <th className="pb-4 border-b border-slate-100">NAMA SANTRI</th>
                          <th className="pb-4 border-b border-slate-100">KAMAR</th>
                          <th className="pb-4 border-b border-slate-100">TOTAL HADIR</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-50">
                        {santris.length > 0 ? santris.map((santri, idx) => {
                          const mutholaahCount = absensiMutholaahList.filter(r => r.santriId === santri.id && r.status.includes('Hadir')).length;
                          const tidurCount = absensiTidurList.filter(r => r.santriId === santri.id && r.status.includes('Hadir')).length;
                          const total = mutholaahCount + tidurCount;
                          return (
                            <tr key={santri.id} className="hover:bg-slate-50">
                              <td className="py-4 px-6 text-center font-bold text-slate-600">{idx + 1}</td>
                              <td className="py-4 px-6 font-bold text-[#0B4A3F]">{santri.name}</td>
                              <td className="py-4 px-6 font-bold text-slate-700">{santri.asrama} - {santri.kamar}</td>
                              <td className="py-4 px-6 font-bold text-emerald-600">{total} Kali</td>
                            </tr>
                          );
                        }) : (
                          <tr><td colSpan={4} className="py-10 text-center">Belum ada data</td></tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}
            
            {/* ABSENSI KEGIATAN MUSYRIF VIEW */}
            {expandedZone === 'kegiatan_musyrif' && (
              <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
                <div className="p-6 border-b border-slate-100">
                  <h2 className="text-xl font-bold text-[#0B4A3F]">Absensi Kegiatan Musyrif</h2>
                  <p className="text-slate-500 text-sm mt-1">Daftar laporan absensi yang disubmit oleh musyrif/mulahid</p>
                </div>
                <div className="overflow-x-auto p-6">
                  <table className="w-full text-left text-sm border-collapse">
                    <thead>
                      <tr className="text-slate-500 font-bold uppercase tracking-wide text-[11px]">
                        <th className="pb-4 border-b border-slate-100">TANGGAL</th>
                        <th className="pb-4 border-b border-slate-100">MUSYRIF</th>
                        <th className="pb-4 border-b border-slate-100">KEGIATAN</th>
                        <th className="pb-4 border-b border-slate-100">STATUS</th>
                        <th className="pb-4 border-b border-slate-100">AKSI</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50">
                      {absensiList.length > 0 ? absensiList.map(r => (
                        <tr key={r.id}>
                          <td className="py-4 px-6 font-bold text-slate-700">{r.tanggal} {r.waktu}</td>
                          <td className="py-4 px-6 font-bold text-[#0B4A3F]">{r.namaMusyrif} ({r.asrama})</td>
                          <td className="py-4 px-6 text-slate-600">{r.kegiatan}</td>
                          <td className="py-4 px-6">
                            <span className={`px-2 py-1 rounded text-xs font-bold ${r.status === 'Hadir' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}`}>
                              {r.status}
                            </span>
                          </td>
                          <td className="py-4 px-6">
                            <button onClick={() => {
                                  if (window.confirm('Hapus laporan ini?')) {
                                    deleteAbsensi(r.id);
                                  }
                                }} className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition" title="Hapus">
                                  <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      )) : (
                        <tr><td colSpan={5} className="py-10 text-center">Belum ada laporan</td></tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
            
            {/* ABSENSI MUTHOLAAH VIEW */}
            {expandedZone === 'mutholaah' && (
              <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
                <div className="p-6 border-b border-slate-100">
                  <h2 className="text-xl font-bold text-[#0B4A3F]">Absensi Muthola'ah Santri</h2>
                  <p className="text-slate-500 text-sm mt-1">Daftar laporan kehadiran santri saat kegiatan muthola'ah</p>
                </div>
                <div className="overflow-x-auto p-6">
                  <table className="w-full text-left text-sm border-collapse">
                    <thead>
                      <tr className="text-slate-500 font-bold uppercase tracking-wide text-[11px]">
                        <th className="pb-4 border-b border-slate-100">TANGGAL</th>
                        <th className="pb-4 border-b border-slate-100">SANTRI</th>
                        <th className="pb-4 border-b border-slate-100">KAMAR</th>
                        <th className="pb-4 border-b border-slate-100">STATUS</th>
                        <th className="pb-4 border-b border-slate-100">AKSI</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50">
                      {absensiMutholaahList.length > 0 ? absensiMutholaahList.map(r => (
                        <tr key={r.id}>
                          <td className="py-4 px-6 font-bold text-slate-700">{r.tanggal} {r.waktu}</td>
                          <td className="py-4 px-6 font-bold text-[#0B4A3F]">{r.santriName}</td>
                          <td className="py-4 px-6 text-slate-600">{r.asrama} - {r.kamar}</td>
                          <td className="py-4 px-6">
                            <span className="px-2 py-1 rounded text-xs font-bold bg-slate-100 text-slate-700">
                              {r.status}
                            </span>
                          </td>
                          <td className="py-4 px-6">
                            <button onClick={() => {
                                  if (window.confirm('Hapus absensi ini?')) {
                                    deleteAbsensiMutholaah(r.id);
                                  }
                                }} className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition" title="Hapus">
                                  <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      )) : (
                        <tr><td colSpan={5} className="py-10 text-center">Belum ada absensi muthola'ah</td></tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
            
            {/* ABSENSI TIDUR VIEW */}
            {expandedZone === 'tidur' && (
              <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
                <div className="p-6 border-b border-slate-100">
                  <h2 className="text-xl font-bold text-[#0B4A3F]">Absensi Tidur Malam Santri</h2>
                  <p className="text-slate-500 text-sm mt-1">Daftar laporan kehadiran santri saat jam tidur malam</p>
                </div>
                <div className="overflow-x-auto p-6">
                  <table className="w-full text-left text-sm border-collapse">
                    <thead>
                      <tr className="text-slate-500 font-bold uppercase tracking-wide text-[11px]">
                        <th className="pb-4 border-b border-slate-100">TANGGAL</th>
                        <th className="pb-4 border-b border-slate-100">SANTRI</th>
                        <th className="pb-4 border-b border-slate-100">KAMAR</th>
                        <th className="pb-4 border-b border-slate-100">STATUS</th>
                        <th className="pb-4 border-b border-slate-100">AKSI</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50">
                      {absensiTidurList.length > 0 ? absensiTidurList.map(r => (
                        <tr key={r.id}>
                          <td className="py-4 px-6 font-bold text-slate-700">{r.tanggal} {r.waktu}</td>
                          <td className="py-4 px-6 font-bold text-[#0B4A3F]">{r.santriName}</td>
                          <td className="py-4 px-6 text-slate-600">{r.asrama} - {r.kamar}</td>
                          <td className="py-4 px-6">
                            <span className="px-2 py-1 rounded text-xs font-bold bg-slate-100 text-slate-700">
                              {r.status}
                            </span>
                          </td>
                          <td className="py-4 px-6">
                            <button onClick={() => {
                                  if (window.confirm('Hapus absensi ini?')) {
                                    deleteAbsensiTidur(r.id);
                                  }
                                }} className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition" title="Hapus">
                                  <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      )) : (
                        <tr><td colSpan={5} className="py-10 text-center">Belum ada absensi tidur malam</td></tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
            
            {/* WHATSAPP REMINDER VIEW */}"""

content = content.replace(match.group(0), proper_views)

with open('src/components/AdminDashboard.tsx', 'w') as f:
    f.write(content)
print("Replaced Laporan, Mutholaah, Tidur, Kegiatan Musyrif views successfully!")
