import re

with open('src/components/MusyrifDashboard.tsx', 'r') as f:
    content = f.read()

reports_pattern = r'const displayedReports = absensiList\.filter\(\(r\) => \{.*?return true; \/\/ semua asrama \/ semua pondok\s*\}\);'

reports_replacement = """const displayedReports = absensiList.filter((r) => {
    let passHistory = true;
    if (historyFilter === 'saya') {
      passHistory = r.musyrifId === currentUser.id;
    } else if (historyFilter === 'asrama') {
      passHistory = r.asrama === activeAsrama;
    }
    
    if (!passHistory) return false;
    
    if (jenisFilter === 'musyrif') {
      return r.kegiatan.includes('(Absen Musyrif)');
    } else if (jenisFilter === 'mulahid') {
      return r.kegiatan.includes('(Absen Mulahid)');
    }
    return true;
  });"""

content = re.sub(reports_pattern, reports_replacement, content, flags=re.DOTALL)

with open('src/components/MusyrifDashboard.tsx', 'w') as f:
    f.write(content)
