import re

with open('src/components/MusyrifDashboard.tsx', 'r') as f:
    content = f.read()

radio_pattern = r'<label className="flex items-center gap-2 cursor-pointer">\s*<input type="radio" name="jenis_absensi" value="musyrif" className="text-\[#0B4A3F\] focus:ring-\[#0B4A3F\] w-4 h-4" defaultChecked \/>\s*<span className="text-sm font-bold text-slate-700">Absen Musyrif<\/span>\s*<\/label>\s*<label className="flex items-center gap-2 cursor-pointer">\s*<input type="radio" name="jenis_absensi" value="mulahid" className="text-\[#0B4A3F\] focus:ring-\[#0B4A3F\] w-4 h-4" \/>\s*<span className="text-sm font-bold text-slate-700">Absen Mulahid<\/span>\s*<\/label>'

radio_replacement = """<label className="flex items-center gap-2 cursor-pointer">
                    <input type="radio" name="jenis_absensi" value="musyrif" checked={jenisAbsensi === 'musyrif'} onChange={(e) => setJenisAbsensi('musyrif')} className="text-[#0B4A3F] focus:ring-[#0B4A3F] w-4 h-4 accent-[#0B4A3F]" />
                    <span className="text-sm font-bold text-slate-700">Absen Musyrif</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="radio" name="jenis_absensi" value="mulahid" checked={jenisAbsensi === 'mulahid'} onChange={(e) => setJenisAbsensi('mulahid')} className="text-[#0B4A3F] focus:ring-[#0B4A3F] w-4 h-4 accent-[#0B4A3F]" />
                    <span className="text-sm font-bold text-slate-700">Absen Mulahid</span>
                  </label>"""

content = re.sub(radio_pattern, radio_replacement, content, flags=re.DOTALL)

with open('src/components/MusyrifDashboard.tsx', 'w') as f:
    f.write(content)
