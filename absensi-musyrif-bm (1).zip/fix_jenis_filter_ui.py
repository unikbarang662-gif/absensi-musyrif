import re

with open('src/components/MusyrifDashboard.tsx', 'r') as f:
    content = f.read()

filter_ui_pattern = r'\{\/\* Sub Filter: Semua, Musyrif, Mulahid \*\/\}\s*<div className="flex gap-2">\s*<div className="bg-slate-50 rounded-xl p-1 flex items-center border border-slate-100">\s*<button className="px-4 py-1\.5 bg-\[#8b5cf6\] text-white rounded-lg text-xs font-bold shadow-sm">Semua<\/button>\s*<button className="px-4 py-1\.5 text-slate-500 hover:text-slate-700 rounded-lg text-xs font-bold">Musyrif<\/button>\s*<button className="px-4 py-1\.5 text-slate-500 hover:text-slate-700 rounded-lg text-xs font-bold">Mulahid<\/button>\s*<\/div>\s*<\/div>'

filter_ui_replacement = """{/* Sub Filter: Semua, Musyrif, Mulahid */}
            <div className="flex gap-2">
               <div className="bg-slate-50 rounded-xl p-1 flex items-center border border-slate-100">
                 <button onClick={() => setJenisFilter('semua')} className={`px-4 py-1.5 rounded-lg text-xs font-bold transition ${jenisFilter === 'semua' ? 'bg-[#8b5cf6] text-white shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>Semua</button>
                 <button onClick={() => setJenisFilter('musyrif')} className={`px-4 py-1.5 rounded-lg text-xs font-bold transition ${jenisFilter === 'musyrif' ? 'bg-white shadow-sm text-slate-700 border border-slate-200' : 'text-slate-500 hover:text-slate-700'}`}>Musyrif</button>
                 <button onClick={() => setJenisFilter('mulahid')} className={`px-4 py-1.5 rounded-lg text-xs font-bold transition ${jenisFilter === 'mulahid' ? 'bg-white shadow-sm text-slate-700 border border-slate-200' : 'text-slate-500 hover:text-slate-700'}`}>Mulahid</button>
               </div>
            </div>"""

content = re.sub(filter_ui_pattern, filter_ui_replacement, content, flags=re.DOTALL)

with open('src/components/MusyrifDashboard.tsx', 'w') as f:
    f.write(content)
