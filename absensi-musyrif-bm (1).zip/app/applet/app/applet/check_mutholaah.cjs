const fs = require('fs');
const content = fs.readFileSync('src/components/MusyrifDashboard.tsx', 'utf8');
const lines = content.split('\n');
let depth = 0;
for (let i = 1088; i < 1627; i++) {
  const line = lines[i];
  const opens = (line.match(/<div(?![^>]*\/>)/g) || []).length;
  const closes = (line.match(/<\/div>/g) || []).length;
  depth += opens - closes;
  if (opens > 0 || closes > 0) {
    console.log(`${i + 1}: depth=${depth} (line=${line.trim()})`);
  }
}
