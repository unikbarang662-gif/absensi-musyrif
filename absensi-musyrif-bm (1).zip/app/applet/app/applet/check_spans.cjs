const fs = require('fs');
const content = fs.readFileSync('src/components/MusyrifDashboard.tsx', 'utf8');
const lines = content.split('\n');
let depth = 0;
lines.forEach((line, i) => {
  const opens = (line.match(/<span/g) || []).length;
  const closes = (line.match(/<\/span>/g) || []).length;
  depth += opens - closes;
  if (opens > 0 || closes > 0) {
    console.log(`${i + 1}: depth=${depth} (line=${line.trim()})`);
  }
});
