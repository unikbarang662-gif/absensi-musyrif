const fs = require('fs');
const content = fs.readFileSync('src/components/MusyrifDashboard.tsx', 'utf8');

let opens = 0;
let pos = 0;
while ((pos = content.indexOf('<div', pos)) !== -1) {
  const endOfTag = content.indexOf('>', pos);
  if (endOfTag !== -1) {
    const tagContent = content.substring(pos, endOfTag + 1);
    if (!tagContent.endsWith('/>')) {
      opens++;
    }
  }
  pos += 4;
}

const closes = (content.match(/<\/div>/g) || []).length;
console.log('Total Opens (non-self-closing):', opens);
console.log('Total Closes:', closes);
console.log('Difference:', opens - closes);
