const fs = require('fs');
const content = fs.readFileSync('src/components/MusyrifDashboard.tsx', 'utf8');

const stack = [];
let pos = 0;

function getLine(p) {
  return content.substring(0, p).split('\n').length;
}

while (pos < content.length) {
  const openIdx = content.indexOf('<div', pos);
  const closeIdx = content.indexOf('</div>', pos);
  
  if (openIdx !== -1 && (closeIdx === -1 || openIdx < closeIdx)) {
    const endOfTag = content.indexOf('>', openIdx);
    if (endOfTag !== -1) {
      const tagContent = content.substring(openIdx, endOfTag + 1);
      if (!tagContent.endsWith('/>')) {
        stack.push({ line: getLine(openIdx), content: tagContent.substring(0, 50) });
      }
    }
    pos = openIdx + 4;
  } else if (closeIdx !== -1) {
    if (stack.length > 0) {
      stack.pop();
    } else {
      console.log(`EXTRA CLOSE at line ${getLine(closeIdx)}`);
    }
    pos = closeIdx + 6;
  } else {
    break;
  }
}

console.log('Unclosed tags:');
stack.forEach(s => console.log(`Line ${s.line}: ${s.content}`));
