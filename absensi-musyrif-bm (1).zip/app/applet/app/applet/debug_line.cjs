const fs = require('fs');
const content = fs.readFileSync('src/components/MusyrifDashboard.tsx', 'utf8');
const lines = content.split('\n');
const line = lines[1656]; // line 1657
console.log('Line 1657:', line.trim());
console.log('Opens:', (line.match(/<div/g) || []).length);
console.log('SelfClosings:', (line.match(/<div[^>]*\/>/g) || []).length);
console.log('Closes:', (line.match(/<\/div>/g) || []).length);
