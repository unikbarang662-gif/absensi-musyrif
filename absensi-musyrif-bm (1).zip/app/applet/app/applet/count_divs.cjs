const fs = require('fs');
const content = fs.readFileSync('src/components/MusyrifDashboard.tsx', 'utf8');
const opens = (content.match(/<div(?![^>]*\/>)/g) || []).length;
const closes = (content.match(/<\/div>/g) || []).length;
console.log('Total Opens (non-self-closing):', opens);
console.log('Total Closes:', closes);
console.log('Difference:', opens - closes);
