const fs = require('fs');
const content = fs.readFileSync('src/components/MusyrifDashboard.tsx', 'utf8');

let depth = 0;
let pos = 0;
let lastLineIdx = 0;
const lines = content.split('\n');

while (pos < content.length) {
  const openIdx = content.indexOf('<div', pos);
  const closeIdx = content.indexOf('</div>', pos);
  
  if (openIdx !== -1 && (closeIdx === -1 || openIdx < closeIdx)) {
    const endOfTag = content.indexOf('>', openIdx);
    if (endOfTag !== -1) {
      const tagContent = content.substring(openIdx, endOfTag + 1);
      if (!tagContent.endsWith('/>')) {
        depth++;
        const lineNum = content.substring(0, openIdx).split('\n').length;
        console.log(`${lineNum}: depth=${depth} (OPEN: ${tagContent.substring(0, 40)}...)`);
      }
    }
    pos = openIdx + 4;
  } else if (closeIdx !== -1) {
    depth--;
    const lineNum = content.substring(0, closeIdx).split('\n').length;
    console.log(`${lineNum}: depth=${depth} (CLOSE)`);
    pos = closeIdx + 6;
  } else {
    break;
  }
}
