import re

with open('src/components/AdminDashboard.tsx', 'r') as f:
    content = f.read()

# First we inject the kamarStats useMemo near other states, but maybe we can just calculate it inline to avoid breaking hooks order
# Wait, inline calculation in render is fine if it's not too heavy.

kamar_stats_code = """
  // Compute kamar stats dynamically
  const kamarStats = React.useMemo(() => {
    const stats: Record<string, { asrama: string, kamar: string, kapasitas: number, terisi: number, musyrifs: any[] }> = {};
    
    santris.forEach(s => {
        const key = `${s.asrama}-${s.kamar}`;
        if (!stats[key]) stats[key] = { asrama: s.asrama, kamar: s.kamar, kapasitas: 30, terisi: 0, musyrifs: [] };
        stats[key].terisi += 1;
    });

    musyrifs.forEach(m => {
        const key = `${m.asrama}-${m.kamar}`;
        if (!stats[key]) stats[key] = { asrama: m.asrama, kamar: m.kamar, kapasitas: 30, terisi: 0, musyrifs: [] };
        stats[key].musyrifs.push(m);
    });

    return Object.values(stats).sort((a, b) => a.asrama.localeCompare(b.asrama) || a.kamar.localeCompare(b.kamar));
  }, [santris, musyrifs]);
"""

# Instead of injecting hooks, let's just compute it inline in the view to avoid React hooks errors if we inject it wrong

new_musyrif_view = """            {/* DATA MUSYRIF VIEW */}
            {expandedZone === 'musyrifs' && (() => {
              const stats: Record<string, { asrama: string, kamar: string, kapasitas: number, terisi: number, musyrifs: any[] }> = {};
              santris.forEach(s => {
                  const key = `${s.asrama}-${s.kamar}`;
                  if (!stats[key]) stats[key] = { asrama: s.asrama, kamar: s.kamar, kapasitas: 30, terisi: 0, musyrifs: [] };
                  stats[key].terisi += 1;
              });
              musyrifs.forEach(m => {
                  const key = `${m.asrama}-${m.kamar}`;
                  if (!stats[key]) stats[key] = { asrama: m.asrama, kamar: m.kamar, kapasitas: 30, terisi: 0, musyrifs: [] };
                  stats[key].musyrifs.push(m);
              });
              const kamarList = Object.values(stats).sort((a, b) => a.asrama.localeCompare(b.asrama) || a.kamar.localeCompare(b.kamar));
              
              return (
              <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
                <div className="p-6 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <h2 className="text-xl font-bold text-[#0B4A3F] flex items-center gap-2">
                      <span className="text-emerald-500">✨</span> Data Kamar & Musyrif Kamar
                    </h2>
                    <p className="text-slate-500 text-sm mt-1">Manajemen data asrama dan kamar</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                      <input type="text" placeholder="Cari data..." className="w-64 bg-white border border-slate-200 rounded-lg py-2 pl-9 pr-3 text-sm focus:outline-none focus:border-blue-500" />
                    </div>
                    <button onClick={() => { setShowMusyrifModal(true); setAddMusyrifMode('single'); }} className="bg-[#4F46E5] text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-indigo-600 transition flex items-center gap-2">
                      <PlusCircle className="w-4 h-4" /> Tambah
                    </button>
                    <button onClick={() => { setShowMusyrifModal(true); setAddMusyrifMode('bulk'); }} className="bg-[#10B981] text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-emerald-600 transition flex items-center gap-2">
                      <span className="text-sm">↑</span> Tambah Masal
                    </button>
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm border-collapse">
                    <thead>
                      <tr className="bg-white border-b border-slate-100 text-slate-700 font-bold uppercase tracking-wide text-xs">
                        <th className="py-4 px-6 text-center w-16">NO</th>
                        <th className="py-4 px-6">NAMA ASRAMA</th>
                        <th className="py-4 px-6">NAMA KAMAR</th>
                        <th className="py-4 px-6">KAPASITAS</th>
                        <th className="py-4 px-6">TERISI</th>
                        <th className="py-4 px-6">MUSYRIF KAMAR</th>
                        <th className="py-4 px-6">MULAHID</th>
                        <th className="py-4 px-6 text-center">AKSI</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50">
                      {kamarList.length > 0 ? (
                        kamarList.map((item, idx) => (
                          <tr key={`${item.asrama}-${item.kamar}`} className="hover:bg-slate-50 transition">
                            <td className="py-4 px-6 text-center text-slate-500 font-medium">{idx + 1}</td>
                            <td className="py-4 px-6 font-bold text-[#0B4A3F]">{item.asrama}</td>
                            <td className="py-4 px-6 text-slate-600 font-bold">{item.kamar}</td>
                            <td className="py-4 px-6 font-bold">{item.kapasitas}</td>
                            <td className="py-4 px-6 font-bold text-emerald-600">{item.terisi}</td>
                            <td className="py-4 px-6 text-slate-800 font-bold">{item.musyrifs[0] ? item.musyrifs[0].name : '-'}</td>
                            <td className="py-4 px-6 text-slate-800 font-bold">{item.musyrifs[1] ? item.musyrifs[1].name : '-'}</td>
                            <td className="py-4 px-6">
                              <div className="flex justify-center gap-2">
                                <button onClick={() => {
                                  // Open edit modal for the first musyrif or create new
                                  if(item.musyrifs[0]) setEditingMusyrif(item.musyrifs[0]);
                                  else {
                                    // Hack to set default asrama/kamar when adding
                                    setShowMusyrifModal(true);
                                  }
                                }} className="p-1.5 text-blue-500 hover:bg-blue-50 rounded-lg transition" title="Edit Musyrif">
                                  <Edit className="w-4 h-4" />
                                </button>
                                {item.musyrifs[0] && (
                                  <button onClick={() => {
                                    if (window.confirm('Hapus musyrif ini?')) {
                                      deleteMusyrif(item.musyrifs[0].id);
                                    }
                                  }} className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition" title="Hapus Musyrif">
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                )}
                              </div>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={8} className="py-10 text-center text-slate-500 font-medium">Belum ada data kamar</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
              );
            })()}
"""

musyrif_view_pattern = r'\{\/\* DATA MUSYRIF VIEW \*\/\}.*?\{\/\* DATA YATIM VIEW \*\/\}'

match = re.search(musyrif_view_pattern, content, re.DOTALL)
if match:
    content = content.replace(match.group(0), new_musyrif_view + "\n            {/* DATA YATIM VIEW */}")
    with open('src/components/AdminDashboard.tsx', 'w') as f:
        f.write(content)
    print("Replaced musyrif view successfully!")
else:
    print("Could not find musyrif view pattern")

