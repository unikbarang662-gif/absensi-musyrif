/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect } from 'react';
import { Musyrif, AbsensiRecord, PondokSettings, ActiveUser, AsramaName, Santri, AbsensiTidurRecord, AbsensiMutholaahRecord } from '../types';
import { INITIAL_MUSYRIF_LIST, INITIAL_ABSENSI_DATA, DEFAULT_PONDOK_SETTINGS, INITIAL_SANTRI_LIST, INITIAL_ABSENSI_TIDUR_DATA } from '../data';
import { 
  collection, 
  doc, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  onSnapshot,
  writeBatch,
  query,
  orderBy,
  limit,
  getCountFromServer,
  where,
  getDocs,
  Timestamp
} from 'firebase/firestore';
import { db, OperationType, handleFirestoreError } from '../firebase';

interface AppStats {
  today: number;
  week: number;
  month: number;
}

interface AppState {
  musyrifs: Musyrif[];
  absensiList: AbsensiRecord[];
  santris: Santri[];
  absensiTidurList: AbsensiTidurRecord[];
  absensiMutholaahList: AbsensiMutholaahRecord[];
  pondokSettings: PondokSettings;
  currentUser: ActiveUser | null;
  loading: boolean;
  firebaseError: string | null;
  isCloudSynced: boolean;
  stats: AppStats;
  addMusyrif: (musyrif: Omit<Musyrif, 'id' | 'isActive'>) => void;
  updateMusyrif: (id: string, updated: Partial<Musyrif>) => void;
  deleteMusyrif: (id: string) => void;
  submitAbsensi: (record: Omit<AbsensiRecord, 'id' | 'waktu' | 'tanggal' | 'hari'>) => void;
  deleteAbsensi: (id: string) => void;
  addSantri: (santri: Omit<Santri, 'id' | 'isActive'>) => void;
  updateSantri: (id: string, updated: Partial<Santri>) => void;
  deleteSantri: (id: string) => void;
  submitAbsensiTidur: (record: Omit<AbsensiTidurRecord, 'id' | 'waktu' | 'tanggal' | 'hari'>) => void;
  deleteAbsensiTidur: (id: string) => void;
  submitAbsensiMutholaah: (record: Omit<AbsensiMutholaahRecord, 'id' | 'waktu' | 'tanggal' | 'hari'>) => void;
  deleteAbsensiMutholaah: (id: string) => void;
  updateSettings: (settings: Partial<PondokSettings>) => void;
  deleteKamarMaster: (room: string) => Promise<void>;
  login: (name: string, asrama: AsramaName | 'Admin', password?: string) => { success: boolean; error?: string };
  logout: () => void;
  retrySync: () => Promise<void>;
  fetchFullAbsensi: (filters?: { musyrifId?: string; asrama?: string; limit?: number }) => Promise<void>;
}

const AppStateContext = createContext<AppState | undefined>(undefined);

export const AppStateProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [santris, setSantris] = useState<Santri[]>(() => {
    const cached = localStorage.getItem('bm_santris');
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch (e) {}
    }
    return INITIAL_SANTRI_LIST;
  });
  const [absensiTidurList, setAbsensiTidurList] = useState<AbsensiTidurRecord[]>(() => {
    const cached = localStorage.getItem('bm_absensi_tidur');
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch (e) {}
    }
    return INITIAL_ABSENSI_TIDUR_DATA;
  });
  const [absensiMutholaahList, setAbsensiMutholaahList] = useState<AbsensiMutholaahRecord[]>(() => {
    const cached = localStorage.getItem('bm_absensi_mutholaah');
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch (e) {}
    }
    return [];
  });
  const [musyrifs, setMusyrifs] = useState<Musyrif[]>(() => {
    const cached = localStorage.getItem('bm_musyrifs');
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch (e) {
        // ignore
      }
    }
    return INITIAL_MUSYRIF_LIST;
  });
  const [absensiList, setAbsensiList] = useState<AbsensiRecord[]>(() => {
    const cached = localStorage.getItem('bm_absensi');
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch (e) {
        // ignore
      }
    }
    return INITIAL_ABSENSI_DATA;
  });
  const [pondokSettings, setPondokSettings] = useState<PondokSettings>(() => {
    const cached = localStorage.getItem('bm_settings');
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (parsed && parsed.namaPondok) return parsed;
      } catch (e) {
        // ignore
      }
    }
    return DEFAULT_PONDOK_SETTINGS;
  });
  const [currentUser, setCurrentUser] = useState<ActiveUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [firebaseError, setFirebaseError] = useState<string | null>(null);
  const [isCloudSynced, setIsCloudSynced] = useState<boolean>(true);
  const [stats, setStats] = useState<AppStats>({ today: 0, week: 0, month: 0 });

  const lastStatsRefresh = React.useRef<number>(0);

  // Fetch server-side counts for dashboard
  const refreshStats = async (force = false) => {
    // Throttle refresh to once every 2 minutes unless forced
    const nowTime = Date.now();
    if (!force && nowTime - lastStatsRefresh.current < 120000) return;
    
    try {
      lastStatsRefresh.current = nowTime;
      const now = new Date();
      const formatNum = (num: number) => num.toString().padStart(2, '0');
      const dateToday = `${now.getFullYear()}-${formatNum(now.getMonth() + 1)}-${formatNum(now.getDate())}`;
      
      const oneWeekAgo = new Date();
      oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
      const dateWeek = `${oneWeekAgo.getFullYear()}-${formatNum(oneWeekAgo.getMonth() + 1)}-${formatNum(oneWeekAgo.getDate())}`;
      
      const oneMonthAgo = new Date();
      oneMonthAgo.setDate(oneMonthAgo.getDate() - 30);
      const dateMonth = `${oneMonthAgo.getFullYear()}-${formatNum(oneMonthAgo.getMonth() + 1)}-${formatNum(oneMonthAgo.getDate())}`;

      const collRef = collection(db, 'absensiList');
      
      const qToday = query(collRef, where('tanggal', '==', dateToday));
      const qWeek = query(collRef, where('tanggal', '>=', dateWeek));
      const qMonth = query(collRef, where('tanggal', '>=', dateMonth));

      const [snapToday, snapWeek, snapMonth] = await Promise.all([
        getCountFromServer(qToday),
        getCountFromServer(qWeek),
        getCountFromServer(qMonth)
      ]);

      setStats({
        today: snapToday.data().count,
        week: snapWeek.data().count,
        month: snapMonth.data().count
      });
    } catch (err: any) {
      console.warn('Stats refresh failed:', err);
      if (err?.message && (err.message.toLowerCase().includes('quota') || err.message.toLowerCase().includes('limit') || err.message.toLowerCase().includes('exceeded'))) {
        setIsCloudSynced(false);
        setFirebaseError(err.message);
      }
    }
  };

    // Initialize and register data fetching
    useEffect(() => {
      let settingsLoaded = false;
      let musyrifsLoaded = false;
      let absensiLoaded = false;
      let santrisLoaded = false;
      let tidursLoaded = false;
      let mutholaahsLoaded = false;
  
      refreshStats();
  
      // Safety fallback timer to prevent infinite loading
      const fallbackTimer = setTimeout(() => {
        setLoading(false);
      }, 3500);
  
      const checkAllLoaded = () => {
        if (settingsLoaded && musyrifsLoaded && absensiLoaded && santrisLoaded && tidursLoaded && mutholaahsLoaded) {
          setLoading(false);
          clearTimeout(fallbackTimer);
          setIsCloudSynced(true);
          setFirebaseError(null);
        }
      };
  
      // 1. Central settings real-time snapshot listener (Keep real-time as it's small and important)
      const settingsRef = doc(db, 'settings', 'pondok');
      const unsubSettings = onSnapshot(settingsRef, (snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.data() as PondokSettings;
          if (!data.daftarKamar) {
            data.daftarKamar = DEFAULT_PONDOK_SETTINGS.daftarKamar || [];
          }
          setPondokSettings(data);
          localStorage.setItem('bm_settings', JSON.stringify(data));
        }
        settingsLoaded = true;
        checkAllLoaded();
      }, (error) => {
        console.warn('Settings listener offline:', error);
        setIsCloudSynced(false);
        if (error?.message && (error.message.toLowerCase().includes('quota') || error.message.toLowerCase().includes('limit') || error.message.toLowerCase().includes('exceeded'))) {
          setFirebaseError(error.message);
        }
        settingsLoaded = true;
        checkAllLoaded();
      });
  
      // 2. Musyrifs - Switch to one-time fetch to save reads
      const fetchMusyrifs = async () => {
        try {
          const snapshot = await getDocs(collection(db, 'musyrifs'));
          if (!snapshot.empty) {
            const serverList: Musyrif[] = [];
            snapshot.forEach((docSnap) => serverList.push(docSnap.data() as Musyrif));
            setMusyrifs(serverList);
            localStorage.setItem('bm_musyrifs', JSON.stringify(serverList));
          }
        } catch (error: any) {
          console.warn('Musyrifs fetch failed:', error);
          if (error?.message && (error.message.toLowerCase().includes('quota') || error.message.toLowerCase().includes('limit') || error.message.toLowerCase().includes('exceeded'))) {
            setIsCloudSynced(false);
            setFirebaseError(error.message);
          }
        } finally {
          musyrifsLoaded = true;
          checkAllLoaded();
        }
      };
      fetchMusyrifs();
  
      // 3. Attendance report records - LIMIT TO LATEST 50
      const absensiCol = collection(db, 'absensiList');
      const qAbsensi = query(absensiCol, orderBy('tanggal', 'desc'), orderBy('waktu', 'desc'), limit(50));
      
      const unsubAbsensi = onSnapshot(qAbsensi, (snapshot) => {
        if (!snapshot.empty) {
          const serverList: AbsensiRecord[] = [];
          snapshot.forEach((docSnap) => {
            serverList.push(docSnap.data() as AbsensiRecord);
          });
          setAbsensiList(serverList);
          localStorage.setItem('bm_absensi', JSON.stringify(serverList));
          // REMOVED refreshStats() from here to save reads
        }
        absensiLoaded = true;
        checkAllLoaded();
      }, (error) => {
        console.warn('Absensi listener offline:', error);
        setIsCloudSynced(false);
        if (error?.message && (error.message.toLowerCase().includes('quota') || error.message.toLowerCase().includes('limit') || error.message.toLowerCase().includes('exceeded'))) {
          setFirebaseError(error.message);
        }
        absensiLoaded = true;
        checkAllLoaded();
      });
  
      // 4. Santris - Switch to one-time fetch
      const fetchSantris = async () => {
        try {
          const snapshot = await getDocs(collection(db, 'santris'));
          if (!snapshot.empty) {
            const serverList: Santri[] = [];
            snapshot.forEach((docSnap) => serverList.push(docSnap.data() as Santri));
            setSantris(serverList);
            localStorage.setItem('bm_santris', JSON.stringify(serverList));
          }
        } catch (error: any) {
          console.warn('Santris fetch failed:', error);
          if (error?.message && (error.message.toLowerCase().includes('quota') || error.message.toLowerCase().includes('limit') || error.message.toLowerCase().includes('exceeded'))) {
            setIsCloudSynced(false);
            setFirebaseError(error.message);
          }
        } finally {
          santrisLoaded = true;
          checkAllLoaded();
        }
      };
      fetchSantris();
  
      // 5. Absensi Tidur - Switch to one-time fetch for history
      const fetchAbsensiTidur = async () => {
        try {
          const qTidur = query(collection(db, 'absensiTidurList'), orderBy('tanggal', 'desc'), orderBy('waktu', 'desc'), limit(30));
          const snapshot = await getDocs(qTidur);
          if (!snapshot.empty) {
            const serverList: AbsensiTidurRecord[] = [];
            snapshot.forEach((docSnap) => serverList.push(docSnap.data() as AbsensiTidurRecord));
            setAbsensiTidurList(serverList);
            localStorage.setItem('bm_absensi_tidur', JSON.stringify(serverList));
          }
        } catch (error: any) {
          console.warn('AbsensiTidur fetch failed:', error);
          if (error?.message && (error.message.toLowerCase().includes('quota') || error.message.toLowerCase().includes('limit') || error.message.toLowerCase().includes('exceeded'))) {
            setIsCloudSynced(false);
            setFirebaseError(error.message);
          }
        } finally {
          tidursLoaded = true;
          checkAllLoaded();
        }
      };
      fetchAbsensiTidur();
  
      // 6. Absensi Mutholaah - Switch to one-time fetch
      const fetchAbsensiMutholaah = async () => {
        try {
          const qMutholaah = query(collection(db, 'absensiMutholaahList'), orderBy('tanggal', 'desc'), orderBy('waktu', 'desc'), limit(30));
          const snapshot = await getDocs(qMutholaah);
          if (!snapshot.empty) {
            const serverList: AbsensiMutholaahRecord[] = [];
            snapshot.forEach((docSnap) => serverList.push(docSnap.data() as AbsensiMutholaahRecord));
            setAbsensiMutholaahList(serverList);
            localStorage.setItem('bm_absensi_mutholaah', JSON.stringify(serverList));
          }
        } catch (error: any) {
          console.warn('AbsensiMutholaah fetch failed:', error);
          if (error?.message && (error.message.toLowerCase().includes('quota') || error.message.toLowerCase().includes('limit') || error.message.toLowerCase().includes('exceeded'))) {
            setIsCloudSynced(false);
            setFirebaseError(error.message);
          }
        } finally {
          mutholaahsLoaded = true;
          checkAllLoaded();
        }
      };
      fetchAbsensiMutholaah();
  
      // Load active login session
      const storedUser = localStorage.getItem('bm_session');
      if (storedUser) {
        try { setCurrentUser(JSON.parse(storedUser)); } catch (err) { setCurrentUser(null); }
      } else {
        const defaultUser: ActiveUser = {
          id: 'hakim-1',
          name: 'Ust Ali Mashuri',
          asrama: 'Al Hakim',
          kamar: 'Kamar 101',
          role: 'musyrif'
        };
        setCurrentUser(defaultUser);
        localStorage.setItem('bm_session', JSON.stringify(defaultUser));
      }
  
      return () => {
        unsubSettings();
        unsubAbsensi();
        clearTimeout(fallbackTimer);
      };
    }, []);

  const fetchFullAbsensi = async (filters?: { musyrifId?: string; asrama?: string; limit?: number }) => {
    try {
      // DEFAULT LIMIT of 200 to prevent accidental full collection reads
      const effectiveLimit = filters?.limit || 200;
      let q = query(collection(db, 'absensiList'), orderBy('tanggal', 'desc'), orderBy('waktu', 'desc'), limit(effectiveLimit));
      
      if (filters?.musyrifId) {
        q = query(q, where('musyrifId', '==', filters.musyrifId));
      }
      if (filters?.asrama) {
        q = query(q, where('asrama', '==', filters.asrama));
      }

      const snap = await getDocs(q);
      const list: AbsensiRecord[] = [];
      snap.forEach(d => list.push(d.data() as AbsensiRecord));
      
      // Merge with current list to avoid flickering, or just replace if it's a specific filter
      if (!filters) {
        setAbsensiList(list);
      } else {
        setAbsensiList(prev => {
          const combined = [...list, ...prev];
          const unique = Array.from(new Map(combined.map(item => [item.id, item])).values());
          return unique.sort((a, b) => {
            const dateComp = b.tanggal.localeCompare(a.tanggal);
            if (dateComp !== 0) return dateComp;
            return b.waktu.localeCompare(a.waktu);
          });
        });
      }
    } catch (e: any) {
      console.warn('Fetch absensi failed (offline or quota exceeded):', e);
      setIsCloudSynced(false);
      setFirebaseError(e?.message || String(e));
    }
  };

  // Helper to remove any undefined fields before writing to Firestore (prevents Firebase SDK from throwing errors)
  const cleanUndefined = <T extends Record<string, any>>(obj: T): T => {
    const cleaned = { ...obj } as any;
    Object.keys(cleaned).forEach((key) => {
      if (cleaned[key] === undefined) {
        delete cleaned[key];
      } else if (cleaned[key] !== null && typeof cleaned[key] === 'object' && !Array.isArray(cleaned[key])) {
        cleaned[key] = cleanUndefined(cleaned[key]);
      }
    });
    return cleaned;
  };

  // CRUD actions proxying write commands optimistically to local and cloud Firestore
  const addMusyrif = async (newMusyrif: Omit<Musyrif, 'id' | 'isActive'>) => {
    const freshId = `m-${Date.now()}`;
    const fresh: Musyrif = {
      ...newMusyrif,
      id: freshId,
      isActive: true,
    };

    // Optimistic local state update for zero lag
    setMusyrifs((prev) => {
      const updated = [...prev.filter((m) => m.id !== freshId), fresh];
      localStorage.setItem('bm_musyrifs', JSON.stringify(updated));
      return updated;
    });

    try {
      await setDoc(doc(db, 'musyrifs', freshId), cleanUndefined(fresh));
      setIsCloudSynced(true);
      setFirebaseError(null);
    } catch (error: any) {
      console.warn('Background sync failed for addMusyrif, stored locally:', error);
      setIsCloudSynced(false);
      setFirebaseError(`Add Musyrif: ${error.message || error}`);
    }
  };

  const updateMusyrif = async (id: string, updated: Partial<Musyrif>) => {
    // Optimistic local update
    setMusyrifs((prev) => {
      const updatedList = prev.map((m) => (m.id === id ? { ...m, ...updated } : m));
      localStorage.setItem('bm_musyrifs', JSON.stringify(updatedList));
      return updatedList;
    });

    try {
      await setDoc(doc(db, 'musyrifs', id), cleanUndefined(updated), { merge: true });
      setIsCloudSynced(true);
      setFirebaseError(null);
    } catch (error: any) {
      console.warn('Background sync failed for updateMusyrif, updated locally:', error);
      setIsCloudSynced(false);
      setFirebaseError(`Update Musyrif: ${error.message || error}`);
    }
  };

  const deleteMusyrif = async (id: string) => {
    // Optimistic local update
    setMusyrifs((prev) => {
      const filtered = prev.filter((m) => m.id !== id);
      localStorage.setItem('bm_musyrifs', JSON.stringify(filtered));
      return filtered;
    });

    try {
      await deleteDoc(doc(db, 'musyrifs', id));
      setIsCloudSynced(true);
      setFirebaseError(null);
    } catch (error: any) {
      console.warn('Background sync failed for deleteMusyrif, removed locally:', error);
      setIsCloudSynced(false);
      setFirebaseError(`Delete Musyrif: ${error.message || error}`);
    }
  };

  const submitAbsensi = async (record: Omit<AbsensiRecord, 'id' | 'waktu' | 'tanggal' | 'hari'>) => {
    const now = new Date();
    const DAYS_INDONESIAN = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    const hari = DAYS_INDONESIAN[now.getDay()];

    const formatNum = (num: number) => num.toString().padStart(2, '0');
    const waktu = `${formatNum(now.getHours())}:${formatNum(now.getMinutes())}`;
    const tanggal = `${now.getFullYear()}-${formatNum(now.getMonth() + 1)}-${formatNum(now.getDate())}`;

    const freshId = `r-${Date.now()}`;
    const fresh: AbsensiRecord = {
      ...record,
      id: freshId,
      waktu,
      tanggal,
      hari,
    };

    // Optimistic local update
    setAbsensiList((prev) => {
      const list = [fresh, ...prev.filter((r) => r.id !== freshId)];
      const sortedList = list.sort((a, b) => {
        const dateComp = b.tanggal.localeCompare(a.tanggal);
        if (dateComp !== 0) return dateComp;
        return b.waktu.localeCompare(a.waktu);
      });
      localStorage.setItem('bm_absensi', JSON.stringify(sortedList));
      return sortedList;
    });

    try {
      await setDoc(doc(db, 'absensiList', freshId), cleanUndefined(fresh));
      setIsCloudSynced(true);
      setFirebaseError(null);
      // Trigger a light stats refresh after successful submission
      refreshStats(true);
    } catch (error: any) {
      console.warn('Background sync failed for submitAbsensi, saved locally:', error);
      setIsCloudSynced(false);
      setFirebaseError(`Submit Absensi: ${error.message || error}`);
    }
  };

  const addSantri = async (newSantri: Omit<Santri, 'id' | 'isActive'>) => {
    const freshId = `s-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const fresh: Santri = {
      ...newSantri,
      id: freshId,
      isActive: true,
    };
    
    setSantris((prev) => {
      const updated = [...prev.filter((s) => s.id !== freshId), fresh];
      localStorage.setItem('bm_santris', JSON.stringify(updated));
      return updated;
    });

    try {
      await setDoc(doc(db, 'santris', freshId), cleanUndefined(fresh));
      setIsCloudSynced(true);
      setFirebaseError(null);
    } catch (error: any) {
      console.warn('Sync failed addSantri', error);
      setIsCloudSynced(false);
      setFirebaseError(`Add Santri: ${error.message || error}`);
    }
  };

  const updateSantri = async (id: string, updated: Partial<Santri>) => {
    setSantris((prev) => {
      const updatedList = prev.map((s) => (s.id === id ? { ...s, ...updated } : s));
      localStorage.setItem('bm_santris', JSON.stringify(updatedList));
      return updatedList;
    });

    try {
      await setDoc(doc(db, 'santris', id), cleanUndefined(updated), { merge: true });
      setIsCloudSynced(true);
      setFirebaseError(null);
    } catch (error: any) {
      console.warn('Sync failed updateSantri', error);
      setIsCloudSynced(false);
      setFirebaseError(`Update Santri: ${error.message || error}`);
    }
  };

  const deleteSantri = async (id: string) => {
    setSantris((prev) => {
      const filtered = prev.filter((s) => s.id !== id);
      localStorage.setItem('bm_santris', JSON.stringify(filtered));
      return filtered;
    });

    try {
      await deleteDoc(doc(db, 'santris', id));
      setIsCloudSynced(true);
      setFirebaseError(null);
    } catch (error: any) {
      console.warn('Sync failed deleteSantri', error);
      setIsCloudSynced(false);
      setFirebaseError(`Delete Santri: ${error.message || error}`);
    }
  };

  const submitAbsensiTidur = async (record: Omit<AbsensiTidurRecord, 'id' | 'waktu' | 'tanggal' | 'hari'>) => {
    const now = new Date();
    const DAYS_INDONESIAN = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    const hari = DAYS_INDONESIAN[now.getDay()];

    const formatNum = (num: number) => num.toString().padStart(2, '0');
    const waktu = `${formatNum(now.getHours())}:${formatNum(now.getMinutes())}`;
    const tanggal = `${now.getFullYear()}-${formatNum(now.getMonth() + 1)}-${formatNum(now.getDate())}`;

    const freshId = `at-${Date.now()}`;
    const fresh: AbsensiTidurRecord = {
      ...record,
      id: freshId,
      waktu,
      tanggal,
      hari,
    };

    setAbsensiTidurList((prev) => {
      const list = [fresh, ...prev.filter((r) => r.id !== freshId)];
      const sortedList = list.sort((a, b) => {
        const dateComp = b.tanggal.localeCompare(a.tanggal);
        if (dateComp !== 0) return dateComp;
        return b.waktu.localeCompare(a.waktu);
      });
      localStorage.setItem('bm_absensi_tidur', JSON.stringify(sortedList));
      return sortedList;
    });

    try {
      await setDoc(doc(db, 'absensiTidurList', freshId), cleanUndefined(fresh));
      setIsCloudSynced(true);
      setFirebaseError(null);
      // Optional: refreshStats() if tidur is included in counts
    } catch (error: any) {
      console.warn('Sync failed submitAbsensiTidur', error);
      setIsCloudSynced(false);
      setFirebaseError(`Submit Absensi Tidur: ${error.message || error}`);
    }
  };

  const deleteAbsensiTidur = async (id: string) => {
    setAbsensiTidurList((prev) => {
      const filtered = prev.filter((r) => r.id !== id);
      localStorage.setItem('bm_absensi_tidur', JSON.stringify(filtered));
      return filtered;
    });

    try {
      await deleteDoc(doc(db, 'absensiTidurList', id));
      setIsCloudSynced(true);
      setFirebaseError(null);
    } catch (error: any) {
      console.warn('Sync failed deleteAbsensiTidur', error);
      setIsCloudSynced(false);
      setFirebaseError(`Delete Absensi Tidur: ${error.message || error}`);
    }
  };

  const submitAbsensiMutholaah = async (record: Omit<AbsensiMutholaahRecord, 'id' | 'waktu' | 'tanggal' | 'hari'>) => {
    const now = new Date();
    const DAYS_INDONESIAN = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    const hari = DAYS_INDONESIAN[now.getDay()];

    const formatNum = (num: number) => num.toString().padStart(2, '0');
    const waktu = `${formatNum(now.getHours())}:${formatNum(now.getMinutes())}`;
    const tanggal = `${now.getFullYear()}-${formatNum(now.getMonth() + 1)}-${formatNum(now.getDate())}`;

    const freshId = `am-${Date.now()}`;
    const fresh: AbsensiMutholaahRecord = {
      ...record,
      id: freshId,
      waktu,
      tanggal,
      hari,
    };

    setAbsensiMutholaahList((prev) => {
      const list = [fresh, ...prev.filter((r) => r.id !== freshId)];
      const sortedList = list.sort((a, b) => {
        const dateComp = b.tanggal.localeCompare(a.tanggal);
        if (dateComp !== 0) return dateComp;
        return b.waktu.localeCompare(a.waktu);
      });
      localStorage.setItem('bm_absensi_mutholaah', JSON.stringify(sortedList));
      return sortedList;
    });

    try {
      await setDoc(doc(db, 'absensiMutholaahList', freshId), cleanUndefined(fresh));
      setIsCloudSynced(true);
      setFirebaseError(null);
    } catch (error: any) {
      console.warn('Sync failed submitAbsensiMutholaah', error);
      setIsCloudSynced(false);
      setFirebaseError(`Submit Absensi Mutholaah: ${error.message || error}`);
    }
  };

  const deleteAbsensiMutholaah = async (id: string) => {
    setAbsensiMutholaahList((prev) => {
      const filtered = prev.filter((r) => r.id !== id);
      localStorage.setItem('bm_absensi_mutholaah', JSON.stringify(filtered));
      return filtered;
    });

    try {
      await deleteDoc(doc(db, 'absensiMutholaahList', id));
      setIsCloudSynced(true);
      setFirebaseError(null);
    } catch (error: any) {
      console.warn('Sync failed deleteAbsensiMutholaah', error);
      setIsCloudSynced(false);
      setFirebaseError(`Delete Absensi Mutholaah: ${error.message || error}`);
    }
  };

  const deleteAbsensi = async (id: string) => {
    // Optimistic local update
    setAbsensiList((prev) => {
      const filtered = prev.filter((r) => r.id !== id);
      localStorage.setItem('bm_absensi', JSON.stringify(filtered));
      return filtered;
    });

    try {
      await deleteDoc(doc(db, 'absensiList', id));
      setIsCloudSynced(true);
      setFirebaseError(null);
    } catch (error: any) {
      console.warn('Background sync failed for deleteAbsensi, removed locally:', error);
      setIsCloudSynced(false);
      setFirebaseError(`Delete Absensi: ${error.message || error}`);
    }
  };

  const updateSettings = async (sets: Partial<PondokSettings>) => {
    const updated = { ...pondokSettings, ...sets };
    // Optimistic local update
    setPondokSettings(updated);
    localStorage.setItem('bm_settings', JSON.stringify(updated));

    try {
      await setDoc(doc(db, 'settings', 'pondok'), cleanUndefined(updated));
      setIsCloudSynced(true);
      setFirebaseError(null);
    } catch (error: any) {
      console.warn('Background sync failed for updateSettings, updated locally:', error);
      setIsCloudSynced(false);
      setFirebaseError(`Update Settings: ${error.message || error}`);
    }
  };

  const deleteKamarMaster = async (room: string) => {
    const trimmedRoom = room.trim();

    // 1. Optimistic Local State Updates
    setSantris((prev) => {
      const updated = prev.map((s) => s.kamar?.trim() === trimmedRoom ? { ...s, kamar: '' } : s);
      localStorage.setItem('bm_santris', JSON.stringify(updated));
      return updated;
    });

    setMusyrifs((prev) => {
      const updated = prev.map((m) => m.kamar?.trim() === trimmedRoom ? { ...m, kamar: '' } : m);
      localStorage.setItem('bm_musyrifs', JSON.stringify(updated));
      return updated;
    });

    const updatedSettings = {
      ...pondokSettings,
      daftarKamar: (pondokSettings?.daftarKamar || []).filter((r) => r.trim() !== trimmedRoom)
    };
    setPondokSettings(updatedSettings);
    localStorage.setItem('bm_settings', JSON.stringify(updatedSettings));

    // 2. Atomic Firestore Write Batch (Guarantees atomic execution and a single snapshot listener trigger)
    try {
      const batch = writeBatch(db);

      // Find affected santris
      const affectedSantris = santris.filter((s) => s.kamar?.trim() === trimmedRoom);
      affectedSantris.forEach((s) => {
        const sRef = doc(db, 'santris', s.id);
        batch.set(sRef, cleanUndefined({ kamar: '' }), { merge: true });
      });

      // Find affected musyrifs
      const affectedMusyrifs = musyrifs.filter((m) => m.kamar?.trim() === trimmedRoom);
      affectedMusyrifs.forEach((m) => {
        const mRef = doc(db, 'musyrifs', m.id);
        batch.set(mRef, cleanUndefined({ kamar: '' }), { merge: true });
      });

      // Update settings document
      const settingsRef = doc(db, 'settings', 'pondok');
      batch.set(settingsRef, cleanUndefined(updatedSettings), { merge: true });

      await batch.commit();
      setIsCloudSynced(true);
      setFirebaseError(null);
    } catch (error: any) {
      console.warn('Sync failed for deleteKamarMaster, saved locally:', error);
      setIsCloudSynced(false);
      setFirebaseError(`Hapus Kamar: ${error.message || error}`);
    }
  };

  const retrySync = async () => {
    setFirebaseError(null);
    setIsCloudSynced(true);

    try {
      // 1. Sync Settings
      const cachedSettings = localStorage.getItem('bm_settings');
      if (cachedSettings) {
        const parsed = JSON.parse(cachedSettings);
        if (parsed && parsed.namaPondok) {
          await setDoc(doc(db, 'settings', 'pondok'), cleanUndefined(parsed));
        }
      }

      // 2. Sync Musyrifs
      const cachedMusyrifs = localStorage.getItem('bm_musyrifs');
      if (cachedMusyrifs) {
        const parsed = JSON.parse(cachedMusyrifs) as Musyrif[];
        if (Array.isArray(parsed)) {
          for (const m of parsed) {
            await setDoc(doc(db, 'musyrifs', m.id), cleanUndefined(m));
          }
        }
      }

      // 3. Sync Absensi List
      const cachedAbsensi = localStorage.getItem('bm_absensi');
      if (cachedAbsensi) {
        const parsed = JSON.parse(cachedAbsensi) as AbsensiRecord[];
        if (Array.isArray(parsed)) {
          for (const r of parsed) {
            await setDoc(doc(db, 'absensiList', r.id), cleanUndefined(r));
          }
        }
      }

      // 4. Sync Santri
      const cachedSantris = localStorage.getItem('bm_santris');
      if (cachedSantris) {
        const parsed = JSON.parse(cachedSantris) as Santri[];
        if (Array.isArray(parsed)) {
          for (const s of parsed) {
            await setDoc(doc(db, 'santris', s.id), cleanUndefined(s));
          }
        }
      }

      // 5. Sync Absensi Tidur
      const cachedAbsensiTidur = localStorage.getItem('bm_absensi_tidur');
      if (cachedAbsensiTidur) {
        const parsed = JSON.parse(cachedAbsensiTidur) as AbsensiTidurRecord[];
        if (Array.isArray(parsed)) {
          for (const r of parsed) {
            await setDoc(doc(db, 'absensiTidurList', r.id), cleanUndefined(r));
          }
        }
      }

      // 6. Sync Absensi Mutholaah
      const cachedAbsensiMutholaah = localStorage.getItem('bm_absensi_mutholaah');
      if (cachedAbsensiMutholaah) {
        const parsed = JSON.parse(cachedAbsensiMutholaah) as AbsensiMutholaahRecord[];
        if (Array.isArray(parsed)) {
          for (const r of parsed) {
            await setDoc(doc(db, 'absensiMutholaahList', r.id), cleanUndefined(r));
          }
        }
      }
      setIsCloudSynced(true);
      setFirebaseError(null);
    } catch (err: any) {
      console.warn('Failed to manually sync data to Firebase (offline or quota exceeded):', err);
      setFirebaseError(`Retry Sync: ${err?.message || err}`);
      setIsCloudSynced(false);
    }
  };

  const login = (name: string, asrama: AsramaName | 'Admin', password?: string) => {
    const cleanPassword = (password || '').trim();
    const cleanName = (name || '').trim();

    if (asrama === 'Admin') {
      if (cleanPassword === 'admin123' || cleanPassword === 'admin' || cleanPassword === 'adminpassword123') {
        const adminSession: ActiveUser = {
          id: 'admin-1',
          name: 'Administrator',
          role: 'admin',
        };
        setCurrentUser(adminSession);
        localStorage.setItem('bm_session', JSON.stringify(adminSession));
        return { success: true };
      }
      return { success: false, error: 'Password Admin salah! (Gunakan password "admin123")' };
    }

    // Find musyrif in selected dormitory using trimmed and case-insensitive check
    const matched = musyrifs.find(
      (m) => m.asrama === asrama && m.name.toLowerCase().trim() === cleanName.toLowerCase()
    );

    if (matched) {
      const expectedPassword = (matched.password || '1234').trim();
      if (cleanPassword === '1234' || cleanPassword === 'musyrif123' || cleanPassword === expectedPassword) {
        const userSession: ActiveUser = {
          id: matched.id,
          name: matched.name,
          asrama: matched.asrama,
          kamar: matched.kamar,
          role: 'musyrif',
        };
        setCurrentUser(userSession);
        localStorage.setItem('bm_session', JSON.stringify(userSession));
        return { success: true };
      }
      return { success: false, error: 'Password Musyrif salah! (Gunakan "1234")' };
    }

    return { success: false, error: 'Nama Musyrif tidak terdaftar di asrama tersebut.' };
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('bm_session');
  };

  return (
    <AppStateContext.Provider
      value={{
        musyrifs,
        absensiList,
        santris,
        absensiTidurList,
        absensiMutholaahList,
        pondokSettings,
        currentUser,
        loading,
        firebaseError,
        isCloudSynced,
        stats,
        addMusyrif,
        updateMusyrif,
        deleteMusyrif,
        submitAbsensi,
        deleteAbsensi,
        addSantri,
        updateSantri,
        deleteSantri,
        submitAbsensiTidur,
        deleteAbsensiTidur,
        submitAbsensiMutholaah,
        deleteAbsensiMutholaah,
        updateSettings,
        deleteKamarMaster,
        login,
        logout,
        retrySync,
        fetchFullAbsensi,
      }}
    >
      {children}
    </AppStateContext.Provider>
  );
};

export const useAppState = () => {
  const context = useContext(AppStateContext);
  if (context === undefined) {
    throw new Error('useAppState must be used within an AppStateProvider');
  }
  return context;
};
