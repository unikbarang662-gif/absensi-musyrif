/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Utility to compress and resize images client-side using HTML5 Canvas.
 * Resizes the image to a maximum dimension while maintaining aspect ratio,
 * and outputs a compressed JPEG base64 string.
 *
 * @param base64Str - The original base64 raw data URL
 * @param maxWidth - The maximum width boundary (default 1000px)
 * @param maxHeight - The maximum height boundary (default 1000px)
 * @param quality - The compression quality between 0.0 and 1.0 (default 0.7)
 */
export function compressImage(
  base64Str: string,
  maxWidth = 1000,
  maxHeight = 1000,
  quality = 0.7
): Promise<string> {
  return new Promise((resolve, reject) => {
    // If it's a mock url (like Unsplash urls used for quick simulation), return unchanged
    if (!base64Str.startsWith('data:image')) {
      resolve(base64Str);
      return;
    }

    const img = new Image();
    img.src = base64Str;
    
    img.onload = () => {
      let width = img.width;
      let height = img.height;

      // Maintain aspect ratio while constricting to maximum limits
      if (width > height) {
        if (width > maxWidth) {
          height = Math.round((height * maxWidth) / width);
          width = maxWidth;
        }
      } else {
        if (height > maxHeight) {
          width = Math.round((width * maxHeight) / height);
          height = maxHeight;
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;

      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve(base64Str); // Fallback to original
        return;
      }

      // Fill background as white to handle transparent PNGs transitioning to JPEG
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, width, height);

      // Draw original image on resized canvas bounds
      ctx.drawImage(img, 0, 0, width, height);

      try {
        // Output as highly optimized jpeg data URL
        const compressedDataUrl = canvas.toDataURL('image/jpeg', quality);
        resolve(compressedDataUrl);
      } catch (err) {
        console.error('Failed to export canvas to compressed DataURL: ', err);
        resolve(base64Str); // Fallback
      }
    };

    img.onerror = (err) => {
      console.error('Error loading image source object for canvas resize: ', err);
      reject(err);
    };
  });
}
