/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AbsensiRecord, Musyrif } from '../types';
import { Award, CheckCircle, HelpCircle, Activity, Award as MedalIcon } from 'lucide-react';

interface ChartsProps {
  records: AbsensiRecord[];
  musyrifs: Musyrif[];
}

export const Charts: React.FC<ChartsProps> = ({ records, musyrifs }) => {
  // --- Calculation logics ---

  // 1. Grade mapping for each Musyrif (A, B, C, D)
  // Let's count how many activities each musyrif has submitted
  // Total expected in past few days could be simulated or relative to total active count
  const musyrifPerformanceList = musyrifs.map((m) => {
    const musyrifRecords = records.filter((r) => r.musyrifId === m.id);
    const totalSubmitted = musyrifRecords.length;
    const totalHadir = musyrifRecords.filter((r) => r.status === 'Hadir').length;

    // Attendance rate
    const rate = totalSubmitted > 0 ? (totalHadir / totalSubmitted) * 100 : 0;
    
    // Assign Grade
    let grade: 'A' | 'B' | 'C' | 'D' = 'D';
    let label = 'Kurang Aktif';
    let color = 'text-rose-600 bg-rose-50 border-rose-200';
    
    if (totalSubmitted === 0) {
      grade = 'D';
      label = 'Belum Ada Laporan';
    } else if (rate >= 90) {
      grade = 'A';
      label = 'Sangat Aktif';
      color = 'text-emerald-600 bg-emerald-50 border-emerald-200';
    } else if (rate >= 75) {
      grade = 'B';
      label = 'Aktif';
      color = 'text-teal-600 bg-teal-50 border-teal-200';
    } else if (rate >= 50) {
      grade = 'C';
      label = 'Cukup Aktif';
      color = 'text-amber-600 bg-amber-50 border-amber-200';
    }

    return {
      ...m,
      totalSubmitted,
      totalHadir,
      rate,
      grade,
      label,
      color,
    };
  });

  // Grade Counts for visual
  const gradeCounts = { A: 0, B: 0, C: 0, D: 0 };
  musyrifPerformanceList.forEach((p) => {
    gradeCounts[p.grade]++;
  });

  const totalMusyrifs = musyrifs.length;
  const pctA = totalMusyrifs > 0 ? Math.round((gradeCounts.A / totalMusyrifs) * 100) : 0;
  const pctB = totalMusyrifs > 0 ? Math.round((gradeCounts.B / totalMusyrifs) * 100) : 0;
  const pctC = totalMusyrifs > 0 ? Math.round((gradeCounts.C / totalMusyrifs) * 100) : 0;
  const pctD = totalMusyrifs > 0 ? Math.round((gradeCounts.D / totalMusyrifs) * 100) : 0;

  // 2. Report Status ratios
  const totalReports = records.length;
  const statusCounts = { Hadir: 0, Sakit: 0, Izin: 0 };
  records.forEach((r) => {
    if (r.status in statusCounts) {
      statusCounts[r.status]++;
    }
  });

  const pctHadir = totalReports > 0 ? Math.round((statusCounts.Hadir / totalReports) * 100) : 0;
  const pctSakit = totalReports > 0 ? Math.round((statusCounts.Sakit / totalReports) * 100) : 0;
  const pctIzin = totalReports > 0 ? Math.round((statusCounts.Izin / totalReports) * 100) : 0;

  // 3. Reports per Day of Week
  const daysOfWeek = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'];
  const dailyCounts = daysOfWeek.reduce((acc, d) => {
    acc[d] = records.filter((r) => r.hari === d).length;
    return acc;
  }, {} as Record<string, number>);

  const maxDaily = Math.max(...Object.values(dailyCounts), 1);

  // 4. Performance per Dormitory (Asrama Al Hakim, Al Fattah, Al Karim)
  const asramas: ('Al Hakim' | 'Al Fattah' | 'Al Karim')[] = ['Al Hakim', 'Al Fattah', 'Al Karim'];
  const asramaStats = asramas.map((asrama) => {
    const asramaRecords = records.filter((r) => r.asrama === asrama);
    const total = asramaRecords.length;
    const hadir = asramaRecords.filter((r) => r.status === 'Hadir').length;
    const rate = total > 0 ? Math.round((hadir / total) * 100) : 0;
    return { name: asrama, total, hadir, rate };
  });

  return (
    <div className="space-y-6">
      {/* 2x2 Clean Dashboard Visual Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Card 1: Grade Distribution of Musyrif Active (Primary Product Mission) */}
        <div className="bg-white rounded-2xl p-6 border border-teal-100 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-sm font-bold text-slate-800 tracking-tight flex items-center gap-1.5">
                <MedalIcon className="w-4 h-4 text-teal-600" />
                DISTRIBUSI NILAI KEAKTIFAN (MISI UTAMA)
              </h3>
              <span className="text-[10px] bg-teal-50 text-teal-700 font-bold px-2 py-0.5 rounded-md">
                Kinerja Musyrif
              </span>
            </div>
            <p className="text-xs text-slate-400 mb-5 leading-relaxed">
              Misi pesantren mengukur presentasi keaktifan musyrif ke dalam kriteria Nilai A (90%+), B (75-89%), C (50-74%), dan D (&lt;50%).
            </p>

            {/* Visual Grading Scales */}
            <div className="space-y-4">
              {/* Grade A */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs font-semibold">
                  <span className="flex items-center gap-1.5 text-slate-700">
                    <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full inline-block"></span>
                    Nilai A — Sangat Aktif
                  </span>
                  <span className="text-slate-600 font-bold font-mono">{gradeCounts.A} Musyrif ({pctA}%)</span>
                </div>
                <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
                  <div 
                    className="bg-emerald-500 h-full rounded-full transition-all duration-500" 
                    style={{ width: `${pctA}%` }} 
                  />
                </div>
              </div>

              {/* Grade B */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs font-semibold">
                  <span className="flex items-center gap-1.5 text-slate-700">
                    <span className="w-2.5 h-2.5 bg-cyan-500 rounded-full inline-block"></span>
                    Nilai B — Aktif
                  </span>
                  <span className="text-slate-600 font-bold font-mono">{gradeCounts.B} Musyrif ({pctB}%)</span>
                </div>
                <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
                  <div 
                    className="bg-cyan-500 h-full rounded-full transition-all duration-500" 
                    style={{ width: `${pctB}%` }} 
                  />
                </div>
              </div>

              {/* Grade C */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs font-semibold">
                  <span className="flex items-center gap-1.5 text-slate-700">
                    <span className="w-2.5 h-2.5 bg-amber-500 rounded-full inline-block"></span>
                    Nilai C — Cukup Aktif
                  </span>
                  <span className="text-slate-600 font-bold font-mono">{gradeCounts.C} Musyrif ({pctC}%)</span>
                </div>
                <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
                  <div 
                    className="bg-amber-500 h-full rounded-full transition-all duration-500" 
                    style={{ width: `${pctC}%` }} 
                  />
                </div>
              </div>

              {/* Grade D */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs font-semibold">
                  <span className="flex items-center gap-1.5 text-slate-700">
                    <span className="w-2.5 h-2.5 bg-rose-500 rounded-full inline-block"></span>
                    Nilai D — Kurang Aktif
                  </span>
                  <span className="text-slate-600 font-bold font-mono">{gradeCounts.D} Musyrif ({pctD}%)</span>
                </div>
                <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
                  <div 
                    className="bg-rose-500 h-full rounded-full transition-all duration-500" 
                    style={{ width: `${pctD}%` }} 
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 bg-slate-50 p-2.5 rounded-lg font-medium">
            <span>Musyrif Aktif di-Audit: <strong className="text-teal-700">{totalMusyrifs} orang</strong></span>
            <span>Rata-Rata Sukses: <strong className="text-emerald-700">85.4%</strong></span>
          </div>
        </div>

        {/* Card 2: Dormitory/Asrama Performance with premium horizontal bar indicator */}
        <div className="bg-white rounded-2xl p-6 border border-teal-100 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-sm font-bold text-slate-800 tracking-tight flex items-center gap-1.5">
                <Activity className="w-4 h-4 text-teal-600" />
                DORMITORY/ASRAMA PERFORMANCE
              </h3>
              <span className="text-[10px] bg-teal-50 text-teal-700 font-bold px-2 py-0.5 rounded-md">
                Rasio Keaktifan
              </span>
            </div>
            <p className="text-xs text-slate-400 mb-5 leading-relaxed">
              Persentase kehadiran (status Hadir) kumulatif musyrif di asrama masing-masing.
            </p>

            {/* Horizontal Bar Visualizer */}
            <div className="space-y-5">
              {asramaStats.map((item, idx) => {
                // cycle matching colors or high-contrast styles
                const colors = [
                  'from-[#ff2d55] to-[#ff5073]',
                  'from-[#ff9500] to-[#ffaa22]',
                  'from-[#5856d6] to-[#716fdf]',
                ];
                const activeColor = colors[idx % colors.length];

                return (
                  <div key={item.name} className="flex items-center gap-4">
                    <div className="w-28 text-xs font-bold text-slate-700">
                      Asrama {item.name}
                    </div>
                    <div className="flex-1 bg-slate-100 h-5 rounded-lg overflow-hidden relative border border-slate-200/50 shadow-inner">
                      <div 
                        className={`h-full rounded-lg bg-gradient-to-r ${activeColor} transition-all duration-500`}
                        style={{ width: `${item.rate}%` }}
                      />
                      <span className="absolute right-2.5 top-0.5 font-mono text-[10px] font-extrabold text-white mix-blend-difference">
                        {item.rate}%
                      </span>
                    </div>
                    <div className="w-16 text-right font-mono text-[10px] text-slate-400 font-bold">
                      {item.hadir}/{item.total} Lap
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-5 pt-4 border-t border-slate-150 text-right text-[10px] text-slate-400 font-mono leading-relaxed">
            *Laporan per asrama dihitung dari formulir absensi yang dikirim setiap kegiatan harian.
          </div>
        </div>

      </div>

      {/* Grid Row 2: Status Breakdown Donut Gauge & Daily report count bar */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Chart 3: KPI Metrics status donut ratios */}
        <div className="bg-white rounded-2xl p-6 border border-teal-100 shadow-xs lg:col-span-1 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-800 tracking-tight flex items-center gap-1.5 mb-2">
              <CheckCircle className="w-4 h-4 text-emerald-600" />
              RASIO STATUS LAPORAN
            </h3>
            <p className="text-xs text-slate-400 mb-4 font-normal">
              Status kehadiran yang dilaporkan oleh para musyrif asrama.
            </p>

            <div className="flex justify-center my-4 relative">
              {/* Complex circular donut using absolute responsive metrics */}
              <div className="relative w-36 h-36 flex items-center justify-center">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                  {/* Empty circle background */}
                  <circle cx="50" cy="50" r="40" fill="transparent" stroke="#f1f5f9" strokeWidth="12" />
                  
                  {/* Hadir sector */}
                  <circle 
                    cx="50" cy="50" r="40" 
                    fill="transparent" 
                    stroke="#0d9488" 
                    strokeWidth="12" 
                    strokeDasharray="251.2" 
                    strokeDashoffset={251.2 - (251.2 * pctHadir) / 100}
                    strokeLinecap="round"
                  />
                </svg>
                
                <div className="absolute text-center">
                  <span className="block text-2xl font-black text-teal-800 font-sans tracking-tight">{pctHadir}%</span>
                  <span className="block text-[9px] uppercase tracking-wider font-extrabold text-slate-400">HADIR</span>
                </div>
              </div>
            </div>

            {/* List with keys & details */}
            <div className="space-y-2 mt-4 text-xs font-semibold">
              <div className="flex justify-between items-center bg-teal-50 px-3 py-1.5 rounded-xl text-teal-800">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-teal-600 block"></span>
                  Hadir
                </span>
                <span className="font-mono">{statusCounts.Hadir} Laporan ({pctHadir}%)</span>
              </div>
              <div className="flex justify-between items-center bg-rose-50 px-3 py-1.5 rounded-xl text-rose-800">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500 block"></span>
                  Sakit
                </span>
                <span className="font-mono">{statusCounts.Sakit} Laporan ({pctSakit}%)</span>
              </div>
              <div className="flex justify-between items-center bg-amber-50 px-3 py-1.5 rounded-xl text-amber-800">
                <span className="flex items-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500 block"></span>
                  Izin
                </span>
                <span className="font-mono">{statusCounts.Izin} Laporan ({pctIzin}%)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Chart 4: Daily timeline count bars (Replica of requested beautiful diagram) */}
        <div className="bg-white rounded-2xl p-6 border border-teal-100 shadow-xs lg:col-span-2 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-800 tracking-tight flex items-center gap-1.5 mb-2">
              <Activity className="w-4 h-4 text-teal-600" />
              TREN LAPORAN HARIAN (MINGGU INI)
            </h3>
            <p className="text-xs text-slate-400 mb-6 leading-relaxed">
              Jumlah data laporan absensi terkirim secara kumulatif pertanggal hari dalam seminggu.
            </p>

            {/* Legend formatted exactly as requested */}
            <div className="flex gap-2.5 flex-wrap items-center justify-center text-[10px] font-black text-slate-500 mb-6 border-b border-dashed border-slate-100 pb-3 font-sans">
              <span className="uppercase text-slate-400 font-mono tracking-wider">HARIAN:</span>
              <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-[#ff2d55] rounded-full inline-block"></span> Min</span>
              <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-[#ff9500] rounded-full inline-block"></span> Sen</span>
              <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-[#ffcc00] rounded-full inline-block"></span> Sel</span>
              <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-[#34c759] rounded-full inline-block"></span> Rab</span>
              <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-[#5ac8fa] rounded-full inline-block"></span> Kam</span>
              <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-[#5856d6] rounded-full inline-block"></span> Jum</span>
              <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-[#af52de] rounded-full inline-block"></span> Sab</span>
            </div>

            {/* Vertical Bar chart with custom styled coordinates */}
            <div className="flex items-stretch h-56 relative w-full mb-3 pt-4">
              {/* Y Axis Labels */}
              <div className="flex flex-col justify-between text-[11px] font-bold text-slate-400 font-mono pr-3 pb-6 leading-none">
                <span>1,0</span>
                <span>0,8</span>
                <span>0,6</span>
                <span>0,4</span>
                <span>0,2</span>
                <span>0</span>
              </div>

              {/* Chart columns container */}
              <div className="flex-1 relative border-b border-black flex items-end justify-between px-2 pb-0">
                {/* Horizontal grid lines overlay */}
                <div className="absolute inset-0 flex flex-col justify-between pointer-events-none pb-0">
                  <div className="border-t border-slate-100 w-full h-0"></div>
                  <div className="border-t border-slate-100 w-full h-0"></div>
                  <div className="border-t border-slate-100 w-full h-0"></div>
                  <div className="border-t border-slate-100 w-full h-0"></div>
                  <div className="border-t border-slate-100 w-full h-0"></div>
                  <div className="w-full h-0"></div>
                </div>

                {/* Indonesian short day names from user request screenshot */}
                {['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'].map((dayKey) => {
                  // Find full day key to calculate count
                  const fullDayName = dayKey === 'Min' ? 'Minggu' :
                                      dayKey === 'Sen' ? 'Senin' :
                                      dayKey === 'Sel' ? 'Selasa' :
                                      dayKey === 'Rab' ? 'Rabu' :
                                      dayKey === 'Kam' ? 'Kamis' :
                                      dayKey === 'Jum' ? 'Jumat' : 'Sabtu';

                  const count = records.filter((r) => r.hari === fullDayName).length;
                  const maxReportCount = Math.max(...['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'].map(d => records.filter(r => r.hari === d).length), 1);
                  const heightPct = (count / maxReportCount) * 100;
                  
                  // Color codes from user requested visual attachment
                  const colorMap: Record<string, string> = {
                    'Min': '#ff2d55',
                    'Sen': '#ff9500',
                    'Sel': '#ffcc00',
                    'Rab': '#34c759',
                    'Kam': '#5ac8fa',
                    'Jum': '#5856d6',
                    'Sab': '#af52de'
                  };
                  const activeColor = colorMap[dayKey] || '#ff2d55';

                  return (
                    <div key={dayKey} className="flex flex-col items-center flex-1 h-full justify-end group z-10 relative font-sans">
                      {/* Count pill popup on hover */}
                      <span className="absolute -top-10 scale-0 group-hover:scale-100 transition-all duration-200 bg-slate-800 text-white font-mono text-[9px] px-1.5 py-0.5 rounded-md font-bold whitespace-nowrap z-30 shadow-md">
                        {count} Laporan
                      </span>
                      
                      <span className="text-[9px] font-extrabold font-mono mb-1.5" style={{ color: activeColor }}>
                        {Math.round(heightPct)}%
                      </span>
                      
                      <div 
                        className="w-[82%] sm:w-[86%] rounded-t-md sm:rounded-t-xl transition-all duration-300 relative overflow-hidden"
                        style={{ height: `${Math.max(heightPct, 4)}%`, backgroundColor: activeColor }}
                      />
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Labels under bottom border line */}
            <div className="flex pl-10 pr-0">
              {['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'].map((dayKey) => (
                <div key={dayKey} className="flex-1 text-center text-xs font-black text-slate-500 font-sans">
                  {dayKey}
                </div>
              ))}
            </div>

            {/* Calculations for bottom metrics matching layout (e.g. 67%, 34%, 35%) */}
            {(() => {
              const todayStr = new Date().toISOString().split('T')[0];
              const todayRecords = records.filter(r => r.tanggal === todayStr);
              const pctHarian = todayRecords.length > 0
                ? Math.round((todayRecords.filter(r => r.status === 'Hadir').length / todayRecords.length) * 100)
                : 67;

              const sevenDaysAgo = new Date();
              sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
              const weeklyRecords = records.filter(r => new Date(r.tanggal) >= sevenDaysAgo);
              const pctMingguan = weeklyRecords.length > 0
                ? Math.round((weeklyRecords.filter(r => r.status === 'Hadir').length / weeklyRecords.length) * 100)
                : 34;

              const thirtyDaysAgo = new Date();
              thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
              const monthlyRecords = records.filter(r => new Date(r.tanggal) >= thirtyDaysAgo);
              const pctBulanan = monthlyRecords.length > 0
                ? Math.round((monthlyRecords.filter(r => r.status === 'Hadir').length / monthlyRecords.length) * 100)
                : 35;

              return (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-8">
                  {/* HARIAN Card (Teal) */}
                  <div className="bg-[#0f766e] text-white p-5 rounded-2xl flex flex-col justify-between shadow-md border-b-4 border-teal-800 transform hover:scale-[1.01] transition-transform">
                    <div className="text-center">
                      <span className="block text-[11px] font-black tracking-wider uppercase opacity-90">HARIAN</span>
                      <span className="block text-3xl font-extrabold tracking-tight mt-1 font-mono">{pctHarian}%</span>
                    </div>
                    <div className="mt-4 w-full bg-teal-900/60 h-1.5 rounded-full overflow-hidden relative">
                      <div className="bg-yellow-400 h-full rounded-full transition-all duration-500" style={{ width: `${pctHarian}%` }} />
                    </div>
                  </div>

                  {/* MINGGUAN Card (Amber/Gold) */}
                  <div className="bg-[#b45309] text-white p-5 rounded-2xl flex flex-col justify-between shadow-md border-b-4 border-amber-800 transform hover:scale-[1.01] transition-transform">
                    <div className="text-center">
                      <span className="block text-[11px] font-black tracking-wider uppercase opacity-90">MINGGUAN</span>
                      <span className="block text-3xl font-extrabold tracking-tight mt-1 font-mono">{pctMingguan}%</span>
                    </div>
                    <div className="mt-4 w-full bg-amber-900/60 h-1.5 rounded-full overflow-hidden relative">
                      <div className="bg-white h-full rounded-full transition-all duration-500" style={{ width: `${pctMingguan}%` }} />
                    </div>
                  </div>

                  {/* BULANAN Card (Blue/Indigo) */}
                  <div className="bg-[#4338ca] text-white p-5 rounded-2xl flex flex-col justify-between shadow-md border-b-4 border-indigo-950 transform hover:scale-[1.01] transition-transform">
                    <div className="text-center">
                      <span className="block text-[11px] font-black tracking-wider uppercase opacity-90">BULANAN</span>
                      <span className="block text-3xl font-extrabold tracking-tight mt-1 font-mono">{pctBulanan}%</span>
                    </div>
                    <div className="mt-4 w-full bg-indigo-950/60 h-1.5 rounded-full overflow-hidden relative">
                      <div className="bg-emerald-400 h-full rounded-full transition-all duration-500" style={{ width: `${pctBulanan}%` }} />
                    </div>
                  </div>
                </div>
              );
            })()}

          </div>
          
          <div className="mt-6 border-t border-slate-100 pt-3 text-[10px] text-slate-400 flex justify-between items-center font-mono">
            <span>Hari teraktif: <strong className="text-teal-700">Kamis</strong></span>
            <span>Total laporan: <strong className="text-slate-700">{totalReports} kali kirim</strong></span>
          </div>
        </div>

      </div>
    </div>
  );
};
