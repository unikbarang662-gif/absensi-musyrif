/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useAppState } from '../context/AppStateContext';
import { AsramaName } from '../types';
import { ShieldCheck, BookOpen, KeyRound, User, Home, AlertCircle } from 'lucide-react';

export const Login: React.FC = () => {
  const { musyrifs, login, pondokSettings, firebaseError } = useAppState();
  const [role, setRole] = useState<'musyrif' | 'admin'>('musyrif');
  
  // States for Musyrif Login
  const [selectedAsrama, setSelectedAsrama] = useState<AsramaName>('Al Hakim');
  const [selectedName, setSelectedName] = useState<string>('');
  const [musyrifPassword, setMusyrifPassword] = useState<string>('');
  
  // States for Admin Login
  const [adminUsername, setAdminUsername] = useState<string>('admin');
  const [adminPassword, setAdminPassword] = useState<string>('');
  
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Filter musyrifs matching chosen Dormitory
  const filteredMusyrifs = musyrifs.filter((m) => m.asrama === selectedAsrama && m.isActive);

  // Auto select first musyrif when dormitory changes
  React.useEffect(() => {
    if (filteredMusyrifs.length > 0) {
      setSelectedName(filteredMusyrifs[0].name);
    } else {
      setSelectedName('');
    }
  }, [selectedAsrama, musyrifs]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (role === 'admin') {
      if (!adminPassword) {
        setErrorMsg('Harap masukkan password Admin.');
        return;
      }
      const res = login('Admin', 'Admin', adminPassword);
      if (!res.success) {
        setErrorMsg(res.error || 'Password Admin salah!');
      }
    } else {
      if (!selectedName) {
        setErrorMsg('Harap pilih nama Musyrif.');
        return;
      }
      if (!musyrifPassword) {
        setErrorMsg('Harap masukkan password Musyrif.');
        return;
      }
      const res = login(selectedName, selectedAsrama, musyrifPassword);
      if (!res.success) {
        setErrorMsg(res.error || 'Password Musyrif salah!');
      }
    }
  };

  return (
    <div id="login-container" className="min-h-screen bg-slate-50 flex flex-col justify-center items-center p-4">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-xl border border-teal-100/80 overflow-hidden transform transition duration-300 hover:shadow-2xl">
        {/* Banner with Pondok header */}
        <div className="bg-gradient-to-r from-teal-600 to-emerald-600 p-6 text-center text-white relative">
          <div className="absolute top-3 right-3 bg-white/20 backdrop-blur-md px-2.5 py-0.5 rounded-full text-xs font-mono">
            BM v1.0
          </div>
          <div className="mx-auto w-16 h-16 rounded-full bg-white p-1.5 shadow-md flex items-center justify-center mb-3">
            <img 
              src={pondokSettings.logoUrl} 
              alt="Logo Pondok" 
              className="w-full h-full object-cover rounded-full referrerPolicy" 
              referrerPolicy="no-referrer"
              onError={(e) => {
                // Return fallback icon if image fails
                (e.target as HTMLElement).style.display = 'none';
              }}
            />
            <BookOpen className="w-8 h-8 text-teal-600 block" id="fallback-logo-icon" />
          </div>
          <h2 className="text-xl font-bold font-sans tracking-tight leading-6">
            {pondokSettings.namaPondok}
          </h2>
          <p className="text-teal-100 text-xs mt-1 font-mono tracking-wider">
            SISTEM ABSENSI & LAPORAN KEGIATAN MUSYRIF
          </p>
        </div>

        {/* Access Selection Dropdown / Selector */}
        <div className="px-8 pt-6 pb-2 space-y-1.5">
          <label className="text-xs font-bold text-slate-500 uppercase tracking-widest block">
            Pilih akses masuk
          </label>
          <div className="grid grid-cols-2 gap-2 bg-teal-55/40 bg-slate-100 p-1 rounded-xl">
            <button
              id="role-musyrif"
              type="button"
              className={`py-2 text-xs font-bold rounded-lg transition flex items-center justify-center gap-1.5 cursor-pointer ${
                role === 'musyrif'
                  ? 'bg-white text-teal-700 shadow-sm'
                  : 'text-slate-500 hover:text-slate-700'
              }`}
              onClick={() => {
                setRole('musyrif');
                setErrorMsg(null);
              }}
            >
              <User className="w-3.5 h-3.5" />
              Musyrif Asrama
            </button>
            <button
              id="role-admin"
              type="button"
              className={`py-2 text-xs font-bold rounded-lg transition flex items-center justify-center gap-1.5 cursor-pointer ${
                role === 'admin'
                  ? 'bg-white text-teal-700 shadow-sm'
                  : 'text-slate-500 hover:text-slate-700'
              }`}
              onClick={() => {
                setRole('admin');
                setErrorMsg(null);
              }}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              Administrator
            </button>
          </div>
        </div>

        {/* Form area */}
        <form onSubmit={handleSubmit} className="p-8 pt-4 space-y-5">
          {errorMsg && (
            <div className="flex items-start gap-2 bg-rose-50 border border-rose-200 text-rose-700 p-3 rounded-lg text-xs animate-shake">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}



          {role === 'musyrif' ? (
            <>
              {/* Musyrif Form */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-600 flex items-center gap-1">
                  <Home className="w-3.5 h-3.5 text-teal-600" />
                  Pilih Asrama
                </label>
                <select
                  id="login-asrama-select"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 font-medium"
                  value={selectedAsrama}
                  onChange={(e) => setSelectedAsrama(e.target.value as AsramaName)}
                >
                  <option value="Al Hakim">Asrama Al Hakim</option>
                  <option value="Al Fattah">Asrama Al Fattah</option>
                  <option value="Al Karim">Asrama Al Karim</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-600 flex items-center gap-1">
                  <User className="w-3.5 h-3.5 text-teal-600" />
                  Nama Musyrif
                </label>
                {filteredMusyrifs.length > 0 ? (
                  <select
                    id="login-musyrif-select"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 font-semibold"
                    value={selectedName}
                    onChange={(e) => setSelectedName(e.target.value)}
                  >
                    {filteredMusyrifs.map((m) => (
                      <option key={m.id} value={m.name}>
                        {m.name} ({m.kamar})
                      </option>
                    ))}
                  </select>
                ) : (
                  <div className="text-xs text-amber-600 bg-amber-50 p-2.5 rounded-lg font-medium">
                    Tidak ada musyrif aktif di asrama ini.
                  </div>
                )}
              </div>

              <div className="space-y-1">
                <div className="flex justify-between items-center">
                  <label className="text-xs font-semibold text-slate-600 flex items-center gap-1">
                    <KeyRound className="w-3.5 h-3.5 text-teal-600" />
                    Kata Sandi (Password)
                  </label>
                </div>
                <input
                  id="login-musyrif-password"
                  type="password"
                  placeholder="••••••••"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                  value={musyrifPassword}
                  onChange={(e) => setMusyrifPassword(e.target.value)}
                />
              </div>
            </>
          ) : (
            <>
              {/* Admin Form */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-600 flex items-center gap-1">
                  <User className="w-3.5 h-3.5 text-teal-600" />
                  Username Admin
                </label>
                <input
                  id="login-admin-username"
                  type="text"
                  className="w-full px-3.5 py-2.5 bg-slate-100 border border-slate-200 text-slate-500 rounded-xl text-sm focus:outline-none cursor-not-allowed font-semibold"
                  value={adminUsername}
                  disabled
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between items-center">
                  <label className="text-xs font-semibold text-slate-600 flex items-center gap-1">
                    <KeyRound className="w-3.5 h-3.5 text-teal-600" />
                    Kata Sandi Admin
                  </label>
                </div>
                <input
                  id="login-admin-password"
                  type="password"
                  placeholder="••••••••"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                />
              </div>
            </>
          )}

          <button
            id="login-submit-button"
            type="submit"
            className="w-full cursor-pointer py-3 mt-4 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-sm font-bold tracking-wide transition-all duration-200 shadow-md shadow-teal-500/10 hover:shadow-lg hover:shadow-teal-500/20 active:scale-[0.98] flex items-center justify-center gap-2"
          >
            Masuk ke Dashboard
          </button>
        </form>
      </div>
    </div>
  );
};
