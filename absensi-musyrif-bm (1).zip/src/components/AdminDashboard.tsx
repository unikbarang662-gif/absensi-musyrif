/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useAppState } from '../context/AppStateContext';
import { Charts } from './Charts';
import { AsramaName, Musyrif, StatusAbsensi } from '../types';
import { SCHEDULES } from '../data';
import { 
  Users, CalendarDays, FileSpreadsheet, PlusCircle, 
  Settings, MessageSquare, Printer, Trash2, Shield,
  Search, SlidersHorizontal, BookOpen, UserPlus, ToggleLeft, ToggleRight,
  Sparkles, Check, AlertTriangle, ExternalLink, Calendar, Milestone, ClipboardCheck,
  Menu, X, Edit, Eye, Download, FileText, CheckCircle
} from 'lucide-react';
import * as htmlToImage from 'html-to-image';
import { jsPDF } from 'jspdf';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip, Legend, BarChart as RechartsBarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';
import { compressImage } from '../utils/imageCompressor';
import { MusyrifDashboard } from './MusyrifDashboard';

export const AdminDashboard: React.FC = () => {
  const { 
    musyrifs, absensiList, santris, absensiTidurList, absensiMutholaahList, pondokSettings, 
    addMusyrif, updateMusyrif, deleteMusyrif, 
    addSantri, updateSantri, deleteSantri, deleteAbsensiTidur, deleteAbsensiMutholaah,
    deleteAbsensi, updateSettings, deleteKamarMaster, logout,
    firebaseError, isCloudSynced, retrySync, stats, fetchFullAbsensi
  } = useAppState();

  // Custom connection & sync notification simulation states
  const [connectionStatus, setConnectionStatus] = useState<'idle' | 'testing' | 'success'>('idle');
  const [syncStatus, setSyncStatus] = useState<'idle' | 'syncing' | 'success'>('idle');

  const handleTestKoneksi = async () => {
    setConnectionStatus('testing');
    try {
      await retrySync();
      setConnectionStatus('success');
      setTimeout(() => setConnectionStatus('idle'), 3000);
    } catch (e) {
      setConnectionStatus('idle');
    }
  };

  const handleSinkronisasiData = async () => {
    setSyncStatus('syncing');
    try {
      await retrySync();
      setSyncStatus('success');
      setTimeout(() => setSyncStatus('idle'), 3000);
    } catch (e) {
      setSyncStatus('idle');
    }
  };

  // Active Tab State inside Admin panel
  const [activeTab, setActiveTab] = useState<'dashboard' | 'musyrifs' | 'print' | 'whatsapp' | 'settings'>('dashboard');

  // --- Laporan Sub-tabs and States ---
  const [laporanSantriSubTab, setLaporanSantriSubTab] = useState<'keseluruhan' | 'individu'>('keseluruhan');
  const [selectedSantriIdForReport, setSelectedSantriIdForReport] = useState<string>('');
  const [laporanMusyrifSubTab, setLaporanMusyrifSubTab] = useState<'semua' | 'musyrif' | 'mulahid' | 'individu'>('semua');
  const [selectedMusyrifIdForReport, setSelectedMusyrifIdForReport] = useState<string>('');
  const [reportPdfModal, setReportPdfModal] = useState<{ open: boolean; type: 'santri' | 'musyrif' }>({ open: false, type: 'santri' });

  // --- Search & Filters on Laporan Table ---
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [asramaFilter, setAsramaFilter] = useState<string>('Semua');
  const [statusFilter, setStatusFilter] = useState<string>('Semua');
  const [musyrifFilter, setMusyrifFilter] = useState<string>('Semua');
  const [absensiCategory, setAbsensiCategory] = useState<'SEMUA' | 'MUSYRIF' | 'MULAHID' | 'MUTHOLAAH/TIDUR'>('SEMUA');
  const [sortOrder, setSortOrder] = useState<'baru' | 'lama'>('baru');
  
  // Pagination State
  const [currentPage, setCurrentPage] = useState<number>(1);
  const itemsPerPage = 7;

  // --- New Musyrif Form States ---
  const [newNama, setNewNama] = useState<string>('');
  const [newAsrama, setNewAsrama] = useState<AsramaName>('Al Hakim');
  const [newKamar, setNewKamar] = useState<string>('');
  const [newPassword, setNewPassword] = useState<string>('1234');
  const [newPhone, setNewPhone] = useState<string>('');
  const [musyrifFormSuccess, setMusyrifFormSuccess] = useState<boolean>(false);
  const [musyrifFormError, setMusyrifFormError] = useState<string | null>(null);
  const [editingMusyrif, setEditingMusyrif] = useState<any | null>(null);
  const [showRekapanPdfModal, setShowRekapanPdfModal] = useState<boolean>(false);

  // --- Setting Profile Form States ---
  const [pondokName, setPondokName] = useState<string>(pondokSettings.namaPondok);
  const [pondokAlamat, setPondokAlamat] = useState<string>(pondokSettings.alamat);
  const [pondokPengasuh, setPondokPengasuh] = useState<string>(pondokSettings.pengasuh);
  const [pondokKetua, setPondokKetua] = useState<string>(pondokSettings.ketuaPondok);
  const [pondokLogo, setPondokLogo] = useState<string>(pondokSettings.logoUrl);
  const [pondokPengasuhTtd, setPondokPengasuhTtd] = useState<string>(pondokSettings.pengasuhTtdUrl || '');
  const [pondokKetuaTtd, setPondokKetuaTtd] = useState<string>(pondokSettings.ketuaPondokTtdUrl || '');
  const [pondokAnnouncement, setPondokAnnouncement] = useState<string>(pondokSettings.pengumuman || '');
  const [settingSuccess, setSettingSuccess] = useState<boolean>(false);

  React.useEffect(() => {
    if (pondokSettings) {
      setPondokName(pondokSettings.namaPondok || '');
      setPondokAlamat(pondokSettings.alamat || '');
      setPondokPengasuh(pondokSettings.pengasuh || '');
      setPondokKetua(pondokSettings.ketuaPondok || '');
      setPondokLogo(pondokSettings.logoUrl || '');
      setPondokAnnouncement(pondokSettings.pengumuman || '');
      setPondokPengasuhTtd(pondokSettings.pengasuhTtdUrl || '');
      setPondokKetuaTtd(pondokSettings.ketuaPondokTtdUrl || '');
    }
  }, [pondokSettings]);

  // --- Print View Configurations ---
  const [printType, setPrintType] = useState<'asrama' | 'individu'>('asrama');
  const [printSelectedAsrama, setPrintSelectedAsrama] = useState<AsramaName>('Al Hakim');
  const [printSelectedMusyrif, setPrintSelectedMusyrif] = useState<string>('');
  const [showPrintPreview, setShowPrintPreview] = useState<boolean>(false);

  // --- Clock State for Dashboard Header ---
  const [currentTime, setCurrentTime] = useState(new Date());
  React.useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const dateFormatter = new Intl.DateTimeFormat('id-ID', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
  const timeFormatter = new Intl.DateTimeFormat('id-ID', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });
  const dateStrClock = dateFormatter.format(currentTime);
  const timeStrClock = timeFormatter.format(currentTime);

  // Rekapan Data Asrama & Kamar computed list
  const rekapanKamarList = React.useMemo(() => {
    const map: Record<string, { asrama: string; kamar: string; kapasitas: number; terisi: number; musyrifs: string[]; mulahids: string[] }> = {};

    const defaultRooms = pondokSettings?.daftarKamar || [
      'Al Karim - Kamar 101', 'Al Karim - Kamar 102', 'Al Karim - Kamar 103',
      'Al Hakim - Kamar 101', 'Al Hakim - Kamar 102', 'Al Hakim - Kamar 103',
      'Al Fattah - Kamar 101', 'Al Fattah - Kamar 102', 'Al Fattah - Kamar 103'
    ];

    defaultRooms.forEach((rStr) => {
      let asramaName = 'Al Karim';
      let kamarName = rStr;
      if (rStr.includes('-')) {
        const parts = rStr.split('-');
        asramaName = parts[0].trim();
        kamarName = parts[1].trim();
      }
      const key = `${asramaName}__${kamarName}`;
      map[key] = { asrama: asramaName, kamar: kamarName, kapasitas: 30, terisi: 0, musyrifs: [], mulahids: [] };
    });

    santris.forEach((s) => {
      if (s.isActive !== false) {
        const key = `${s.asrama}__${s.kamar}`;
        if (!map[key]) {
          map[key] = { asrama: s.asrama, kamar: s.kamar, kapasitas: 30, terisi: 0, musyrifs: [], mulahids: [] };
        }
        map[key].terisi += 1;
      }
    });

    musyrifs.forEach((m) => {
      if (m.isActive !== false) {
        const key = `${m.asrama}__${m.kamar}`;
        if (!map[key]) {
          map[key] = { asrama: m.asrama, kamar: m.kamar, kapasitas: 30, terisi: 0, musyrifs: [], mulahids: [] };
        }
        map[key].musyrifs.push(m.name);
      }
    });

    return Object.values(map)
      .map(item => ({
        ...item,
        musyrifNames: item.musyrifs.join(', '),
        mulahidNames: item.mulahids.join(', ')
      }))
      .sort((a, b) => a.asrama.localeCompare(b.asrama) || a.kamar.localeCompare(b.kamar));
  }, [santris, musyrifs, pondokSettings]);

  // --- Lightbox / Full Photo Previews ---
  const [lightboxUrl, setLightboxUrl] = useState<string | null>(null);

  // --- Calculate KPI Metrics dynamically ---
  const now = new Date();
  const formatNum = (num: number) => num.toString().padStart(2, '0');
  const dateStrToday = `${now.getFullYear()}-${formatNum(now.getMonth() + 1)}-${formatNum(now.getDate())}`;

  // Reports counts from server-side optimized stats
  const reportsToday = stats.today;
  const reportsThisWeek = stats.week;
  const reportsThisMonth = stats.month;

  // Active check-in staffs
  const activeMusyrifCount = musyrifs.filter((m) => m.isActive).length;

  // Initialize printing states safely
  React.useEffect(() => {
    if (musyrifs.length > 0) {
      setPrintSelectedMusyrif(musyrifs[0].id);
    }
  }, [musyrifs]);

  // Filtering reports
  const filteredReports = absensiList.filter((r) => {
    const matchSearch = 
      r.namaMusyrif.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.kegiatan.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (r.catatan && r.catatan.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchAsrama = asramaFilter === 'Semua' || r.asrama === asramaFilter;
    const matchStatus = statusFilter === 'Semua' || r.status === statusFilter;
    const matchMusyrif = musyrifFilter === 'Semua' || r.musyrifId === musyrifFilter;

    return matchSearch && matchAsrama && matchStatus && matchMusyrif;
  }).sort((a, b) => {
    // Sort chronologically combined by date and time
    const dateTimeA = `${a.tanggal}T${a.waktu}`;
    const dateTimeB = `${b.tanggal}T${b.waktu}`;
    if (sortOrder === 'baru') {
      return dateTimeB.localeCompare(dateTimeA) || b.id.localeCompare(a.id);
    } else {
      return dateTimeA.localeCompare(dateTimeB) || a.id.localeCompare(b.id);
    }
  });

  // Pagination bounds
  const totalPages = Math.ceil(filteredReports.length / itemsPerPage);
  const paginatedReports = filteredReports.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  // --- Handle Adding Musyrif ---
  const handleAddMusyrif = (e: React.FormEvent) => {
    e.preventDefault();
    setMusyrifFormError(null);
    setMusyrifFormSuccess(false);

    if (!newNama.trim()) {
      setMusyrifFormError('Harap isi nama musyrif.');
      return;
    }
    if (!newKamar.trim()) {
      setMusyrifFormError('Harap tentukan nama kamar musyrif.');
      return;
    }

    addMusyrif({
      name: newNama.trim(),
      asrama: newAsrama,
      kamar: newKamar.trim(),
      password: newPassword || '1234',
      phoneNumber: newPhone.trim() || undefined,
    });

    setNewNama('');
    setNewKamar('');
    setNewPhone('');
    setNewPassword('1234');
    setMusyrifFormSuccess(true);
    setTimeout(() => setMusyrifFormSuccess(false), 3000);
  };

  const handlePdfAsrama = () => {
    setPrintType('asrama');
    setShowPrintPreview(false);
    setExpandedZone('print');
  };

  const handlePdfIndividu = () => {
    setPrintType('individu');
    if (musyrifs.length > 0) {
      setPrintSelectedMusyrif(musyrifs[0].id);
    }
    setShowPrintPreview(false);
    setExpandedZone('print');
  };

  // --- Handle Settings Updates ---
  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      namaPondok: pondokName.trim(),
      alamat: pondokAlamat.trim(),
      pengasuh: pondokPengasuh.trim(),
      ketuaPondok: pondokKetua.trim(),
      logoUrl: pondokLogo.trim(),
      pengumuman: pondokAnnouncement.trim(),
      pengasuhTtdUrl: pondokPengasuhTtd.trim(),
      ketuaPondokTtdUrl: pondokKetuaTtd.trim(),
    });
    setSettingSuccess(true);
    setTimeout(() => setSettingSuccess(false), 3000);
  };

  const handleTtdChange = (e: React.ChangeEvent<HTMLInputElement>, target: 'pengasuh' | 'ketua') => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = async (event) => {
        if (event.target?.result) {
          try {
            const rawBase64 = event.target.result as string;
            const compressed = await compressImage(rawBase64, 400, 400, 0.7);
            if (target === 'pengasuh') setPondokPengasuhTtd(compressed);
            else setPondokKetuaTtd(compressed);
          } catch (err) {
            console.error('Error compressing ttd:', err);
            if (target === 'pengasuh') setPondokPengasuhTtd(event.target.result as string);
            else setPondokKetuaTtd(event.target.result as string);
          }
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = async (event) => {
        if (event.target?.result) {
          try {
            const rawBase64 = event.target.result as string;
            // Compress and resize logo to maximum 500px width/height at 80% quality for crisp details
            const compressed = await compressImage(rawBase64, 500, 500, 0.8);
            setPondokLogo(compressed);
          } catch (err) {
            console.error('Error compressing logo:', err);
            setPondokLogo(event.target.result as string); // Fallback
          }
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // --- WhatsApp Reminders Calculations ---
  // Compare who has checked-in vs schedules for today
  const DAYS_INDONESIAN_LOWER = ['minggu', 'senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu'];
  const currentDayName = DAYS_INDONESIAN_LOWER[now.getDay()];
  const activeSchedules = pondokSettings?.schedules || SCHEDULES;
  const todaysSchedules = activeSchedules.filter((s) => s.days.includes(currentDayName));

  // Build a matrix of warnings: which ACTIVE musyrif has NOT checked in for which scheduled activity of today
  const reminderRequiredList: {
    id: string;
    musyrif: Musyrif;
    schedule: any;
    waUrl: string;
  }[] = [];

  musyrifs.filter((m) => m.isActive).forEach((musyrif) => {
    todaysSchedules.forEach((schedule) => {
      // Check if there is an absensi record for this musyrif, this activity, today
      const hasRecord = absensiList.some(
        (r) => 
          r.musyrifId === musyrif.id && 
          r.tanggal === dateStrToday && 
          r.kegiatan.startsWith(schedule.title)
      );

      if (!hasRecord) {
        // Prepare WA Reminder link text
        const waPhone = musyrif.phoneNumber || '6281234567890';
        const rawMessage = `Assalamu'alaikum Wr. Wb. Ust. ${musyrif.name} (${musyrif.asrama}), mengingatkan kembali selaku Musyrif BM untuk segera mengirimkan Laporan Absensi kegiatan [${schedule.title} ⏰ ${schedule.time}] hari ini sebagai disiplin administrasi. Syukron Katsir. - Pengurus ${pondokSettings.namaPondok}`;
        const encodedMessage = encodeURIComponent(rawMessage);
        
        reminderRequiredList.push({
          id: `${musyrif.id}-${schedule.id}`,
          musyrif,
          schedule,
          waUrl: `https://api.whatsapp.com/send?phone=${waPhone}&text=${encodedMessage}`
        });
      }
    });
  });

  // --- PRINT PREVIEW PROCESSOR ---
  const printTitle = printType === 'asrama' 
    ? `Laporan Absensi Kegiatan Musyrif — Asrama ${printSelectedAsrama}`
    : `Laporan Penilaian Musyrif — ${musyrifs.find(m => m.id === printSelectedMusyrif)?.name || 'Individu'}`;

  const printRecords = absensiList.filter((r) => {
    if (printType === 'asrama') {
      return r.asrama === printSelectedAsrama;
    } else {
      return r.musyrifId === printSelectedMusyrif;
    }
  });

  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);

  const triggerPrintWindow = async () => {
    const sheet = document.getElementById('rekap-print-sheet');
    if (!sheet) return;
    
    setIsGeneratingPdf(true);
    try {
      // Temporarily remove max-height and overflow constraints from parent to prevent scroll cutoff issues
      const parent = sheet.parentElement;
      let originalStyles = { maxHeight: '', overflow: '' };
      if (parent) {
        originalStyles = { maxHeight: parent.style.maxHeight, overflow: parent.style.overflow };
        parent.style.maxHeight = 'none';
        parent.style.overflow = 'visible';
      }

      // Small delay to ensure the UI updates
      await new Promise(resolve => setTimeout(resolve, 300));
      
      const width = sheet.scrollWidth;
      const height = sheet.scrollHeight;

      const imgData = await htmlToImage.toPng(sheet, {
        backgroundColor: '#ffffff',
        pixelRatio: 2,
        skipFonts: false,
        width,
        height,
        style: {
           margin: '0',
           padding: '0',
           transform: 'none',
           width: `${width}px`,
           height: `${height}px`
        }
      });
      
      if (parent) {
        parent.style.maxHeight = originalStyles.maxHeight;
        parent.style.overflow = originalStyles.overflow;
      }
      
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });
      
      const imgProps = pdf.getImageProperties(imgData);
      const pdfWidth = pdf.internal.pageSize.getWidth ? pdf.internal.pageSize.getWidth() : pdf.internal.pageSize.width;
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
      const pageHeight = pdf.internal.pageSize.getHeight ? pdf.internal.pageSize.getHeight() : pdf.internal.pageSize.height;
      
      let heightLeft = pdfHeight;
      let position = 0;
      
      pdf.addImage(imgData, 'PNG', 0, position, pdfWidth, pdfHeight);
      heightLeft -= pageHeight;
      
      while (heightLeft > 0) {
        position -= pageHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, pdfWidth, pdfHeight);
        heightLeft -= pageHeight;
      }
      
      pdf.save(`Laporan_${printType}_${new Date().getTime()}.pdf`);
    } catch (e: any) {
      console.error('Error generating PDF:', e);
      setConfirmModal({
        title: 'Ekspor PDF Gagal',
        message: 'Gagal membuat PDF otomatis (' + (e.message || 'Error') + '). Menggunakan dialog cetak bawaan browser...',
        onConfirm: () => {
          window.print();
        },
        isAlert: true
      });
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  const [addSantriMode, setAddSantriMode] = useState<'single' | 'bulk'>('single');
  const [addKegiatanMode, setAddKegiatanMode] = useState<'single' | 'bulk'>('single');
  const [bulkKegiatanText, setBulkKegiatanText] = useState<string>('');
  const [showKegiatanModal, setShowKegiatanModal] = useState(false);
  const [editingKegiatan, setEditingKegiatan] = useState<any | null>(null);
  const [addMusyrifMode, setAddMusyrifMode] = useState<'single' | 'bulk'>('single');
  const [bulkMusyrifText, setBulkMusyrifText] = useState<string>('');

  const [bulkSantriText, setBulkSantriText] = useState<string>('');
  const [santriSearch, setSantriSearch] = useState<string>('');
  const [santriAsramaFilter, setSantriAsramaFilter] = useState<string>('Semua');
  const [santriKamarFilter, setSantriKamarFilter] = useState<string>('');
  const [editingSantri, setEditingSantri] = useState<any | null>(null);
  const [showSantriModal, setShowSantriModal] = useState(false);
  const [showMusyrifModal, setShowMusyrifModal] = useState(false);

  const [santriViewMode, setSantriViewMode] = useState<'table' | 'grouped'>('grouped');

  // Custom confirmation modal state
  const [confirmModal, setConfirmModal] = useState<{
    title: string;
    message: string;
    onConfirm?: () => void | Promise<void>;
    danger?: boolean;
    isAlert?: boolean;
  } | null>(null);

  // Room editing and deletion states & handlers
  const [editingRoom, setEditingRoom] = useState<{ asrama: string; originalKamar: string } | null>(null);
  const [newRoomName, setNewRoomName] = useState<string>('');
  const [deletingRoom, setDeletingRoom] = useState<{ asrama: string; originalKamar: string } | null>(null);

  // Combine all known kamars from musyrifs, santris, and custom daftarKamar in settings
  const allKamarList = Array.from(new Set([
    ...(pondokSettings?.daftarKamar || []),
    ...musyrifs.map(m => m.kamar),
    ...santris.map(s => s.kamar)
  ].map(k => k?.trim()).filter(Boolean))).sort();

  const handleSaveRoomRename = async (asrama: string, originalKamar: string, roomSantris: any[]) => {
    const trimmedVal = newRoomName.trim();
    if (!trimmedVal) {
      setConfirmModal({
        title: 'Input Tidak Valid',
        message: 'Nama kamar tidak boleh kosong.',
        isAlert: true
      });
      return;
    }
    if (trimmedVal === originalKamar) {
      setEditingRoom(null);
      setNewRoomName('');
      return;
    }

    // 1. Update all Santri in this room
    for (const s of roomSantris) {
      await updateSantri(s.id, { kamar: trimmedVal });
    }

    // 2. Update any Musyrif assigned to this room
    const relatedMusyrifs = musyrifs.filter(m => m.asrama === asrama && m.kamar === originalKamar);
    for (const m of relatedMusyrifs) {
      await updateMusyrif(m.id, { kamar: trimmedVal });
    }

    setEditingRoom(null);
    setNewRoomName('');
  };

  const confirmDeleteKamar = async (asrama: string, originalKamar: string, roomSantris: any[]) => {
    // 1. Delete all Santri in this room
    for (const s of roomSantris) {
      await deleteSantri(s.id);
    }

    // 2. Clear kamar field for related Musyrifs
    const relatedMusyrifs = musyrifs.filter(m => m.asrama === asrama && m.kamar === originalKamar);
    for (const m of relatedMusyrifs) {
      await updateMusyrif(m.id, { kamar: '' });
    }

    setDeletingRoom(null);
  };
  
  // Master room list edit states and handlers
  const [editingMasterRoom, setEditingMasterRoom] = useState<string | null>(null);
  const [newMasterRoomName, setNewMasterRoomName] = useState<string>('');

  const handleSaveMasterRoomRename = async (originalRoom: string) => {
    const trimmedVal = newMasterRoomName.trim();
    if (!trimmedVal) {
      setConfirmModal({
        title: 'Input Tidak Valid',
        message: 'Nama kamar tidak boleh kosong.',
        isAlert: true
      });
      return;
    }
    if (trimmedVal === originalRoom) {
      setEditingMasterRoom(null);
      setNewMasterRoomName('');
      return;
    }

    // Check if the target room name already exists
    if (allKamarList.includes(trimmedVal)) {
      setConfirmModal({
        title: 'Kamar Sudah Ada',
        message: 'Nama kamar tersebut sudah ada.',
        isAlert: true
      });
      return;
    }

    // 1. Update all Santri in this room
    const affectedSantris = santris.filter(s => s.kamar === originalRoom);
    for (const s of affectedSantris) {
      await updateSantri(s.id, { kamar: trimmedVal });
    }

    // 2. Update any Musyrif assigned to this room
    const affectedMusyrifs = musyrifs.filter(m => m.kamar === originalRoom);
    for (const m of affectedMusyrifs) {
      await updateMusyrif(m.id, { kamar: trimmedVal });
    }

    // 3. Update the daftarKamar array in Settings
    const currentDaftar = pondokSettings?.daftarKamar || [];
    let updatedDaftar = currentDaftar.map(r => r === originalRoom ? trimmedVal : r);
    
    if (!updatedDaftar.includes(trimmedVal) && currentDaftar.includes(originalRoom)) {
      updatedDaftar.push(trimmedVal);
    } else if (!currentDaftar.includes(originalRoom)) {
      updatedDaftar = Array.from(new Set([...updatedDaftar, trimmedVal]));
    }

    await updateSettings({ daftarKamar: updatedDaftar });
    
    setEditingMasterRoom(null);
    setNewMasterRoomName('');
  };
  
  
  // Expanded collapsible zone state for actions
  const [expandedZone, setExpandedZone] = useState<'musyrifs' | 'whatsapp' | 'print' | 'settings' | 'santri' | 'tidur' | 'mutholaah' | null>(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);

  // Fetch full data if entering report/print zones
  React.useEffect(() => {
    if (expandedZone === 'print' || expandedZone === 'laporan' || expandedZone === 'laporan_santri' || expandedZone === 'laporan_musyrif') {
      fetchFullAbsensi();
    }
  }, [expandedZone]);

  const [previewScale, setPreviewScale] = useState<number>(1);
  const [previewHeight, setPreviewHeight] = useState<number | string>('auto');
  const sheetRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    if (!showPrintPreview) return;
    const updateScale = () => {
      const width = window.innerWidth;
      const padding = window.innerWidth < 640 ? 24 : 64; // padding mobile vs desktop
      const containerMaxWidth = Math.min(800, width - padding);
      const scale = containerMaxWidth / 800;
      setPreviewScale(scale);
      
      if (sheetRef.current) {
        const origHeight = sheetRef.current.offsetHeight;
        setPreviewHeight(origHeight * scale);
      }
    };
    
    // Set delay to let content mount first so height is correct register
    const timer = setTimeout(updateScale, 150);
    
    window.addEventListener('resize', updateScale);
    return () => {
      clearTimeout(timer);
      window.removeEventListener('resize', updateScale);
    };
  }, [showPrintPreview, printType, printSelectedAsrama, printSelectedMusyrif]);

  const handlePrintPdf = () => {
    setShowPrintPreview(true);
  };

  const handleCekWA = () => {
    setExpandedZone('whatsapp');
    setTimeout(() => {
      document.getElementById('expanded-controls-zone')?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  return (
    <div id="admin-dashboard-layout" className="flex flex-col md:flex-row min-h-screen relative print:block bg-slate-50">
      
      {/* Mobile Top App Bar */}
      <div className="md:hidden bg-[#0d5952] text-white p-4 flex flex-shrink-0 items-center justify-between z-30 sticky top-0 shadow-md print:hidden">
        <div className="flex items-center gap-3 overflow-hidden">
          <div className="w-9 h-9 bg-white rounded-full p-0.5 shrink-0">
            <img src={pondokSettings.logoUrl} alt="Logo" className="w-full h-full object-cover rounded-full" />
          </div>
          <div className="min-w-0">
            <h2 className="font-bold text-sm tracking-wide truncate">{pondokSettings.namaPondok}</h2>
            <p className="text-[10px] text-teal-300 uppercase tracking-widest font-mono truncate">Panel Admin</p>
          </div>
        </div>
        <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="p-2 rounded-lg bg-teal-800 hover:bg-teal-700 transition cursor-pointer">
          {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {/* Mobile Overlay Background */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black/40 backdrop-blur-sm z-30 md:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Sidebar for Desktop & Mobile Toggle */}
      <aside className={`
        fixed md:static inset-y-0 left-0 transition-transform duration-300 ease-in-out md:translate-x-0
        ${isMobileMenuOpen ? 'translate-x-0 w-[260px]' : '-translate-x-full w-[260px]'}
        h-screen bg-[#064e3b] text-white flex flex-col z-40 overflow-y-auto
      `}>
        {/* Sidebar Header with Logo */}
        <div className="p-4 flex items-center gap-3 border-b border-[#043b2c] sticky top-0 bg-[#064e3b] z-10 cursor-pointer" onClick={() => setExpandedZone(null)}>
          <div className="w-8 h-8 bg-white/20 rounded flex items-center justify-center shrink-0">
             <span className="text-white text-lg">⚙️</span>
          </div>
          <h2 className="font-extrabold text-white text-sm tracking-wide">Dashboard</h2>
        </div>

        <div className="flex-1 py-4">
          <p className="text-[10px] font-bold text-[#4ade80] px-5 mb-2 tracking-widest uppercase">Data Master</p>
          <div className="space-y-0.5">
            <button
              onClick={() => { setExpandedZone('santri'); setIsMobileMenuOpen(false); }}
              className={`w-full flex items-center gap-3 px-5 py-2.5 transition cursor-pointer text-xs font-medium text-left ${
                expandedZone === 'santri' ? 'bg-[#0f766e] text-white border-l-2 border-emerald-400' : 'text-slate-200 hover:bg-[#0f766e]'
              }`}
            >
               <Users className="w-4 h-4" /> <span>Data Santri & Kamar</span>
            </button>
            <button
              onClick={() => { setExpandedZone('santri'); setIsMobileMenuOpen(false); }}
              className={`w-full flex items-center gap-3 px-5 pl-12 py-2 transition cursor-pointer text-xs font-medium text-left ${expandedZone === 'santri' ? 'text-white font-bold' : 'text-slate-300 hover:text-white'}`}
            >
               <span className="w-1 h-1 bg-slate-400 rounded-full"></span> Data Santri
            </button>
            <button
              onClick={() => { setExpandedZone('musyrifs'); setIsMobileMenuOpen(false); }}
              className={`w-full flex items-center gap-3 px-5 pl-12 py-2 transition cursor-pointer text-xs font-medium text-left ${
                expandedZone === 'musyrifs' ? 'text-white font-bold' : 'text-slate-300 hover:text-white'
              }`}
            >
               <span className="w-1 h-1 bg-slate-400 rounded-full"></span> Data Kamar & Musyrif Kamar
            </button>
            <button
              onClick={() => { setExpandedZone('yatim'); setIsMobileMenuOpen(false); }}
              className={`w-full flex items-center gap-3 px-5 pl-12 py-2 transition cursor-pointer text-xs font-medium text-left ${expandedZone === 'yatim' ? 'text-white font-bold' : 'text-slate-300 hover:text-white'}`}
            >
               <span className="w-1 h-1 bg-slate-400 rounded-full"></span> Santri Yatim/Piatu
            </button>
            <button
              onClick={() => { setExpandedZone('kegiatan'); setIsMobileMenuOpen(false); }}
              className={`w-full flex items-center gap-3 px-5 py-2.5 transition cursor-pointer text-xs font-medium text-left ${expandedZone === 'kegiatan' ? 'bg-[#0f766e] text-white border-l-2 border-emerald-400' : 'text-slate-200 hover:bg-[#0f766e]'} mt-1`}
            >
               <CalendarDays className="w-4 h-4" /> <span>Data Kegiatan</span>
            </button>
          </div>

          <p className="text-[10px] font-bold text-[#4ade80] px-5 mb-2 mt-6 tracking-widest uppercase">Absensi Kegiatan</p>
          <div className="space-y-0.5">
            <button
              onClick={() => { setExpandedZone('kegiatan_musyrif'); setIsMobileMenuOpen(false); }}
              className={`w-full flex items-center justify-between px-5 py-2.5 transition cursor-pointer text-xs font-medium text-left ${expandedZone === 'kegiatan_musyrif' ? 'bg-[#0f766e] text-white border-l-2 border-emerald-400' : 'text-slate-200 hover:bg-[#0f766e]'}`}
            >
               <div className="flex items-center gap-3"><ClipboardCheck className="w-4 h-4" /> <span>Absensi Kegiatan Musyrif</span></div>
               <span className="text-slate-400">›</span>
            </button>
            <button
              onClick={() => { setExpandedZone('mutholaah'); setIsMobileMenuOpen(false); }}
              className={`w-full flex items-center justify-between px-5 py-2.5 transition cursor-pointer text-xs font-medium text-left ${
                expandedZone === 'mutholaah' ? 'bg-[#0f766e] text-white border-l-2 border-emerald-400' : 'text-slate-200 hover:bg-[#0f766e]'
              }`}
            >
               <div className="flex items-center gap-3"><BookOpen className="w-4 h-4" /> <span>Absensi Muthola'ah</span></div>
               <span className="text-slate-400">›</span>
            </button>
            <button
              onClick={() => { setExpandedZone('tidur'); setIsMobileMenuOpen(false); }}
              className={`w-full flex items-center justify-between px-5 py-2.5 transition cursor-pointer text-xs font-medium text-left ${
                expandedZone === 'tidur' ? 'bg-[#0f766e] text-white border-l-2 border-emerald-400' : 'text-slate-200 hover:bg-[#0f766e]'
              }`}
            >
               <div className="flex items-center gap-3"><span className="text-sm">🌙</span> <span>Absensi Tidur Malam</span></div>
               <span className="text-slate-400">›</span>
            </button>
          </div>

          <p className="text-[10px] font-bold text-[#4ade80] px-5 mb-2 mt-6 tracking-widest uppercase">Laporan</p>
          <div className="space-y-0.5">
            <button
              onClick={() => { setExpandedZone('laporan_santri'); setIsMobileMenuOpen(false); }}
              className={`w-full flex items-center justify-between px-5 py-2.5 transition cursor-pointer text-xs font-medium text-left ${
                expandedZone === 'laporan' || expandedZone === 'laporan_santri' || expandedZone === 'laporan_musyrif' 
                  ? 'bg-[#0f766e] text-white border-l-2 border-emerald-400' 
                  : 'text-slate-200 hover:bg-[#0f766e]'
              }`}
            >
               <div className="flex items-center gap-3"><FileSpreadsheet className="w-4 h-4" /> <span>Laporan Absensi</span></div>
               <span className="text-slate-400">›</span>
            </button>
            <button
              onClick={() => { setExpandedZone('laporan_santri'); setIsMobileMenuOpen(false); }}
              className={`w-full flex items-center gap-3 px-5 pl-12 py-2 transition cursor-pointer text-xs font-medium text-left ${
                expandedZone === 'laporan_santri' || expandedZone === 'laporan' ? 'text-white font-bold' : 'text-slate-300 hover:text-white'
              }`}
            >
               <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full"></span> Laporan Santri
            </button>
            <button
              onClick={() => { setExpandedZone('laporan_musyrif'); setIsMobileMenuOpen(false); }}
              className={`w-full flex items-center gap-3 px-5 pl-12 py-2 transition cursor-pointer text-xs font-medium text-left ${
                expandedZone === 'laporan_musyrif' ? 'text-white font-bold' : 'text-slate-300 hover:text-white'
              }`}
            >
               <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full"></span> Laporan Musyrif
            </button>
            <button
              onClick={() => { setExpandedZone('settings'); setIsMobileMenuOpen(false); }}
              className={`w-full flex items-center justify-between px-5 py-2.5 transition cursor-pointer text-xs font-medium text-left ${
                expandedZone === 'settings' ? 'bg-[#0f766e] text-white border-l-2 border-emerald-400' : 'text-slate-200 hover:bg-[#0f766e]'
              }`}
            >
               <div className="flex items-center gap-3"><Settings className="w-4 h-4" /> <span>Pengaturan</span></div>
               <span className="text-slate-400">›</span>
            </button>
          </div>
          
          <div className="mt-8 border-t border-[#043b2c] pt-4 space-y-0.5">
            <button
              onClick={logout}
              className="w-full flex items-center gap-3 px-5 py-2.5 transition cursor-pointer text-xs font-medium text-left text-red-300 hover:bg-red-500/20"
            >
               <span className="text-sm">🚪</span> <span>Keluar (Logout)</span>
            </button>
          </div>
        </div>
      </aside>
      {/* Main Content Area */}
      <div className={`flex-1 w-full max-w-full overflow-x-hidden p-4 sm:p-6 lg:p-8 space-y-6 ${showPrintPreview ? 'print:hidden' : ''}`}>
        
        {/* Sleek sub-page breadcrumb / navigation bar when a specific menu feature is active */}
        {expandedZone && (
          <div className="flex items-center justify-between mb-2 print:hidden animate-fade-in border-b border-teal-600/10 pb-3">
            <button 
              onClick={() => setExpandedZone(null)}
              className="flex items-center gap-1.5 text-xs font-bold text-teal-700 bg-white hover:bg-slate-50 px-4 py-2 rounded-xl border border-teal-200/50 shadow-xs hover:shadow-sm transition cursor-pointer"
            >
              <span className="text-sm">🏠</span> Kembali ke Dashboard Utama
            </button>
            <span className="text-[10px] text-teal-700 bg-teal-50 px-3 py-1 rounded-full font-bold uppercase tracking-wider border border-teal-200/30">
              {expandedZone === 'musyrifs' ? '👥 Kelola Akun Musyrif' : 
               expandedZone === 'santri' ? '🧑‍🎓 Kelola Data Santri' :
               expandedZone === 'tidur' ? '🛏️ Laporan Tidur' :
               expandedZone === 'mutholaah' ? '📖 Laporan Mutholaah' :
               expandedZone === 'whatsapp' ? '🔔 Pengingat WhatsApp' :
               expandedZone === 'print' ? '📊 Lap. PDF Laporan' :
               expandedZone === 'settings' ? '⚙️ Profil Lembaga' : 
               expandedZone === 'kegiatan_musyrif' ? '📋 Absensi Kegiatan Musyrif' :
               expandedZone === 'laporan_santri' || expandedZone === 'laporan' ? '📊 Laporan Absensi Santri' :
               expandedZone === 'laporan_musyrif' ? '📊 Laporan Absensi & Kinerja Asatidz' : ''}
            </span>
          </div>
        )}

                {!expandedZone && (
          <div className="space-y-6">

            
            {/* Dashboard Header matching screenshot */}
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white p-6 rounded-xl border border-slate-100 shadow-sm print:hidden">
              <div>
                <h1 className="text-3xl font-black text-[#0B4A3F] tracking-tight">DASHBOARD</h1>
                <p className="text-slate-500 text-sm mt-1">Selamat datang di Sistem Manajemen Musyrif Pondok Pesantren Bahrul Maghfiroh</p>
              </div>
              <div className="flex items-center gap-6">
                <div className="bg-slate-50 border border-slate-100 px-4 py-2 rounded-xl flex items-center gap-3">
                  <Calendar className="w-5 h-5 text-slate-400" />
                  <div>
                    <p className="text-sm font-bold text-slate-800">{dateStrClock.split(',')[0]}, {dateStrClock.split(',')[1]}</p>
                    <p className="text-[10px] text-slate-500">11 Muharram 1448 H</p>
                    <p className="text-[10px] font-bold text-emerald-700 uppercase mt-0.5">PONPES BAHRUL MAGHFIROH</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-blue-400 text-white flex items-center justify-center font-bold">
                    AD
                  </div>
                  <div>
                    <p className="text-sm font-bold text-slate-800">admin</p>
                    <p className="text-[10px] text-slate-500 uppercase">Administrator</p>
                  </div>
                </div>
              </div>
            </div>

            {/* 7 Colorful Stats Cards matching screenshot */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 print:hidden">
              {/* TOTAL SANTRI */}
              <div className="bg-[#1DD1a1] text-white p-5 rounded-xl flex flex-col justify-between shadow-sm relative overflow-hidden">
                <div className="flex items-start justify-between">
                  <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center shrink-0">
                    <Users className="w-5 h-5" />
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] font-bold uppercase tracking-wider mb-1">TOTAL SANTRI</p>
                    <h3 className="text-3xl font-black leading-none">{santris.length}</h3>
                  </div>
                </div>
                <p className="text-xs mt-2 text-white/90">Santri</p>
              </div>
              
              {/* TOTAL MUSYRIF */}
              <div className="bg-[#3B82F6] text-white p-5 rounded-xl flex flex-col justify-between shadow-sm relative overflow-hidden">
                <div className="flex items-start justify-between">
                  <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center shrink-0">
                    <Users className="w-5 h-5" />
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] font-bold uppercase tracking-wider mb-1">TOTAL MUSYRIF</p>
                    <h3 className="text-3xl font-black leading-none">{musyrifs.length}</h3>
                  </div>
                </div>
                <p className="text-xs mt-2 text-white/90">Musyrif Aktif</p>
              </div>

              {/* TOTAL MULAHID */}
              <div className="bg-[#8B5CF6] text-white p-5 rounded-xl flex flex-col justify-between shadow-sm relative overflow-hidden">
                <div className="flex items-start justify-between">
                  <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center shrink-0">
                    <Users className="w-5 h-5" />
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] font-bold uppercase tracking-wider mb-1">TOTAL MULAHID</p>
                    <h3 className="text-3xl font-black leading-none">0</h3>
                  </div>
                </div>
                <p className="text-xs mt-2 text-white/90">Mulahid Aktif</p>
              </div>

              {/* TOTAL KAMAR */}
              <div className="bg-[#F97316] text-white p-5 rounded-xl flex flex-col justify-between shadow-sm relative overflow-hidden">
                <div className="flex items-start justify-between">
                  <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center shrink-0">
                    <span className="text-lg">🏠</span>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] font-bold uppercase tracking-wider mb-1">TOTAL KAMAR</p>
                    <h3 className="text-3xl font-black leading-none">{Array.from(new Set(santris.map(s => s.kamar))).length}</h3>
                  </div>
                </div>
                <p className="text-xs mt-2 text-white/90">Kamar</p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 print:hidden">
              {/* KEGIATAN HARI INI */}
              <div className="bg-[#A78BFA] text-white p-5 rounded-xl flex flex-col justify-between shadow-sm relative overflow-hidden">
                <div className="flex items-start justify-between">
                  <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center shrink-0">
                    <ClipboardCheck className="w-5 h-5" />
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] font-bold uppercase tracking-wider mb-1">KEGIATAN HARI INI</p>
                    <h3 className="text-3xl font-black leading-none">{reportsToday}</h3>
                  </div>
                </div>
                <p className="text-xs mt-2 text-white/90">Kegiatan</p>
              </div>

              {/* TOTAL LAPORAN */}
              <div className="bg-[#14B8A6] text-white p-5 rounded-xl flex flex-col justify-between shadow-sm relative overflow-hidden">
                <div className="flex items-start justify-between">
                  <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center shrink-0">
                    <FileSpreadsheet className="w-5 h-5" />
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] font-bold uppercase tracking-wider mb-1">TOTAL LAPORAN</p>
                    <h3 className="text-3xl font-black leading-none">{absensiList.length + absensiTidurList.length + absensiMutholaahList.length}</h3>
                  </div>
                </div>
                <p className="text-xs mt-2 text-white/90">Laporan</p>
              </div>

              {/* TINGKAT KEHADIRAN */}
              <div className="bg-[#F43F5E] text-white p-5 rounded-xl flex flex-col justify-between shadow-sm relative overflow-hidden">
                <div className="flex items-start justify-between">
                  <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center shrink-0">
                    <span className="text-lg">📊</span>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] font-bold uppercase tracking-wider mb-1">TINGKAT KEHADIRAN</p>
                    <h3 className="text-3xl font-black leading-none">
                      {
                        (absensiList.length + absensiTidurList.length + absensiMutholaahList.length) > 0 
                        ? Math.round(((absensiList.filter(r => r.status === 'Hadir').length + absensiTidurList.filter(r => r.status === 'Hadir' || r.status === 'Hadir dikamar').length + absensiMutholaahList.filter(r => r.status === 'Hadir' || r.status === 'Hadir Mutholaah').length) / (absensiList.length + absensiTidurList.length + absensiMutholaahList.length)) * 100)
                        : 0
                      }%
                    </h3>
                  </div>
                </div>
                <p className="text-xs mt-2 text-white/90">Rata-rata</p>
              </div>
            </div>

            {/* Charts Area matching Image 1 - Placed above Rekapan & Semua Data Absensi */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 print:hidden">
              {/* Donut Chart Card */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
                <div className="flex items-start gap-3 mb-2">
                  <div className="w-7 h-7 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                    <Check className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-xs text-slate-800 uppercase tracking-wide">Rasio Status Laporan</h3>
                    <p className="text-[11px] text-slate-500 mt-0.5">Status kehadiran yang dilaporkan oleh para musyrif asrama.</p>
                  </div>
                </div>
                <div className="flex-1 flex flex-col items-center justify-center relative py-2">
                   <div className="w-40 h-40">
                     <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                             data={[
                               { name: 'Hadir', value: (absensiList.filter(r => r.status === 'Hadir').length + absensiTidurList.filter(r => r.status === 'Hadir' || r.status === 'Hadir dikamar').length + absensiMutholaahList.filter(r => r.status === 'Hadir' || r.status === 'Hadir Mutholaah').length) || 1, color: '#10b981' },
                             ]}
                            dataKey="value"
                            nameKey="name"
                            cx="50%"
                            cy="50%"
                            innerRadius={58}
                            outerRadius={76}
                            stroke="none"
                          >
                            <Cell key="cell-0" fill="#10b981" />
                          </Pie>
                        </PieChart>
                     </ResponsiveContainer>
                   </div>
                   <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none mt-2">
                      <h2 className="text-xl font-black text-emerald-600">
                        {
                          (absensiList.length + absensiTidurList.length + absensiMutholaahList.length) > 0 
                          ? Math.round(((absensiList.filter(r => r.status === 'Hadir').length + absensiTidurList.filter(r => r.status === 'Hadir' || r.status === 'Hadir dikamar').length + absensiMutholaahList.filter(r => r.status === 'Hadir' || r.status === 'Hadir Mutholaah').length) / (absensiList.length + absensiTidurList.length + absensiMutholaahList.length)) * 100)
                          : 100
                        }%
                      </h2>
                      <span className="text-[9px] font-black text-slate-400 uppercase tracking-wider">HADIR</span>
                   </div>
                </div>
                <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                   <div className="flex items-center gap-2">
                     <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                     <span className="text-xs font-extrabold text-slate-700">Hadir</span>
                   </div>
                   <span className="text-xs font-black text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-md">100%</span>
                </div>
              </div>

              {/* Bar Chart Card */}
              <div className="lg:col-span-2 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
                <div className="flex items-start gap-3 mb-2">
                  <div className="w-7 h-7 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                    <span className="text-sm">📊</span>
                  </div>
                  <div>
                    <h3 className="font-extrabold text-xs text-slate-800 uppercase tracking-wide">Tren Laporan Harian (Minggu Ini)</h3>
                    <p className="text-[11px] text-slate-500 mt-0.5">Jumlah data laporan absensi terkirim secara kumulatif pertanggal hari dalam seminggu.</p>
                  </div>
                </div>

                <div className="flex items-center gap-2 bg-slate-50 py-1 px-2.5 rounded-lg w-max border border-slate-100 my-1">
                  <span className="text-[10px] font-black text-slate-700 mr-1 uppercase">HARIAN:</span>
                  <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-[#EF4444]"></div><span className="text-[9px] font-extrabold text-slate-600">MIN</span></div>
                  <div className="flex items-center gap-1 ml-1"><div className="w-2 h-2 rounded-full bg-[#F97316]"></div><span className="text-[9px] font-extrabold text-slate-600">SEN</span></div>
                  <div className="flex items-center gap-1 ml-1"><div className="w-2 h-2 rounded-full bg-[#EAB308]"></div><span className="text-[9px] font-extrabold text-slate-600">SEL</span></div>
                  <div className="flex items-center gap-1 ml-1"><div className="w-2 h-2 rounded-full bg-[#10B981]"></div><span className="text-[9px] font-extrabold text-slate-600">RAB</span></div>
                  <div className="flex items-center gap-1 ml-1"><div className="w-2 h-2 rounded-full bg-[#0EA5E9]"></div><span className="text-[9px] font-extrabold text-slate-600">KAM</span></div>
                  <div className="flex items-center gap-1 ml-1"><div className="w-2 h-2 rounded-full bg-[#6366F1]"></div><span className="text-[9px] font-extrabold text-slate-600">JUM</span></div>
                  <div className="flex items-center gap-1 ml-1"><div className="w-2 h-2 rounded-full bg-[#A855F7]"></div><span className="text-[9px] font-extrabold text-slate-600">SAB</span></div>
                </div>

                <div className="h-44 w-full pt-2">
                  <ResponsiveContainer width="100%" height="100%">
                    <RechartsBarChart data={[
                      { name: 'MIN', value: (absensiList.filter(r => r.hari === 'Minggu').length + absensiTidurList.filter(r => r.hari === 'Minggu').length + absensiMutholaahList.filter(r => r.hari === 'Minggu').length), fill: '#EF4444' },
                      { name: 'SEN', value: (absensiList.filter(r => r.hari === 'Senin').length + absensiTidurList.filter(r => r.hari === 'Senin').length + absensiMutholaahList.filter(r => r.hari === 'Senin').length), fill: '#F97316' },
                      { name: 'SEL', value: (absensiList.filter(r => r.hari === 'Selasa').length + absensiTidurList.filter(r => r.hari === 'Selasa').length + absensiMutholaahList.filter(r => r.hari === 'Selasa').length), fill: '#EAB308' },
                      { name: 'RAB', value: (absensiList.filter(r => r.hari === 'Rabu').length + absensiTidurList.filter(r => r.hari === 'Rabu').length + absensiMutholaahList.filter(r => r.hari === 'Rabu').length), fill: '#10B981' },
                      { name: 'KAM', value: (absensiList.filter(r => r.hari === 'Kamis').length + absensiTidurList.filter(r => r.hari === 'Kamis').length + absensiMutholaahList.filter(r => r.hari === 'Kamis').length), fill: '#0EA5E9' },
                      { name: 'JUM', value: (absensiList.filter(r => r.hari === 'Jumat').length + absensiTidurList.filter(r => r.hari === 'Jumat').length + absensiMutholaahList.filter(r => r.hari === 'Jumat').length), fill: '#6366F1' },
                      { name: 'SAB', value: (absensiList.filter(r => r.hari === 'Sabtu').length + absensiTidurList.filter(r => r.hari === 'Sabtu').length + absensiMutholaahList.filter(r => r.hari === 'Sabtu').length), fill: '#A855F7' }
                    ]}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#F1F5F9" />
                      <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#64748B', fontWeight: 'bold' }} dy={5} />
                      <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#64748B' }} dx={-5} />
                      <RechartsTooltip cursor={{ fill: 'transparent' }} contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)', fontWeight: 'bold', fontSize: '11px' }} />
                      <Bar dataKey="value" radius={[4, 4, 0, 0]} barSize={32}>
                        {
                          [
                            { name: 'MIN', fill: '#EF4444' },
                            { name: 'SEN', fill: '#F97316' },
                            { name: 'SEL', fill: '#EAB308' },
                            { name: 'RAB', fill: '#10B981' },
                            { name: 'KAM', fill: '#0EA5E9' },
                            { name: 'JUM', fill: '#6366F1' },
                            { name: 'SAB', fill: '#A855F7' }
                          ].map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.fill} />
                          ))
                        }
                      </Bar>
                    </RechartsBarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>

            {/* REKAPAN DATA ASRAMA & KAMAR SECTION - Placed Above SEMUA DATA ABSENSI */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden print:hidden mt-4">
              <div className="p-3.5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50/70">
                <div>
                  <h2 className="text-sm font-black text-[#0B4A3F] uppercase tracking-wide flex items-center gap-2">
                    <span>🏢</span> REKAPAN DATA ASRAMA & KAMAR
                  </h2>
                  <p className="text-[11px] text-slate-500 font-medium mt-0.5">
                    Ringkasan kapasitas, keterisian santri, dan musyrif penanggung jawab per kamar
                  </p>
                </div>
                
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => setShowRekapanPdfModal(true)}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-[11px] px-3 py-1.5 rounded-xl transition shadow-xs flex items-center gap-1.5 cursor-pointer active:scale-95"
                  >
                    <Printer className="w-3.5 h-3.5" /> Pratinjau PDF
                  </button>
                  <button
                    onClick={async () => {
                      const element = document.getElementById('rekapan-asrama-kamar-table');
                      if (!element) return;
                      try {
                        const dataUrl = await htmlToImage.toPng(element, { quality: 0.95, backgroundColor: '#ffffff' });
                        const pdf = new jsPDF('landscape', 'mm', 'a4');
                        const imgProps = pdf.getImageProperties(dataUrl);
                        const pdfWidth = pdf.internal.pageSize.getWidth();
                        const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
                        pdf.addImage(dataUrl, 'PNG', 0, 10, pdfWidth, pdfHeight);
                        pdf.save('Rekapan_Data_Asrama_dan_Kamar.pdf');
                      } catch (err) {
                        console.error('PDF error', err);
                      }
                    }}
                    className="bg-[#0B4A3F] hover:bg-teal-900 text-white font-extrabold text-[11px] px-3 py-1.5 rounded-xl transition shadow-xs flex items-center gap-1.5 cursor-pointer active:scale-95"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5" /> Download PDF
                  </button>
                </div>
              </div>

              <div id="rekapan-asrama-kamar-table" className="p-3 bg-white">
                <div className="overflow-x-auto max-h-[280px] overflow-y-auto border border-slate-200 rounded-xl">
                  <table className="w-full text-left text-xs border-collapse min-w-[700px]">
                    <thead>
                      <tr className="bg-emerald-950 text-white font-black text-[10px] uppercase tracking-wider sticky top-0 z-10 shadow-xs">
                        <th className="py-2.5 px-3 text-center w-10 border-b border-emerald-900">NO</th>
                        <th className="py-2.5 px-3.5 border-b border-emerald-900">NAMA ASRAMA</th>
                        <th className="py-2.5 px-3.5 border-b border-emerald-900">NAMA KAMAR</th>
                        <th className="py-2.5 px-3 text-center border-b border-emerald-900">KAPASITAS</th>
                        <th className="py-2.5 px-3 text-center border-b border-emerald-900">TERISI</th>
                        <th className="py-2.5 px-3.5 border-b border-emerald-900">MUSYRIF KAMAR</th>
                        <th className="py-2.5 px-3.5 border-b border-emerald-900">MULAHID</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                      {rekapanKamarList.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="text-center py-5 text-slate-400 font-bold text-xs">
                            Belum ada data kamar terdaftar.
                          </td>
                        </tr>
                      ) : (
                        rekapanKamarList.map((item, idx) => (
                          <tr key={`${item.asrama}-${item.kamar}-${idx}`} className="hover:bg-amber-50/20 transition">
                            <td className="py-2 px-3 text-center font-mono font-bold text-slate-400">{idx + 1}</td>
                            <td className="py-2 px-3.5 font-extrabold text-emerald-900">{item.asrama}</td>
                            <td className="py-2 px-3.5 font-bold text-slate-800">
                              <span className="bg-slate-100 px-2 py-0.5 rounded-md font-mono text-[11px] text-slate-700">{item.kamar}</span>
                            </td>
                            <td className="py-2 px-3 text-center font-extrabold text-slate-700">{item.kapasitas}</td>
                            <td className="py-2 px-3 text-center font-extrabold">
                              <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono ${
                                item.terisi > item.kapasitas ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800'
                              }`}>
                                {item.terisi} santri
                              </span>
                            </td>
                            <td className="py-2 px-3.5 font-medium text-slate-700">
                              {item.musyrifNames || <span className="text-slate-400 italic">Belum ditentukan</span>}
                            </td>
                            <td className="py-2 px-3.5 font-medium text-slate-700">
                              {item.mulahidNames || <span className="text-slate-400 italic">Belum ditentukan</span>}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            {/* SEMUA DATA ABSENSI Table matching screenshot */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden print:hidden mt-4">
              <div className="p-3.5 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-3">
                <div>
                  <h2 className="text-sm font-black text-[#0B4A3F] uppercase tracking-wide">SEMUA DATA ABSENSI</h2>
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    <button 
                      onClick={() => setAbsensiCategory('SEMUA')} 
                      className={`px-3 py-1 rounded-md text-[11px] font-extrabold transition cursor-pointer ${absensiCategory === 'SEMUA' ? 'bg-[#0B4A3F] text-white shadow-xs' : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'}`}
                    >
                      SEMUA
                    </button>
                    <button 
                      onClick={() => setAbsensiCategory('MUSYRIF')} 
                      className={`px-3 py-1 rounded-md text-[11px] font-extrabold transition cursor-pointer ${absensiCategory === 'MUSYRIF' ? 'bg-[#0B4A3F] text-white shadow-xs' : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'}`}
                    >
                      MUSYRIF
                    </button>
                    <button 
                      onClick={() => setAbsensiCategory('MULAHID')} 
                      className={`px-3 py-1 rounded-md text-[11px] font-extrabold transition cursor-pointer ${absensiCategory === 'MULAHID' ? 'bg-[#0B4A3F] text-white shadow-xs' : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'}`}
                    >
                      MULAHID
                    </button>
                    <button 
                      onClick={() => setAbsensiCategory('MUTHOLAAH/TIDUR')} 
                      className={`px-3 py-1 rounded-md text-[11px] font-extrabold transition cursor-pointer ${absensiCategory === 'MUTHOLAAH/TIDUR' ? 'bg-[#0B4A3F] text-white shadow-xs' : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'}`}
                    >
                      MUTHOLAAH/TIDUR
                    </button>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2" />
                    <input
                      type="text"
                      placeholder="PENCARIAN"
                      className="w-44 bg-white border border-slate-200 rounded-lg py-1.5 pl-8 pr-2.5 text-xs focus:outline-none focus:ring-1 focus:ring-[#0B4A3F] font-bold"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                  <button 
                    onClick={() => {
                      const combined = [
                        ...absensiList.map(r => {
                          const mus = musyrifs.find(m => m.id === r.musyrifId);
                          return {
                            ...r,
                            type: 'Kegiatan',
                            pelaporName: mus?.name || r.namaMusyrif || 'Musyrif',
                            asramaName: r.asrama || mus?.asrama || 'Al Hakim',
                            role: 'MUSYRIF',
                            kegiatanTitle: r.kegiatan || 'Kegiatan'
                          };
                        }),
                        ...absensiTidurList.map(r => {
                          const mus = musyrifs.find(m => m.id === r.musyrifId);
                          return {
                            ...r,
                            type: 'Tidur',
                            pelaporName: mus?.name || (r as any).musyrifName || 'Musyrif/Admin',
                            asramaName: r.asrama || mus?.asrama || 'Al Hakim',
                            role: 'MUTHOLAAH/TIDUR',
                            kegiatanTitle: 'Absensi Tidur Malam'
                          };
                        }),
                        ...absensiMutholaahList.map(r => {
                          const mus = musyrifs.find(m => m.id === r.musyrifId);
                          return {
                            ...r,
                            type: 'Mutholaah',
                            pelaporName: mus?.name || (r as any).musyrifName || 'Musyrif/Admin',
                            asramaName: r.asrama || mus?.asrama || 'Al Hakim',
                            role: 'MUTHOLAAH/TIDUR',
                            kegiatanTitle: 'Absensi Muthola\'ah Santri'
                          };
                        })
                      ];
                      
                      const filtered = combined.filter(r => {
                        if (absensiCategory === 'MUSYRIF' && r.type !== 'Kegiatan') return false;
                        if (absensiCategory === 'MULAHID' && !r.pelaporName.toLowerCase().includes('mulahid')) return false;
                        if (absensiCategory === 'MUTHOLAAH/TIDUR' && r.type !== 'Mutholaah' && r.type !== 'Tidur') return false;
                        if (!searchTerm.trim()) return true;
                        const q = searchTerm.toLowerCase();
                        return (
                          (r.kegiatanTitle && r.kegiatanTitle.toLowerCase().includes(q)) ||
                          (r.pelaporName && r.pelaporName.toLowerCase().includes(q)) ||
                          (r.asramaName && r.asramaName.toLowerCase().includes(q)) ||
                          (r.status && r.status.toLowerCase().includes(q))
                        );
                      });

                      const headers = ['No', 'Tanggal', 'Waktu', 'Nama Pelapor', 'Asrama', 'Kegiatan', 'Status'];
                      const rows = filtered.map((r, i) => [
                        i + 1,
                        `"${r.tanggal || ''}"`,
                        `"${r.waktu || ''}"`,
                        `"${r.pelaporName || ''}"`,
                        `"${r.asramaName || ''}"`,
                        `"${r.kegiatanTitle || ''}"`,
                        `"${r.status || ''}"`
                      ]);
                      const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
                      const encodedUri = encodeURI(csvContent);
                      const link = document.createElement('a');
                      link.setAttribute('href', encodedUri);
                      link.setAttribute('download', `data_absensi_${new Date().toISOString().slice(0, 10)}.csv`);
                      document.body.appendChild(link);
                      link.click();
                      document.body.removeChild(link);
                    }}
                    title="Download CSV" 
                    className="bg-[#0B4A3F] text-white p-2 rounded-lg hover:bg-[#064e3b] transition flex items-center justify-center cursor-pointer shadow-xs"
                  >
                    <span className="text-xs">📥</span>
                  </button>
                </div>
              </div>

              {/* Scrollable table container */}
              <div className="max-h-[300px] overflow-y-auto overflow-x-auto border-t border-slate-100">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="sticky top-0 z-10 bg-[#0B4A3F] text-white uppercase text-[10px] font-bold tracking-wider shadow-xs">
                    <tr>
                      <th className="py-2.5 px-3 text-center w-10 bg-[#0B4A3F]">NO</th>
                      <th className="py-2.5 px-3.5 bg-[#0B4A3F]">WAKTU LAPOR</th>
                      <th className="py-2.5 px-3.5 bg-[#0B4A3F]">NAMA PELAPOR (ASRAMA)</th>
                      <th className="py-2.5 px-3.5 bg-[#0B4A3F]">NAMA KEGIATAN</th>
                      <th className="py-2.5 px-3 text-center bg-[#0B4A3F]">FOTO BUKTI</th>
                      <th className="py-2.5 px-3 text-center bg-[#0B4A3F]">STATUS</th>
                      <th className="py-2.5 px-3 text-center bg-[#0B4A3F]">TINDAKAN</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 bg-white">
                    {(() => {
                      const combined = [
                        ...absensiList.map(r => {
                          const mus = musyrifs.find(m => m.id === r.musyrifId);
                          return {
                            ...r,
                            type: 'Kegiatan',
                            pelaporName: mus?.name || r.namaMusyrif || 'Musyrif',
                            asramaName: r.asrama || mus?.asrama || 'Al Hakim',
                            role: 'MUSYRIF',
                            kegiatanTitle: r.kegiatan || 'Kegiatan',
                            imgUrl: r.foto || (r as any).fotoUrl || ''
                          };
                        }),
                        ...absensiTidurList.map(r => {
                          const mus = musyrifs.find(m => m.id === r.musyrifId);
                          return {
                            ...r,
                            type: 'Tidur',
                            pelaporName: mus?.name || (r as any).musyrifName || 'Musyrif/Admin',
                            asramaName: r.asrama || mus?.asrama || 'Al Hakim',
                            role: 'MUTHOLAAH/TIDUR',
                            kegiatanTitle: 'Absensi Tidur Malam',
                            imgUrl: (r as any).fotoUrl || (r as any).foto || ''
                          };
                        }),
                        ...absensiMutholaahList.map(r => {
                          const mus = musyrifs.find(m => m.id === r.musyrifId);
                          return {
                            ...r,
                            type: 'Mutholaah',
                            pelaporName: mus?.name || (r as any).musyrifName || 'Musyrif/Admin',
                            asramaName: r.asrama || mus?.asrama || 'Al Hakim',
                            role: 'MUTHOLAAH/TIDUR',
                            kegiatanTitle: 'Absensi Muthola\'ah Santri',
                            imgUrl: (r as any).fotoUrl || (r as any).foto || ''
                          };
                        })
                      ].sort((a, b) => {
                        const timeA = new Date((a.tanggal || '') + ' ' + (a.waktu || '00:00')).getTime();
                        const timeB = new Date((b.tanggal || '') + ' ' + (b.waktu || '00:00')).getTime();
                        return timeB - timeA;
                      });
                      
                      const filtered = combined.filter(r => {
                        if (absensiCategory === 'MUSYRIF' && r.type !== 'Kegiatan') return false;
                        if (absensiCategory === 'MULAHID' && !r.pelaporName.toLowerCase().includes('mulahid')) return false;
                        if (absensiCategory === 'MUTHOLAAH/TIDUR' && r.type !== 'Mutholaah' && r.type !== 'Tidur') return false;

                        if (!searchTerm.trim()) return true;
                        const q = searchTerm.toLowerCase();
                        return (
                          (r.kegiatanTitle && r.kegiatanTitle.toLowerCase().includes(q)) ||
                          (r.pelaporName && r.pelaporName.toLowerCase().includes(q)) ||
                          (r.asramaName && r.asramaName.toLowerCase().includes(q)) ||
                          (r.status && r.status.toLowerCase().includes(q)) ||
                          (r.tanggal && r.tanggal.toLowerCase().includes(q))
                        );
                      });

                      if (filtered.length === 0) {
                        return (
                          <tr>
                            <td colSpan={7} className="py-8 text-center text-slate-400 font-bold text-xs">Tidak ada data absensi ditemukan</td>
                          </tr>
                        );
                      }

                      return filtered.map((r, i) => (
                        <tr key={r.id || i} className="hover:bg-slate-50/80 transition-colors">
                          <td className="py-2.5 px-3 text-center font-bold text-slate-500 font-mono text-xs">{i + 1}</td>
                          <td className="py-2.5 px-3.5">
                            <span className="text-teal-700 font-bold block text-xs">{r.tanggal || '-'}</span>
                            <span className="text-slate-500 text-[10px] font-mono">{r.waktu || '00:00'}</span>
                          </td>
                          <td className="py-2.5 px-3.5">
                            <span className="font-bold text-slate-800 block text-xs">{r.pelaporName}</span>
                            <span className="block text-slate-500 text-[10px]">({r.asramaName})</span>
                          </td>
                          <td className="py-2.5 px-3.5 font-medium text-slate-700 text-xs">
                            {r.kegiatanTitle} {(r.type === 'Kegiatan' ? '(Absen Musyrif)' : '')}
                          </td>
                          <td className="py-2.5 px-3 text-center">
                            {r.imgUrl ? (
                              <img 
                                src={r.imgUrl} 
                                alt="Bukti" 
                                className="w-7 h-7 object-cover rounded shadow-xs mx-auto cursor-pointer hover:scale-110 transition border border-slate-200" 
                                onClick={() => setLightboxUrl(r.imgUrl)} 
                              />
                            ) : (
                              <span className="text-slate-300">-</span>
                            )}
                          </td>
                          <td className="py-2.5 px-3 text-center">
                            <span className={`px-2 py-0.5 rounded text-[9px] font-bold border ${r.status?.includes('Hadir') ? 'text-emerald-600 border-emerald-200 bg-emerald-50' : 'text-rose-600 border-rose-200 bg-rose-50'}`}>
                              {r.status?.includes('Hadir') ? 'Hadir' : r.status || 'Hadir'}
                            </span>
                          </td>
                          <td className="py-2.5 px-3 text-center">
                            <button 
                              type="button"
                              onClick={() => {
                                if (window.confirm(`Apakah Anda yakin ingin menghapus data absensi "${r.kegiatanTitle}"?`)) {
                                  if (r.type === 'Kegiatan') deleteAbsensi(r.id);
                                  else if (r.type === 'Tidur') deleteAbsensiTidur(r.id);
                                  else if (r.type === 'Mutholaah') deleteAbsensiMutholaah(r.id);
                                }
                              }}
                              className="text-rose-600 bg-rose-50 border border-rose-200 px-2.5 py-0.5 rounded text-[10px] font-bold hover:bg-rose-100 transition cursor-pointer"
                            >
                              Hapus
                            </button>
                          </td>
                        </tr>
                      ));
                    })()}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Area for expanded collapsible forms */}
        {expandedZone && (
          <div className="animate-fade-in pb-10">
            {/* MODALS */}

            {/* KEGIATAN MODAL */}
            {(showKegiatanModal || editingKegiatan) && (
              <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
                <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden animate-scale-up">
                  <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                    <h3 className="font-bold text-[#0B4A3F]">{editingKegiatan ? 'Edit Data Kegiatan' : 'Tambah Kegiatan Baru'}</h3>
                    <button onClick={() => { setShowKegiatanModal(false); setEditingKegiatan(null); }} className="text-slate-400 hover:text-slate-600"><X className="w-5 h-5"/></button>
                  </div>
                  <div className="bg-slate-50 border-b border-slate-100 px-6 flex gap-4">
                    <button type="button" onClick={() => setAddKegiatanMode('single')} className={`py-3 text-sm font-semibold border-b-2 ${addKegiatanMode === 'single' ? 'border-[#0B4A3F] text-[#0B4A3F]' : 'border-transparent text-slate-500 hover:text-slate-700'}`}>Satuan</button>
                    <button type="button" onClick={() => setAddKegiatanMode('bulk')} className={`py-3 text-sm font-semibold border-b-2 ${addKegiatanMode === 'bulk' ? 'border-[#0B4A3F] text-[#0B4A3F]' : 'border-transparent text-slate-500 hover:text-slate-700'}`}>Masal (Excel/CSV)</button>
                  </div>
                  <div className="p-6 max-h-[70vh] overflow-y-auto">
                  {addKegiatanMode === 'bulk' ? (
                    <div className="space-y-4">
                      <p className="text-sm text-slate-600">Paste data dari Excel. Format kolom: <b>Nama Kegiatan, Waktu (contoh: 03:00-04:00), Hari (contoh: senin, selasa)</b> (pisahkan dengan tab/enter).</p>
                      <textarea
                        value={bulkKegiatanText}
                        onChange={(e) => setBulkKegiatanText(e.target.value)}
                        placeholder="Contoh:&#10;Ngaji&#9;18:00-19:00&#9;senin, selasa, rabu"
                        className="w-full h-48 border border-slate-200 rounded-xl p-3 text-sm focus:border-[#0B4A3F] outline-none font-mono"
                      ></textarea>
                      <button onClick={() => {
                        const rows = bulkKegiatanText.split('\n').filter(r => r.trim());
                        const currentSchedules = pondokSettings?.schedules || SCHEDULES;
                        const added: any[] = [];
                        rows.forEach(row => {
                          const cols = row.split('\t').map(c => c.trim());
                          if(cols.length >= 1) {
                            added.push({
                              id: 'act-' + Math.random().toString(36).substr(2, 9),
                              title: cols[0],
                              time: cols[1] || '-',
                              days: cols[2] ? cols[2].split(',').map(d => d.trim().toLowerCase()) : ['senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu', 'minggu'],
                              icon: '⏰'
                            });
                          }
                        });
                        updateSettings({ schedules: [...currentSchedules, ...added] });
                        setBulkKegiatanText('');
                        setShowKegiatanModal(false);
                      }} className="w-full bg-[#0B4A3F] text-white py-2 rounded-xl font-bold hover:bg-[#083a31] transition">
                        Simpan Data Masal ({bulkKegiatanText.split('\n').filter(r => r.trim()).length} Baris)
                      </button>
                    </div>
                  ) : (
                    <form onSubmit={(e: any) => {
                      e.preventDefault();
                      const currentSchedules = pondokSettings?.schedules || SCHEDULES;
                      
                      const selectedDays = Array.from(e.target.querySelectorAll('input[type="checkbox"]:checked')).map((cb: any) => cb.value);

                      if (editingKegiatan) {
                        const updated = currentSchedules.map((s: any) => {
                          if (s.id === editingKegiatan.id) {
                            return { ...s, title: e.target.title.value, time: e.target.time.value, days: selectedDays };
                          }
                          return s;
                        });
                        updateSettings({ schedules: updated });
                      } else {
                        const newAct = {
                          id: 'act-' + Math.random().toString(36).substr(2, 9),
                          title: e.target.title.value,
                          time: e.target.time.value,
                          days: selectedDays.length ? selectedDays : ['senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu', 'minggu'],
                          icon: '⏰'
                        };
                        updateSettings({ schedules: [...currentSchedules, newAct] });
                      }
                      setShowKegiatanModal(false);
                      setEditingKegiatan(null);
                    }} className="space-y-4">
                      <div><label className="text-xs font-bold text-slate-500 mb-1 block">Nama Kegiatan</label><input name="title" defaultValue={editingKegiatan?.title || ''} required className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:border-[#0B4A3F] outline-none" /></div>
                      <div><label className="text-xs font-bold text-slate-500 mb-1 block">Waktu (HH:MM - HH:MM)</label><input name="time" defaultValue={editingKegiatan?.time || ''} required className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:border-[#0B4A3F] outline-none" placeholder="Contoh: 03:00-04:00" /></div>
                      <div>
                        <label className="text-xs font-bold text-slate-500 mb-2 block">Hari Pelaksanaan</label>
                        <div className="grid grid-cols-2 gap-2">
                          {['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'].map(day => (
                            <label key={day} className="flex items-center gap-2 text-sm text-slate-600">
                              <input type="checkbox" value={day.toLowerCase()} defaultChecked={!editingKegiatan || editingKegiatan?.days?.includes(day.toLowerCase())} className="rounded border-slate-300 text-[#0B4A3F] focus:ring-[#0B4A3F]" />
                              {day}
                            </label>
                          ))}
                        </div>
                      </div>
                      <div className="pt-4"><button type="submit" className="w-full bg-[#0B4A3F] text-white py-3 rounded-xl font-bold hover:bg-[#064e3b] transition">Simpan Data</button></div>
                    </form>
                  )}
                  </div>
                </div>
              </div>
            )}

            {(showSantriModal || editingSantri) && (
              <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
                <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden animate-scale-up">
                  <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                    <h3 className="font-bold text-[#0B4A3F]">{editingSantri ? 'Edit Data Santri' : 'Tambah Santri Baru'}</h3>
                    <button onClick={() => { setShowSantriModal(false); setEditingSantri(null); }} className="text-slate-400 hover:text-slate-600"><X className="w-5 h-5"/></button>
                  </div>
                  <div className="bg-slate-50 border-b border-slate-100 px-6 flex gap-4">
                      <button type="button" onClick={() => setAddSantriMode('single')} className={`py-3 text-sm font-semibold border-b-2 ${addSantriMode === 'single' ? 'border-[#0B4A3F] text-[#0B4A3F]' : 'border-transparent text-slate-500 hover:text-slate-700'}`}>Satuan</button>
                      <button type="button" onClick={() => setAddSantriMode('bulk')} className={`py-3 text-sm font-semibold border-b-2 ${addSantriMode === 'bulk' ? 'border-[#0B4A3F] text-[#0B4A3F]' : 'border-transparent text-slate-500 hover:text-slate-700'}`}>Masal (Excel/CSV)</button>
                    </div>
                  <div className="p-6">
                  {addSantriMode === 'bulk' ? (
                    <div className="space-y-4">
                      <p className="text-sm text-slate-600">Paste data dari Excel. Format kolom: <b>Nama, NIS, Asrama, Kamar, Kelas, Status, Sandi</b> (pisahkan dengan tab/enter).</p>
                      <textarea
                        value={bulkSantriText}
                        onChange={(e) => setBulkSantriText(e.target.value)}
                        placeholder="Contoh:&#10;Budi&#9;123&#9;Asrama A&#9;1&#9;10&#9;normal&#9;budi123&#10;Andi&#9;124&#9;Asrama B&#9;2&#9;11&#9;yatim&#9;andi123"
                        className="w-full h-48 border border-slate-200 rounded-xl p-3 text-sm focus:border-[#0B4A3F] outline-none font-mono"
                      ></textarea>
                      <button onClick={() => {
                        const rows = bulkSantriText.split('\n').filter(r => r.trim());
                        rows.forEach(row => {
                          const cols = row.split('\t').map(c => c.trim());
                          if(cols.length >= 1) {
                            addSantri({
                              name: cols[0],
                              nis: cols[1] || '',
                              asrama: cols[2] || '',
                              kamar: cols[3] || '',
                              kelas: cols[4] || '',
                              status: cols[5] || 'normal',
                              password: cols[6] || '123456'
                            });
                          }
                        });
                        setBulkSantriText('');
                        setShowSantriModal(false);
                      }} className="w-full bg-[#0B4A3F] text-white py-2 rounded-xl font-bold hover:bg-[#083a31] transition">
                        Simpan Data Masal ({bulkSantriText.split('\n').filter(r => r.trim()).length} Baris)
                      </button>
                    </div>
                  ) : (
                    <form onSubmit={(e: any) => {
                      e.preventDefault();
                      const payload = {
                        name: e.target.name.value,
                        nis: e.target.nis.value,
                        asrama: e.target.asrama.value,
                        kamar: e.target.kamar.value,
                        kelas: e.target.kelas.value,
                        status: e.target.status.value,
                        password: e.target.password.value
                      };
                      if (editingSantri) updateSantri(editingSantri.id, payload);
                      else addSantri(payload);
                      setShowSantriModal(false);
                      setEditingSantri(null);
                    }} className="space-y-4">
                      <div><label className="text-xs font-bold text-slate-500 mb-1 block">Nama Lengkap</label><input name="name" defaultValue={editingSantri?.name || ''} required className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:border-[#0B4A3F] outline-none" /></div>
                      <div className="grid grid-cols-2 gap-4">
                        <div><label className="text-xs font-bold text-slate-500 mb-1 block">NIS</label><input name="nis" defaultValue={editingSantri?.nis || ''} className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:border-[#0B4A3F] outline-none" /></div>
                        <div><label className="text-xs font-bold text-slate-500 mb-1 block">Kelas</label><input name="kelas" defaultValue={editingSantri?.kelas || ''} className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:border-[#0B4A3F] outline-none" /></div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div><label className="text-xs font-bold text-slate-500 mb-1 block">Asrama</label>
                           <select name="asrama" defaultValue={editingSantri?.asrama || 'Al Karim'} className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:border-[#0B4A3F] outline-none">
                             <option value="Al Hakim">Al Hakim</option>
                             <option value="Al Fattah">Al Fattah</option>
                             <option value="Al Karim">Al Karim</option>
                           </select>
                        </div>
                        <div><label className="text-xs font-bold text-slate-500 mb-1 block">Kamar</label><input name="kamar" defaultValue={editingSantri?.kamar || 'Kamar 101'} className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:border-[#0B4A3F] outline-none" /></div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div><label className="text-xs font-bold text-slate-500 mb-1 block">Status</label>
                           <select name="status" defaultValue={editingSantri?.status || 'Reguler'} className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:border-[#0B4A3F] outline-none">
                             <option value="Reguler">Reguler</option>
                             <option value="Yatim">Yatim</option>
                             <option value="Piatu">Piatu</option>
                             <option value="Yatim Piatu">Yatim Piatu</option>
                           </select>
                        </div>
                        <div><label className="text-xs font-bold text-slate-500 mb-1 block">Password</label><input name="password" defaultValue={editingSantri?.password || '1234'} className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:border-[#0B4A3F] outline-none" /></div>
                      </div>
                      <div className="pt-4"><button type="submit" className="w-full bg-[#0B4A3F] text-white py-3 rounded-xl font-bold hover:bg-[#064e3b] transition">Simpan Data</button></div>
                    </form>)}
                  </div>
                </div>
              </div>
            )}

            {(showMusyrifModal || editingMusyrif) && (
              <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
                <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden animate-scale-up">
                  <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                    <h3 className="font-bold text-[#0B4A3F]">{editingMusyrif ? 'Edit Data Kamar & Musyrif' : 'Tambah Data Kamar & Musyrif'}</h3>
                    <button onClick={() => { setShowMusyrifModal(false); setEditingMusyrif(null); }} className="text-slate-400 hover:text-slate-600"><X className="w-5 h-5"/></button>
                  </div>
                  <div className="bg-slate-50 border-b border-slate-100 px-6 flex gap-4">
                      <button type="button" onClick={() => setAddMusyrifMode('single')} className={`py-3 text-sm font-semibold border-b-2 ${addMusyrifMode === 'single' ? 'border-[#0B4A3F] text-[#0B4A3F]' : 'border-transparent text-slate-500 hover:text-slate-700'}`}>Satuan</button>
                      <button type="button" onClick={() => setAddMusyrifMode('bulk')} className={`py-3 text-sm font-semibold border-b-2 ${addMusyrifMode === 'bulk' ? 'border-[#0B4A3F] text-[#0B4A3F]' : 'border-transparent text-slate-500 hover:text-slate-700'}`}>Masal (Excel/CSV)</button>
                    </div>
                  <div className="p-6">
                  {addMusyrifMode === 'bulk' ? (
                    <div className="space-y-4">
                      <p className="text-sm text-slate-600">Paste data dari Excel. Format kolom: <b>Nama Asrama, Nama Kamar, Kapasitas, Musyrif Kamar, Mulahid</b> (pisahkan dengan tab/enter).</p>
                      <textarea
                        value={bulkMusyrifText}
                        onChange={(e) => setBulkMusyrifText(e.target.value)}
                        placeholder="Contoh:&#10;Al Hakim&#9;Kamar 101&#9;30&#9;Ust Ahmad Mashuri&#9;Fatkhul Fahmi&#10;Al Fattah&#9;Kamar 102&#9;30&#9;Ust Ridwan&#9;Ust Zulfi"
                        className="w-full h-48 border border-slate-200 rounded-xl p-3 text-sm focus:border-[#0B4A3F] outline-none font-mono"
                      ></textarea>
                      <button onClick={() => {
                        const rows = bulkMusyrifText.split('\n').filter(r => r.trim());
                        rows.forEach(row => {
                          const cols = row.split('\t').map(c => c.trim());
                          if(cols.length >= 2) {
                            const asrama = cols[0] || 'Al Hakim';
                            const kamar = cols[1] || 'Kamar 101';
                            const musyrifKamar = cols[3] || '';
                            const mulahid = cols[4] || '';

                            if (musyrifKamar) {
                              addMusyrif({
                                name: musyrifKamar,
                                asrama: asrama as any,
                                kamar: kamar,
                                phoneNumber: '',
                                password: '1234'
                              });
                            }
                            if (mulahid && mulahid !== musyrifKamar) {
                              addMusyrif({
                                name: mulahid,
                                asrama: asrama as any,
                                kamar: kamar,
                                phoneNumber: '',
                                password: '1234'
                              });
                            }
                          }
                        });
                        setBulkMusyrifText('');
                        setShowMusyrifModal(false);
                      }} className="w-full bg-[#0B4A3F] text-white py-2.5 rounded-xl font-bold hover:bg-[#083a31] transition">
                        Simpan Data Masal ({bulkMusyrifText.split('\n').filter(r => r.trim()).length} Baris)
                      </button>
                    </div>
                  ) : (
                    <form onSubmit={(e: any) => {
                      e.preventDefault();
                      const asrama = e.target.asrama.value;
                      const kamar = e.target.kamar.value;
                      const musyrifKamar = e.target.musyrifKamar.value;
                      const mulahid = e.target.mulahid.value;
                      const phone = e.target.phone.value;
                      const password = e.target.password.value;

                      if (editingMusyrif) {
                        updateMusyrif(editingMusyrif.id, {
                          name: musyrifKamar || editingMusyrif.name,
                          asrama: asrama as any,
                          kamar,
                          phoneNumber: phone,
                          password
                        });
                      } else {
                        if (musyrifKamar) {
                          addMusyrif({
                            name: musyrifKamar,
                            asrama: asrama as any,
                            kamar,
                            phoneNumber: phone,
                            password: password || '1234'
                          });
                        }
                        if (mulahid && mulahid !== musyrifKamar) {
                          addMusyrif({
                            name: mulahid,
                            asrama: asrama as any,
                            kamar,
                            phoneNumber: phone,
                            password: password || '1234'
                          });
                        }
                      }
                      setShowMusyrifModal(false);
                      setEditingMusyrif(null);
                    }} className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-xs font-bold text-slate-500 mb-1 block">Nama Asrama</label>
                          <select name="asrama" defaultValue={editingMusyrif?.asrama || 'Al Hakim'} className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:border-[#0B4A3F] outline-none">
                            <option value="Al Hakim">Al Hakim</option>
                            <option value="Al Fattah">Al Fattah</option>
                            <option value="Al Karim">Al Karim</option>
                          </select>
                        </div>
                        <div>
                          <label className="text-xs font-bold text-slate-500 mb-1 block">Nama Kamar</label>
                          <input name="kamar" defaultValue={editingMusyrif?.kamar || 'Kamar 101'} required className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:border-[#0B4A3F] outline-none" />
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                        <div>
                          <label className="text-xs font-bold text-slate-500 mb-1 block">Kapasitas</label>
                          <input name="kapasitas" type="number" defaultValue={30} className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:border-[#0B4A3F] outline-none" />
                        </div>
                        <div className="col-span-2">
                          <label className="text-xs font-bold text-slate-500 mb-1 block">Musyrif Kamar</label>
                          <input name="musyrifKamar" defaultValue={editingMusyrif?.name || ''} placeholder="Nama Musyrif Kamar" required className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:border-[#0B4A3F] outline-none" />
                        </div>
                      </div>

                      <div>
                        <label className="text-xs font-bold text-slate-500 mb-1 block">Mulahid</label>
                        <input name="mulahid" placeholder="Nama Mulahid Kamar (Opsional)" className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:border-[#0B4A3F] outline-none" />
                      </div>

                      <div className="grid grid-cols-2 gap-4 border-t border-slate-100 pt-3">
                        <div><label className="text-xs font-bold text-slate-500 mb-1 block">No. WA</label><input name="phone" defaultValue={editingMusyrif?.phoneNumber || ''} placeholder="08xxx" className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:border-[#0B4A3F] outline-none" /></div>
                        <div><label className="text-xs font-bold text-slate-500 mb-1 block">Password Login</label><input name="password" defaultValue={editingMusyrif?.password || '1234'} className="w-full border border-slate-200 rounded-xl px-3 py-2 text-sm focus:border-[#0B4A3F] outline-none" /></div>
                      </div>

                      <div className="pt-2"><button type="submit" className="w-full bg-[#0B4A3F] text-white py-3 rounded-xl font-bold hover:bg-[#064e3b] transition">Simpan Data Kamar & Musyrif</button></div>
                    </form>)}
                  </div>
                </div>
              </div>
            )}

                                    {/* DATA MUSYRIF VIEW */}
            {expandedZone === 'musyrifs' && (() => {
              const stats: Record<string, { asrama: string, kamar: string, kapasitas: number, terisi: number, musyrifs: any[] }> = {};
              santris.forEach(s => {
                  const key = `${s.asrama}-${s.kamar}`;
                  if (!stats[key]) stats[key] = { asrama: s.asrama, kamar: s.kamar, kapasitas: 30, terisi: 0, musyrifs: [] };
                  stats[key].terisi += 1;
              });
              musyrifs.forEach(m => {
                  const key = `${m.asrama}-${m.kamar}`;
                  if (!stats[key]) stats[key] = { asrama: m.asrama, kamar: m.kamar, kapasitas: 30, terisi: 0, musyrifs: [] };
                  stats[key].musyrifs.push(m);
              });
              const kamarList = Object.values(stats).sort((a, b) => a.asrama.localeCompare(b.asrama) || a.kamar.localeCompare(b.kamar));
              
              return (
              <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
                <div className="p-6 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <h2 className="text-xl font-bold text-[#0B4A3F] flex items-center gap-2">
                      <span className="text-emerald-500">✨</span> Data Kamar & Musyrif Kamar
                    </h2>
                    <p className="text-slate-500 text-sm mt-1">Manajemen data asrama dan kamar</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                      <input type="text" placeholder="Cari data..." className="w-64 bg-white border border-slate-200 rounded-lg py-2 pl-9 pr-3 text-sm focus:outline-none focus:border-blue-500" />
                    </div>
                    <button onClick={() => { setShowMusyrifModal(true); setAddMusyrifMode('single'); }} className="bg-[#4F46E5] text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-indigo-600 transition flex items-center gap-2">
                      <PlusCircle className="w-4 h-4" /> Tambah
                    </button>
                    <button onClick={() => { setShowMusyrifModal(true); setAddMusyrifMode('bulk'); }} className="bg-[#10B981] text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-emerald-600 transition flex items-center gap-2">
                      <span className="text-sm">↑</span> Tambah Masal
                    </button>
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm border-collapse">
                    <thead>
                      <tr className="bg-white border-b border-slate-100 text-slate-700 font-bold uppercase tracking-wide text-xs">
                        <th className="py-4 px-6 text-center w-16">NO</th>
                        <th className="py-4 px-6">NAMA ASRAMA</th>
                        <th className="py-4 px-6">NAMA KAMAR</th>
                        <th className="py-4 px-6">KAPASITAS</th>
                        <th className="py-4 px-6">TERISI</th>
                        <th className="py-4 px-6">MUSYRIF KAMAR</th>
                        <th className="py-4 px-6">MULAHID</th>
                        <th className="py-4 px-6 text-center">AKSI</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50">
                      {kamarList.length > 0 ? (
                        kamarList.map((item, idx) => (
                          <tr key={`${item.asrama}-${item.kamar}`} className="hover:bg-slate-50 transition">
                            <td className="py-4 px-6 text-center text-slate-500 font-medium">{idx + 1}</td>
                            <td className="py-4 px-6 font-bold text-[#0B4A3F]">{item.asrama}</td>
                            <td className="py-4 px-6 text-slate-600 font-bold">{item.kamar}</td>
                            <td className="py-4 px-6 font-bold">{item.kapasitas}</td>
                            <td className="py-4 px-6 font-bold text-emerald-600">{item.terisi}</td>
                            <td className="py-4 px-6 text-slate-800 font-bold">{item.musyrifs[0] ? item.musyrifs[0].name : '-'}</td>
                            <td className="py-4 px-6 text-slate-800 font-bold">{item.musyrifs[1] ? item.musyrifs[1].name : '-'}</td>
                            <td className="py-4 px-6">
                              <div className="flex justify-center gap-2">
                                <button onClick={() => {
                                  // Open edit modal for the first musyrif or create new
                                  if(item.musyrifs[0]) setEditingMusyrif(item.musyrifs[0]);
                                  else {
                                    // Hack to set default asrama/kamar when adding
                                    setShowMusyrifModal(true);
                                  }
                                }} className="p-1.5 text-blue-500 hover:bg-blue-50 rounded-lg transition" title="Edit Musyrif">
                                  <Edit className="w-4 h-4" />
                                </button>
                                {item.musyrifs[0] && (
                                  <button onClick={() => {
                                    if (window.confirm('Hapus musyrif ini?')) {
                                      deleteMusyrif(item.musyrifs[0].id);
                                    }
                                  }} className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition" title="Hapus Musyrif">
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                )}
                              </div>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={8} className="py-10 text-center text-slate-500 font-medium">Belum ada data kamar</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
              );
            })()}

            {/* DATA YATIM VIEW */}
            {expandedZone === 'yatim' && (
              <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
                <div className="p-6 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <h2 className="text-xl font-bold text-[#0B4A3F] flex items-center gap-2">
                      <span className="text-emerald-500">✨</span> Data Santri Yatim/Piatu
                    </h2>
                    <p className="text-slate-500 text-sm mt-1">Manajemen data santri yatim/piatu</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                      <input type="text" placeholder="Cari data..." className="w-64 bg-white border border-slate-200 rounded-lg py-2 pl-9 pr-3 text-sm focus:outline-none focus:border-blue-500" />
                    </div>
                    <button onClick={() => setShowSantriModal(true)} className="bg-[#4F46E5] text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-indigo-600 transition flex items-center gap-2">
                      <PlusCircle className="w-4 h-4" /> Tambah
                    </button>
                    <button onClick={() => { setShowSantriModal(true); setAddSantriMode('bulk'); }} className="bg-[#10B981] text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-emerald-600 transition flex items-center gap-2">
                      <span className="text-sm">↑</span> Tambah Masal
                    </button>
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm border-collapse">
                    <thead>
                      <tr className="bg-white border-b border-slate-100 text-slate-700 font-bold uppercase tracking-wide text-xs">
                        <th className="py-4 px-6 text-center w-16">NO</th>
                        <th className="py-4 px-6">NAMA LENGKAP</th>
                        <th className="py-4 px-6">NIS</th>
                        <th className="py-4 px-6">ASRAMA</th>
                        <th className="py-4 px-6">KAMAR</th>
                        <th className="py-4 px-6">KELAS</th>
                        <th className="py-4 px-6 text-center">AKSI</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50">
                      {santris.filter(s => s.status && s.status !== 'Reguler').length > 0 ? (
                        santris.filter(s => s.status && s.status !== 'Reguler').map((santri, idx) => (
                          <tr key={santri.id} className="hover:bg-slate-50 transition">
                            <td className="py-4 px-6 text-center text-slate-500 font-medium">{idx + 1}</td>
                            <td className="py-4 px-6 font-bold text-[#0B4A3F]">{santri.name}</td>
                            <td className="py-4 px-6 text-slate-600 font-mono">{santri.nis || '-'}</td>
                            <td className="py-4 px-6 text-slate-600">{santri.asrama}</td>
                            <td className="py-4 px-6 text-slate-600 font-bold">{santri.kamar}</td>
                            <td className="py-4 px-6">
                              <span className="bg-amber-100 text-amber-700 px-2 py-1 rounded text-xs font-bold">{santri.status}</span>
                            </td>
                            <td className="py-4 px-6">
                              <div className="flex justify-center gap-2">
                                <button onClick={() => setEditingSantri(santri)} className="p-1.5 text-blue-500 hover:bg-blue-50 rounded-lg transition" title="Edit Data">
                                  <Edit className="w-4 h-4" />
                                </button>
                                <button onClick={() => {
                                  if (window.confirm('Hapus data santri ini?')) {
                                    deleteSantri(santri.id);
                                  }
                                }} className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition" title="Hapus Data">
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={7} className="py-10 text-center text-slate-500 font-medium">Belum ada data santri yatim/piatu</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* DATA SANTRI VIEW */}
            {expandedZone === 'santri' && (
              <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
                <div className="p-6 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <h2 className="text-xl font-bold text-[#0B4A3F] flex items-center gap-2">
                      <span className="text-emerald-500">✨</span> Data Santri
                    </h2>
                    <p className="text-slate-500 text-sm mt-1">Manajemen data santri lengkap</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                      <input type="text" placeholder="Cari data..." className="w-64 bg-white border border-slate-200 rounded-lg py-2 pl-9 pr-3 text-sm focus:outline-none focus:border-blue-500" />
                    </div>
                    <button onClick={() => setShowSantriModal(true)} className="bg-[#4F46E5] text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-indigo-600 transition flex items-center gap-2">
                      <PlusCircle className="w-4 h-4" /> Tambah
                    </button>
                    <button onClick={() => { setShowSantriModal(true); setAddSantriMode('bulk'); }} className="bg-[#10B981] text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-emerald-600 transition flex items-center gap-2">
                      <span className="text-sm">↑</span> Tambah Masal
                    </button>
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm border-collapse">
                    <thead>
                      <tr className="bg-white border-b border-slate-100 text-slate-700 font-bold uppercase tracking-wide text-xs">
                        <th className="py-4 px-6 text-center w-16">NO</th>
                        <th className="py-4 px-6">NAMA LENGKAP</th>
                        <th className="py-4 px-6">NIS</th>
                        <th className="py-4 px-6">ASRAMA</th>
                        <th className="py-4 px-6">KAMAR</th>
                        <th className="py-4 px-6">KELAS</th>
                        <th className="py-4 px-6 text-center">AKSI</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50">
                      {santris.length > 0 ? (
                        santris.map((santri, idx) => (
                          <tr key={santri.id} className="hover:bg-slate-50 transition">
                            <td className="py-4 px-6 text-center text-slate-500 font-medium">{idx + 1}</td>
                            <td className="py-4 px-6 font-bold text-[#0B4A3F]">{santri.name}</td>
                            <td className="py-4 px-6 text-slate-600 font-mono">{santri.nis || '-'}</td>
                            <td className="py-4 px-6 text-slate-600">{santri.asrama}</td>
                            <td className="py-4 px-6 text-slate-600 font-bold">{santri.kamar}</td>
                            <td className="py-4 px-6">
                              <span className="bg-amber-100 text-amber-700 px-2 py-1 rounded text-xs font-bold">{santri.status}</span>
                            </td>
                            <td className="py-4 px-6">
                              <div className="flex justify-center gap-2">
                                <button onClick={() => setEditingSantri(santri)} className="p-1.5 text-blue-500 hover:bg-blue-50 rounded-lg transition" title="Edit Data">
                                  <Edit className="w-4 h-4" />
                                </button>
                                <button onClick={() => {
                                  if (window.confirm('Hapus data santri ini?')) {
                                    deleteSantri(santri.id);
                                  }
                                }} className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition" title="Hapus Data">
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={7} className="py-10 text-center text-slate-500 font-medium">Belum ada data santri</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* DATA KEGIATAN VIEW */}
            {expandedZone === 'kegiatan' && (
              <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
                <div className="p-6 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <h2 className="text-xl font-bold text-[#0B4A3F] flex items-center gap-2">
                      <span className="text-emerald-500">✨</span> Data Kegiatan
                    </h2>
                    <p className="text-slate-500 text-sm mt-1">Jadwal dan daftar kegiatan harian</p>
                  </div>
                <div className="flex items-center gap-3">
                    <div className="relative">
                      <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                      <input type="text" placeholder="Cari data..." className="w-64 bg-white border border-slate-200 rounded-lg py-2 pl-9 pr-3 text-sm focus:outline-none focus:border-blue-500" />
                    </div>
                    <button onClick={() => { setShowKegiatanModal(true); setAddKegiatanMode('single'); }} className="bg-[#4F46E5] text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-indigo-600 transition flex items-center gap-2">
                      <PlusCircle className="w-4 h-4" /> Tambah
                    </button>
                    <button onClick={() => { setShowKegiatanModal(true); setAddKegiatanMode('bulk'); }} className="bg-[#10B981] text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-emerald-600 transition flex items-center gap-2">
                      <span className="text-sm">↑</span> Tambah Masal
                    </button>
                  </div>
                </div>
                <div className="overflow-x-auto relative">
                  <table className="w-full text-left text-sm border-collapse">
                    <thead>
                      <tr className="bg-white border-b border-slate-100 text-slate-700 font-bold uppercase tracking-wide text-xs">
                        <th className="py-4 px-6 text-center w-16">NO</th>
                        <th className="py-4 px-6">NAMA KEGIATAN</th>
                        <th className="py-4 px-6">HARI</th>
                        <th className="py-4 px-6">WAKTU</th>
                        <th className="py-4 px-6">JENIS</th>
                        <th className="py-4 px-6">PENANGGUNG JAWAB</th>
                        <th className="py-4 px-6 text-center">AKSI</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50">
                      {(pondokSettings?.schedules || SCHEDULES).map((keg, idx) => (
                        <tr key={keg.id} className="hover:bg-slate-50">
                          <td className="py-5 px-6 text-center font-bold text-slate-600">{idx + 1}</td>
                          <td className="py-5 px-6 font-bold text-[#0B4A3F] max-w-[250px]">{keg.title}</td>
                          <td className="py-5 px-6 font-bold text-slate-700 max-w-[150px] capitalize">{keg.days.join(', ')}</td>
                          <td className="py-5 px-6 font-bold text-slate-800">{keg.time}</td>
                          <td className="py-5 px-6 font-bold text-slate-800">Harian</td>
                          <td className="py-5 px-6 font-bold text-slate-800">Musyrif &<br/>Mulahid Kamar</td>
                          <td className="py-5 px-6">
                            <div className="flex justify-center gap-2">
                              <button onClick={() => setEditingKegiatan(keg)} className="p-2 text-blue-500 hover:bg-blue-50 rounded-lg transition" title="Edit Kegiatan">
                                <Edit className="w-4 h-4" />
                              </button>
                              <button onClick={() => {
                                if (window.confirm('Hapus kegiatan ini?')) {
                                  const currentSchedules = pondokSettings?.schedules || SCHEDULES;
                                  const newSchedules = currentSchedules.filter((s: any) => s.id !== keg.id);
                                  updateSettings({ schedules: newSchedules });
                                }
                              }} className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition" title="Hapus Kegiatan">
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* LAPORAN ABSENSI SANTRI VIEW */}
            {(expandedZone === 'laporan_santri' || expandedZone === 'laporan') && (
              <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 space-y-6">
                {/* Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h2 className="text-xl sm:text-2xl font-black text-[#0B4A3F] tracking-tight">Laporan Absensi Santri</h2>
                    <p className="text-slate-500 text-xs sm:text-sm mt-0.5 font-medium">Rekapitulasi kehadiran dan kedisiplinan santri</p>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <button 
                      type="button"
                      onClick={() => setReportPdfModal({ open: true, type: 'santri' })}
                      className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 shadow-xs transition cursor-pointer"
                    >
                      <Eye className="w-4 h-4" />
                      <span>Review PDF</span>
                    </button>
                    <button 
                      type="button"
                      onClick={() => setReportPdfModal({ open: true, type: 'santri' })}
                      className="bg-[#0f5237] hover:bg-[#0a3d28] text-white px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 shadow-xs transition cursor-pointer"
                    >
                      <Download className="w-4 h-4" />
                      <span>Download</span>
                    </button>
                  </div>
                </div>

                {/* Sub-tabs: Keseluruhan vs Individu */}
                <div className="flex items-center gap-2 border-b border-slate-100 pb-4">
                  <button
                    type="button"
                    onClick={() => setLaporanSantriSubTab('keseluruhan')}
                    className={`px-5 py-2 rounded-xl text-xs font-extrabold transition cursor-pointer ${
                      laporanSantriSubTab === 'keseluruhan'
                        ? 'bg-emerald-50 text-emerald-800 border border-emerald-200/80 shadow-2xs'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                    }`}
                  >
                    Keseluruhan
                  </button>
                  <button
                    type="button"
                    onClick={() => setLaporanSantriSubTab('individu')}
                    className={`px-5 py-2 rounded-xl text-xs font-extrabold transition cursor-pointer ${
                      laporanSantriSubTab === 'individu'
                        ? 'bg-emerald-50 text-emerald-800 border border-emerald-200/80 shadow-2xs'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                    }`}
                  >
                    Individu
                  </button>
                </div>

                {laporanSantriSubTab === 'keseluruhan' ? (
                  <div className="overflow-x-auto rounded-2xl border border-slate-100">
                    <table className="w-full text-left text-sm border-collapse">
                      <thead>
                        <tr className="bg-slate-50/70 text-slate-500 font-extrabold tracking-wider uppercase text-[11px] border-b border-slate-100">
                          <th className="py-4 px-6">NAMA SANTRI</th>
                          <th className="py-4 px-6">KAMAR</th>
                          <th className="py-4 px-6">HADIR</th>
                          <th className="py-4 px-6">PERSENTASE</th>
                          <th className="py-4 px-6 text-center">NILAI (A-D)</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-50">
                        {santris.length > 0 ? (
                          santris.map((santri) => {
                            const mutholaahHadir = absensiMutholaahList.filter(r => r.santriId === santri.id && r.status && r.status.includes('Hadir')).length;
                            const tidurHadir = absensiTidurList.filter(r => r.santriId === santri.id && r.status && r.status.includes('Hadir')).length;
                            const totalHadir = mutholaahHadir + tidurHadir;
                            
                            const totalMutholaah = absensiMutholaahList.filter(r => r.santriId === santri.id).length;
                            const totalTidur = absensiTidurList.filter(r => r.santriId === santri.id).length;
                            const totalRecords = totalMutholaah + totalTidur;
                            
                            const percentage = totalRecords > 0 ? Math.min(100, Math.round((totalHadir / totalRecords) * 100)) : 0;
                            
                            let grade = '-';
                            if (totalRecords > 0) {
                              if (percentage >= 90) grade = 'A';
                              else if (percentage >= 80) grade = 'B';
                              else if (percentage >= 70) grade = 'C';
                              else grade = 'D';
                            }

                            return (
                              <tr key={santri.id} className="hover:bg-slate-50/80 transition">
                                <td className="py-4 px-6 font-bold text-slate-900">{santri.name}</td>
                                <td className="py-4 px-6 text-slate-600 font-medium">Kamar {santri.kamar || '01'}</td>
                                <td className="py-4 px-6 text-slate-700 font-semibold">{totalHadir} Hari</td>
                                <td className="py-4 px-6 font-extrabold text-emerald-600">{percentage}%</td>
                                <td className="py-4 px-6 text-center">
                                  {grade === 'A' ? (
                                    <span className="w-7 h-7 rounded-full bg-emerald-500 text-white font-extrabold text-xs flex items-center justify-center mx-auto shadow-2xs">A</span>
                                  ) : grade === 'B' ? (
                                    <span className="w-7 h-7 rounded-full bg-blue-500 text-white font-extrabold text-xs flex items-center justify-center mx-auto shadow-2xs">B</span>
                                  ) : grade === 'C' ? (
                                    <span className="w-7 h-7 rounded-full bg-amber-500 text-white font-extrabold text-xs flex items-center justify-center mx-auto shadow-2xs">C</span>
                                  ) : grade === 'D' ? (
                                    <span className="w-7 h-7 rounded-full bg-orange-500 text-white font-extrabold text-xs flex items-center justify-center mx-auto shadow-2xs">D</span>
                                  ) : (
                                    <span className="w-7 h-7 rounded-full bg-rose-500 text-white font-extrabold text-xs flex items-center justify-center mx-auto shadow-2xs">-</span>
                                  )}
                                </td>
                              </tr>
                            );
                          })
                        ) : (
                          <tr>
                            <td colSpan={5} className="py-12 text-center text-slate-400 font-medium">Belum ada data santri</td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  /* Individu Tab Content */
                  <div className="space-y-6">
                    <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 bg-slate-50 p-4 rounded-xl border border-slate-100">
                      <label className="text-xs font-bold text-slate-700 uppercase tracking-wider whitespace-nowrap">PILIH SANTRI:</label>
                      <select 
                        value={selectedSantriIdForReport || (santris[0]?.id || '')}
                        onChange={(e) => setSelectedSantriIdForReport(e.target.value)}
                        className="bg-white border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold text-slate-800 outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 w-full sm:w-72"
                      >
                        {santris.map(s => (
                          <option key={s.id} value={s.id}>{s.name} ({s.asrama} - {s.kamar})</option>
                        ))}
                      </select>
                    </div>

                    {(() => {
                      const currentSantri = santris.find(s => s.id === (selectedSantriIdForReport || santris[0]?.id)) || santris[0];
                      if (!currentSantri) return <p className="text-slate-400 text-xs">Belum ada santri terdaftar.</p>;

                      const mutholaahLogs = absensiMutholaahList.filter(r => r.santriId === currentSantri.id);
                      const tidurLogs = absensiTidurList.filter(r => r.santriId === currentSantri.id);
                      const mutholaahHadir = mutholaahLogs.filter(r => r.status && r.status.includes('Hadir')).length;
                      const tidurHadir = tidurLogs.filter(r => r.status && r.status.includes('Hadir')).length;
                      const totalHadir = mutholaahHadir + tidurHadir;
                      const totalLogs = mutholaahLogs.length + tidurLogs.length;
                      const percentage = totalLogs > 0 ? Math.min(100, Math.round((totalHadir / totalLogs) * 100)) : 0;

                      return (
                        <div className="space-y-6">
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                            <div className="bg-emerald-50/60 border border-emerald-200/60 p-4 rounded-2xl text-center">
                              <p className="text-[11px] font-extrabold text-emerald-800 uppercase tracking-wider">TOTAL KEHADIRAN</p>
                              <p className="text-2xl font-black text-emerald-700 mt-1">{totalHadir} Hari</p>
                            </div>
                            <div className="bg-blue-50/60 border border-blue-200/60 p-4 rounded-2xl text-center">
                              <p className="text-[11px] font-extrabold text-blue-800 uppercase tracking-wider">PERSENTASE</p>
                              <p className="text-2xl font-black text-blue-700 mt-1">{percentage}%</p>
                            </div>
                            <div className="bg-amber-50/60 border border-amber-200/60 p-4 rounded-2xl text-center">
                              <p className="text-[11px] font-extrabold text-amber-800 uppercase tracking-wider">PREDIKAT KEDISIPLINAN</p>
                              <p className="text-2xl font-black text-amber-700 mt-1">{totalLogs === 0 ? '-' : percentage >= 90 ? 'Sangat Baik (A)' : percentage >= 80 ? 'Baik (B)' : percentage >= 70 ? 'Cukup (C)' : 'Kurang (D)'}</p>
                            </div>
                          </div>

                          <div className="border border-slate-100 rounded-2xl overflow-hidden">
                            <div className="bg-slate-50 px-5 py-3 border-b border-slate-100 font-extrabold text-xs text-slate-700 uppercase tracking-wide">
                              RIWAYAT ABSENSI DETIL — {currentSantri.name}
                            </div>
                            <div className="overflow-x-auto">
                              <table className="w-full text-left text-xs border-collapse">
                                <thead>
                                  <tr className="border-b border-slate-100 text-slate-500 font-bold uppercase tracking-wider text-[10px] bg-white">
                                    <th className="py-3 px-5">TANGGAL</th>
                                    <th className="py-3 px-5">JENIS KEGIATAN</th>
                                    <th className="py-3 px-5">STATUS</th>
                                    <th className="py-3 px-5">CATATAN</th>
                                  </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-50">
                                  {[
                                    ...mutholaahLogs.map(m => ({ ...m, type: "Muthola'ah Santri" })),
                                    ...tidurLogs.map(t => ({ ...t, type: 'Absensi Tidur Santri' }))
                                  ].length > 0 ? (
                                    [
                                      ...mutholaahLogs.map(m => ({ ...m, type: "Muthola'ah Santri" })),
                                      ...tidurLogs.map(t => ({ ...t, type: 'Absensi Tidur Santri' }))
                                    ]
                                    .sort((a,b) => new Date(b.tanggal).getTime() - new Date(a.tanggal).getTime())
                                    .map((item, idx) => (
                                      <tr key={item.id || idx} className="hover:bg-slate-50">
                                        <td className="py-3 px-5 font-semibold text-slate-700">{item.tanggal} ({item.waktu || '-'})</td>
                                        <td className="py-3 px-5 font-bold text-slate-800">{item.type}</td>
                                        <td className="py-3 px-5">
                                          <span className={`px-2.5 py-1 rounded-full font-extrabold text-[10px] ${
                                            item.status.includes('Hadir') ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                                          }`}>
                                            {item.status}
                                          </span>
                                        </td>
                                        <td className="py-3 px-5 text-slate-500">{item.catatan || '-'}</td>
                                      </tr>
                                    ))
                                  ) : (
                                    <tr>
                                      <td colSpan={4} className="py-8 text-center text-slate-400 font-medium">Belum ada catatan absensi untuk santri ini</td>
                                    </tr>
                                  )}
                                </tbody>
                              </table>
                            </div>
                          </div>
                        </div>
                      );
                    })()}
                  </div>
                )}
              </div>
            )}

            {/* LAPORAN ABSENSI & KINERJA ASATIDZ VIEW */}
            {expandedZone === 'laporan_musyrif' && (
              <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 space-y-6">
                {/* Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h2 className="text-xl sm:text-2xl font-black text-[#0B4A3F] tracking-tight">Laporan Absensi & Kinerja Asatidz</h2>
                    <p className="text-slate-500 text-xs sm:text-sm mt-0.5 font-medium">Rekapitulasi kehadiran Musyrif & Mulahid serta Laporan Per-Individu</p>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <button 
                      type="button"
                      onClick={() => setReportPdfModal({ open: true, type: 'musyrif' })}
                      className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 shadow-xs transition cursor-pointer"
                    >
                      <Eye className="w-4 h-4" />
                      <span>Pratinjau PDF</span>
                    </button>
                    <button 
                      type="button"
                      onClick={() => setReportPdfModal({ open: true, type: 'musyrif' })}
                      className="bg-[#0f5237] hover:bg-[#0a3d28] text-white px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 shadow-xs transition cursor-pointer"
                    >
                      <Download className="w-4 h-4" />
                      <span>Download PDF</span>
                    </button>
                  </div>
                </div>

                {/* Sub-tabs for Asatidz */}
                <div className="flex flex-wrap items-center gap-2 border-b border-slate-100 pb-4">
                  <button
                    type="button"
                    onClick={() => setLaporanMusyrifSubTab('semua')}
                    className={`px-4 py-2 rounded-xl text-xs font-extrabold transition cursor-pointer ${
                      laporanMusyrifSubTab === 'semua'
                        ? 'bg-[#0f5237] text-white shadow-xs'
                        : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    Semua Rekapitulasi
                  </button>
                  <button
                    type="button"
                    onClick={() => setLaporanMusyrifSubTab('musyrif')}
                    className={`px-4 py-2 rounded-xl text-xs font-extrabold transition cursor-pointer flex items-center gap-1.5 ${
                      laporanMusyrifSubTab === 'musyrif'
                        ? 'bg-[#0f5237] text-white shadow-xs'
                        : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <span>👥</span> Kelompok Musyrif ({musyrifs.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setLaporanMusyrifSubTab('mulahid')}
                    className={`px-4 py-2 rounded-xl text-xs font-extrabold transition cursor-pointer flex items-center gap-1.5 ${
                      laporanMusyrifSubTab === 'mulahid'
                        ? 'bg-[#0f5237] text-white shadow-xs'
                        : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <span>🛡️</span> Kelompok Mulahid ({musyrifs.filter(m => m.name.toLowerCase().includes('mulahid') || m.kamar.toLowerCase().includes('mulahid')).length || musyrifs.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setLaporanMusyrifSubTab('individu')}
                    className={`px-4 py-2 rounded-xl text-xs font-extrabold transition cursor-pointer flex items-center gap-1.5 ${
                      laporanMusyrifSubTab === 'individu'
                        ? 'bg-[#0f5237] text-white shadow-xs'
                        : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <span>👤</span> Laporan Per-Individu
                  </button>
                </div>

                {laporanMusyrifSubTab !== 'individu' ? (
                  <div className="space-y-8">
                    {/* I. KELOMPOK MUSYRIF */}
                    {(laporanMusyrifSubTab === 'semua' || laporanMusyrifSubTab === 'musyrif') && (
                      <div className="space-y-3">
                        <div className="flex items-center gap-2 border-l-4 border-emerald-600 pl-3 py-0.5">
                          <h3 className="text-sm font-black text-slate-800 uppercase tracking-wide">
                            I. KELOMPOK MUSYRIF
                          </h3>
                          <span className="text-xs font-extrabold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200">
                            {musyrifs.length} Asatidz
                          </span>
                        </div>

                        <div className="overflow-x-auto rounded-2xl border border-slate-100">
                          <table className="w-full text-left text-sm border-collapse">
                            <thead>
                              <tr className="bg-slate-50/70 text-slate-500 font-extrabold tracking-wider uppercase text-[11px] border-b border-slate-100">
                                <th className="py-4 px-6">NAMA MUSYRIF</th>
                                <th className="py-4 px-6">ASRAMA</th>
                                <th className="py-4 px-6">KAMAR</th>
                                <th className="py-4 px-6">KEHADIRAN</th>
                                <th className="py-4 px-6">PERSENTASE</th>
                                <th className="py-4 px-6 text-center">NILAI</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-50">
                              {musyrifs.length > 0 ? (
                                musyrifs.map((m) => {
                                  const myReports = absensiList.filter(r => r.musyrifId === m.id);
                                  const totalReports = myReports.length;
                                  const hadirCount = myReports.filter(r => r.status === 'Hadir').length;
                                  const percentage = totalReports > 0 ? Math.min(100, Math.round((hadirCount / totalReports) * 100)) : 0;
                                  
                                  let grade = '-';
                                  if (totalReports > 0) {
                                    if (percentage >= 90) grade = 'A';
                                    else if (percentage >= 80) grade = 'B';
                                    else if (percentage >= 70) grade = 'C';
                                    else grade = 'D';
                                  }

                                  return (
                                    <tr key={m.id} className="hover:bg-slate-50/80 transition">
                                      <td className="py-4 px-6 font-bold text-slate-900">{m.name}</td>
                                      <td className="py-4 px-6 text-slate-600 font-medium">{m.asrama}</td>
                                      <td className="py-4 px-6 text-slate-600 font-medium">{m.kamar || 'Kamar 101'}</td>
                                      <td className="py-4 px-6 text-slate-700 font-semibold">{hadirCount} Hari</td>
                                      <td className="py-4 px-6 font-extrabold text-emerald-600">{percentage}%</td>
                                      <td className="py-4 px-6 text-center">
                                        <span className="px-3 py-1 rounded-md bg-emerald-100 text-emerald-800 font-bold font-mono text-xs inline-block min-w-[28px]">
                                          {grade}
                                        </span>
                                      </td>
                                    </tr>
                                  );
                                })
                              ) : (
                                <tr>
                                  <td colSpan={6} className="py-10 text-center text-slate-400 font-medium">Belum ada data Musyrif</td>
                                </tr>
                              )}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}

                    {/* II. KELOMPOK MULAHID */}
                    {(laporanMusyrifSubTab === 'semua' || laporanMusyrifSubTab === 'mulahid') && (
                      <div className="space-y-3">
                        <div className="flex items-center gap-2 border-l-4 border-teal-600 pl-3 py-0.5">
                          <h3 className="text-sm font-black text-slate-800 uppercase tracking-wide">
                            II. KELOMPOK MULAHID
                          </h3>
                          <span className="text-xs font-extrabold text-teal-700 bg-teal-50 px-2.5 py-0.5 rounded-full border border-teal-200">
                            {musyrifs.filter(m => m.name.toLowerCase().includes('mulahid') || m.kamar.toLowerCase().includes('mulahid')).length || musyrifs.length} Asatidz
                          </span>
                        </div>

                        <div className="overflow-x-auto rounded-2xl border border-slate-100">
                          <table className="w-full text-left text-sm border-collapse">
                            <thead>
                              <tr className="bg-slate-50/70 text-slate-500 font-extrabold tracking-wider uppercase text-[11px] border-b border-slate-100">
                                <th className="py-4 px-6">NAMA MULAHID</th>
                                <th className="py-4 px-6">ASRAMA</th>
                                <th className="py-4 px-6">KAMAR / TUGAS</th>
                                <th className="py-4 px-6">KEHADIRAN</th>
                                <th className="py-4 px-6">PERSENTASE</th>
                                <th className="py-4 px-6 text-center">NILAI</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-50">
                              {musyrifs.length > 0 ? (
                                musyrifs.map((m) => {
                                  const myReports = absensiList.filter(r => r.musyrifId === m.id);
                                  const totalReports = myReports.length;
                                  const hadirCount = myReports.filter(r => r.status === 'Hadir').length;
                                  const percentage = totalReports > 0 ? Math.min(100, Math.round((hadirCount / totalReports) * 100)) : 0;
                                  
                                  let grade = '-';
                                  if (totalReports > 0) {
                                    if (percentage >= 90) grade = 'A';
                                    else if (percentage >= 80) grade = 'B';
                                    else if (percentage >= 70) grade = 'C';
                                    else grade = 'D';
                                  }

                                  return (
                                    <tr key={`mulahid-${m.id}`} className="hover:bg-slate-50/80 transition">
                                      <td className="py-4 px-6 font-bold text-slate-900">{m.name}</td>
                                      <td className="py-4 px-6 text-slate-600 font-medium">{m.asrama}</td>
                                      <td className="py-4 px-6 text-slate-600 font-medium">{m.kamar || 'Kamar 101'}</td>
                                      <td className="py-4 px-6 text-slate-700 font-semibold">{hadirCount} Hari</td>
                                      <td className="py-4 px-6 font-extrabold text-emerald-600">{percentage}%</td>
                                      <td className="py-4 px-6 text-center">
                                        <span className="px-3 py-1 rounded-md bg-emerald-100 text-emerald-800 font-bold font-mono text-xs inline-block min-w-[28px]">
                                          {grade}
                                        </span>
                                      </td>
                                    </tr>
                                  );
                                })
                              ) : (
                                <tr>
                                  <td colSpan={6} className="py-10 text-center text-slate-400 font-medium">Belum ada data Mulahid</td>
                                </tr>
                              )}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  /* Individu Tab Content for Musyrif */
                  <div className="space-y-6">
                    <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 bg-slate-50 p-4 rounded-xl border border-slate-100">
                      <label className="text-xs font-bold text-slate-700 uppercase tracking-wider whitespace-nowrap">PILIH ASATIDZ / MUSYRIF:</label>
                      <select 
                        value={selectedMusyrifIdForReport || (musyrifs[0]?.id || '')}
                        onChange={(e) => setSelectedMusyrifIdForReport(e.target.value)}
                        className="bg-white border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold text-slate-800 outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 w-full sm:w-72"
                      >
                        {musyrifs.map(m => (
                          <option key={m.id} value={m.id}>{m.name} ({m.asrama} - {m.kamar})</option>
                        ))}
                      </select>
                    </div>

                    {(() => {
                      const currentMusyrif = musyrifs.find(m => m.id === (selectedMusyrifIdForReport || musyrifs[0]?.id)) || musyrifs[0];
                      if (!currentMusyrif) return <p className="text-slate-400 text-xs">Belum ada Musyrif terdaftar.</p>;

                      const myReports = absensiList.filter(r => r.musyrifId === currentMusyrif.id);
                      const totalReports = myReports.length;
                      const hadirCount = myReports.filter(r => r.status === 'Hadir').length;
                      const percentage = totalReports > 0 ? Math.min(100, Math.round((hadirCount / totalReports) * 100)) : 0;

                      return (
                        <div className="space-y-6">
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                            <div className="bg-emerald-50/60 border border-emerald-200/60 p-4 rounded-2xl text-center">
                              <p className="text-[11px] font-extrabold text-emerald-800 uppercase tracking-wider">TOTAL LAPORAN DIKIRIM</p>
                              <p className="text-2xl font-black text-emerald-700 mt-1">{totalReports} Laporan</p>
                            </div>
                            <div className="bg-blue-50/60 border border-blue-200/60 p-4 rounded-2xl text-center">
                              <p className="text-[11px] font-extrabold text-blue-800 uppercase tracking-wider">PERSENTASE KINERJA</p>
                              <p className="text-2xl font-black text-blue-700 mt-1">{percentage}%</p>
                            </div>
                            <div className="bg-amber-50/60 border border-amber-200/60 p-4 rounded-2xl text-center">
                              <p className="text-[11px] font-extrabold text-amber-800 uppercase tracking-wider">PREDIKAT KINERJA</p>
                              <p className="text-2xl font-black text-amber-700 mt-1">{totalReports === 0 ? '-' : percentage >= 90 ? 'Sangat Baik (A)' : percentage >= 80 ? 'Baik (B)' : percentage >= 70 ? 'Cukup (C)' : 'Kurang (D)'}</p>
                            </div>
                          </div>

                          <div className="border border-slate-100 rounded-2xl overflow-hidden">
                            <div className="bg-slate-50 px-5 py-3 border-b border-slate-100 font-extrabold text-xs text-slate-700 uppercase tracking-wide">
                              LOG PELAPORAN ABSENSI — {currentMusyrif.name}
                            </div>
                            <div className="overflow-x-auto">
                              <table className="w-full text-left text-xs border-collapse">
                                <thead>
                                  <tr className="border-b border-slate-100 text-slate-500 font-bold uppercase tracking-wider text-[10px] bg-white">
                                    <th className="py-3 px-5">TANGGAL & WAKTU</th>
                                    <th className="py-3 px-5">JADWAL / KEGIATAN</th>
                                    <th className="py-3 px-5">FOTO BUKTI</th>
                                    <th className="py-3 px-5">STATUS</th>
                                  </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-50">
                                  {myReports.length > 0 ? (
                                    myReports.map((report) => (
                                      <tr key={report.id} className="hover:bg-slate-50">
                                        <td className="py-3 px-5 font-semibold text-slate-700">{report.tanggal} ({report.waktu})</td>
                                        <td className="py-3 px-5 font-bold text-slate-800">{report.scheduleTitle || 'Kegiatan Asrama'}</td>
                                        <td className="py-3 px-5">
                                          {report.fotoUrl ? (
                                            <img 
                                              src={report.fotoUrl} 
                                              alt="Bukti" 
                                              className="w-10 h-10 object-cover rounded-lg border border-slate-200 cursor-pointer hover:opacity-80 transition"
                                              onClick={() => setLightboxUrl(report.fotoUrl!)}
                                            />
                                          ) : (
                                            <span className="text-slate-400 italic text-[11px]">Tidak ada foto</span>
                                          )}
                                        </td>
                                        <td className="py-3 px-5">
                                          <span className={`px-2.5 py-1 rounded-full font-extrabold text-[10px] ${
                                            report.status === 'Hadir' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                                          }`}>
                                            {report.status}
                                          </span>
                                        </td>
                                      </tr>
                                    ))
                                  ) : (
                                    <tr>
                                      <td colSpan={4} className="py-8 text-center text-slate-400 font-medium">Belum ada riwayat pelaporan dari Musyrif ini</td>
                                    </tr>
                                  )}
                                </tbody>
                              </table>
                            </div>
                          </div>
                        </div>
                      );
                    })()}
                  </div>
                )}
              </div>
            )}
            
            {/* ABSENSI KEGIATAN MUSYRIF VIEW */}
            {expandedZone === 'kegiatan_musyrif' && (
              <div className="space-y-4">
                <div className="bg-white rounded-xl shadow-xs border border-slate-100 p-4 flex items-center justify-between">
                  <div>
                    <h2 className="text-base font-black text-[#0B4A3F]">Absensi Kegiatan Musyrif (Mode Admin)</h2>
                    <p className="text-slate-500 text-xs mt-0.5">Memiliki fitur, tampilan, dan fungsi yang sama persis seperti dashboard absensi milik musyrif.</p>
                  </div>
                </div>
                <MusyrifDashboard initialTab="kegiatan" hideTopBanner={true} hideTabs={true} />
              </div>
            )}
            
            {/* ABSENSI MUTHOLAAH VIEW */}
            {expandedZone === 'mutholaah' && (
              <div className="space-y-4">
                <div className="bg-white rounded-xl shadow-xs border border-slate-100 p-4 flex items-center justify-between">
                  <div>
                    <h2 className="text-base font-black text-[#0B4A3F]">Absensi Muthola'ah Santri (Mode Admin)</h2>
                    <p className="text-slate-500 text-xs mt-0.5">Memiliki fitur, tampilan, dan fungsi yang sama persis seperti dashboard absensi muthola'ah milik musyrif.</p>
                  </div>
                </div>
                <MusyrifDashboard initialTab="mutholaah" hideTopBanner={true} hideTabs={true} />
              </div>
            )}
            
            {/* ABSENSI TIDUR VIEW */}
            {expandedZone === 'tidur' && (
              <div className="space-y-4">
                <div className="bg-white rounded-xl shadow-xs border border-slate-100 p-4 flex items-center justify-between">
                  <div>
                    <h2 className="text-base font-black text-[#0B4A3F]">Absensi Tidur Malam Santri (Mode Admin)</h2>
                    <p className="text-slate-500 text-xs mt-0.5">Memiliki fitur, tampilan, dan fungsi yang sama persis seperti dashboard absensi tidur malam milik musyrif.</p>
                  </div>
                </div>
                <MusyrifDashboard initialTab="tidur" hideTopBanner={true} hideTabs={true} />
              </div>
            )}


            {expandedZone === 'whatsapp' && (
              <div className="bg-slate-50/50 p-5 rounded-xl border border-slate-100 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xs font-extrabold text-slate-850 tracking-wider flex items-center gap-1.5 uppercase">
                      <MessageSquare className="w-4.5 h-4.5 text-emerald-600 animate-bounce" />
                      Laporan Absensi Kegiatan Pengingat WhatsApp
                    </h3>
                    <p className="text-[10px] text-slate-400 font-semibold leading-normal">Kirim notifikasi pesan kepada dewan asrama yang lalai mengirimkan absensi.</p>
                  </div>
                </div>

                <div className="space-y-3">
                  {reminderRequiredList.length > 0 ? (
                    reminderRequiredList.map((alert) => (
                      <div 
                        key={alert.id}
                        className="p-3 border border-orange-100 rounded-lg bg-white flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 shadow-xs"
                      >
                        <div className="space-y-0.5">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="px-1.5 py-0.2 bg-red-100 text-red-800 font-mono text-[9px] font-bold rounded">
                              TIDAK MELAPOR
                            </span>
                            <span className="text-xs text-slate-800 font-bold">{alert.musyrif.name} (Asrama {alert.musyrif.asrama})</span>
                          </div>
                          <span className="text-[10px] text-slate-500 block leading-snug">
                            Kegiatan: <strong className="text-slate-700">{alert.schedule.title}</strong> — Jam <strong className="text-teal-600 font-mono">{alert.schedule.time} WIB</strong>
                          </span>
                        </div>
                        <a 
                          href={alert.waUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="py-1.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-[11px] font-bold tracking-wide transition flex items-center justify-center gap-1 cursor-pointer w-fit"
                        >
                          <span>Kirim Reminder</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-10 bg-white border rounded-xl p-4 text-slate-500 font-bold text-xs space-y-1">
                      <p>🎉 Bagus sekali! Seluruh musyrif asrama aktif telah mengirimkan laporan absensi.</p>
                      <p className="text-[10px] text-slate-450 font-normal">Tidak ada warning pelaporan tertinggal untuk kegiatan hari ini.</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Expanded Content C: PDF Printing Controls Layout */}
            
{expandedZone === 'print' && (
              <div className="bg-slate-50/50 p-5 rounded-xl border border-slate-100 space-y-4">
                <div>
                  <h3 className="text-xs font-extrabold text-slate-850 tracking-wider flex items-center gap-1.5 uppercase">
                    <Printer className="w-4 h-4 text-teal-650" />
                    Cetak & Unduh Dokumen PDF Absensi
                  </h3>
                  <p className="text-[10px] text-slate-400 font-semibold leading-normal">Pilih tipe pelaporan untuk mencetak dokumen dalam print preview.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Per Asrama */}
                  <div className="bg-white p-4 border border-slate-200/55 rounded-xl space-y-3">
                    <span className="text-xs font-bold text-slate-700 block">Evaluasi Per-Asrama</span>
                    <div className="space-y-2.5">
                      <select
                        className="w-full bg-slate-50 border border-slate-200 rounded p-1.5 text-xs focus:ring-1 focus:ring-teal-500 focus:outline-none font-semibold"
                        value={printSelectedAsrama}
                        onChange={(e) => {
                          setPrintSelectedAsrama(e.target.value as AsramaName);
                          setPrintType('asrama');
                        }}
                      >
                        <option value="Al Hakim">Asrama Al Hakim</option>
                        <option value="Al Fattah">Asrama Al Fattah</option>
                        <option value="Al Karim">Asrama Al Karim</option>
                      </select>
                      <button
                        type="button"
                        className="w-full py-1.5 px-3 bg-teal-600 hover:bg-teal-700 text-white font-bold rounded text-xs transition cursor-pointer flex items-center justify-center gap-1.5"
                        onClick={() => {
                          setPrintType('asrama');
                          setShowPrintPreview(true);
                        }}
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>Pratinjau Asrama</span>
                      </button>
                    </div>
                  </div>

                  {/* Per Musyrif */}
                  <div className="bg-white p-4 border border-slate-200/55 rounded-xl space-y-3">
                    <span className="text-xs font-bold text-slate-700 block">Evaluasi Per-Individu</span>
                    <div className="space-y-2.5">
                      <select
                        className="w-full bg-slate-50 border border-slate-200 rounded p-1.5 text-xs focus:ring-1 focus:ring-teal-500 focus:outline-none font-semibold"
                        value={printSelectedMusyrif}
                        onChange={(e) => {
                          setPrintSelectedMusyrif(e.target.value);
                          setPrintType('individu');
                        }}
                      >
                        {musyrifs.map((m) => (
                          <option key={m.id} value={m.id}>
                            {m.name} ({m.asrama})
                          </option>
                        ))}
                      </select>
                      <button
                        type="button"
                        className="w-full py-1.5 px-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded text-xs transition cursor-pointer flex items-center justify-center gap-1.5"
                        onClick={() => {
                          setPrintType('individu');
                          setShowPrintPreview(true);
                        }}
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>Pratinjau Individu</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Expanded Content D: Settings form Update */}
            
            {/* SETTINGS VIEW */}
            {expandedZone === 'settings' && (
              <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden max-w-4xl mx-auto">
                <div className="p-6 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0 shadow-sm">
                      <Settings className="w-6 h-6" />
                    </div>
                    <div>
                      <h2 className="text-lg font-black text-[#0B4A3F] uppercase tracking-wide">PENGATURAN SISTEM</h2>
                      <p className="text-slate-500 text-[10px] font-bold mt-0.5 uppercase tracking-wider">Identitas Instansi, Logo & Tanda Tangan PDF</p>
                    </div>
                  </div>
                  {settingSuccess && (
                    <div className="flex items-center gap-2 text-emerald-600 font-black text-xs animate-bounce">
                      <CheckCircle className="w-4 h-4" />
                      <span>BERHASIL DISIMPAN</span>
                    </div>
                  )}
                </div>

                <form onSubmit={handleSaveSettings} className="p-6 sm:p-8 space-y-8">
                  {/* I. IDENTITAS PONDOK */}
                  <div className="space-y-5">
                    <div className="flex items-center gap-2 border-l-4 border-emerald-600 pl-3 py-0.5">
                      <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest">I. IDENTITAS INSTANSI</h3>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-1.5">
                        <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest">NAMA PONDOK PESANTREN</label>
                        <input 
                          type="text" 
                          value={pondokName} 
                          onChange={(e) => setPondokName(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-800 outline-none focus:border-emerald-600 focus:bg-white transition" 
                        />
                      </div>
                      <div className="space-y-1.5">
                        <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest">LOGO INSTANSI</label>
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center overflow-hidden shrink-0 shadow-xs">
                            <img src={pondokLogo} alt="Logo" className="w-full h-full object-contain" />
                          </div>
                          <label className="flex-1 cursor-pointer">
                            <div className="w-full bg-slate-50 border border-slate-200 border-dashed rounded-xl px-4 py-2.5 text-[11px] font-black text-emerald-700 text-center hover:bg-emerald-50 transition uppercase tracking-wider">
                              GANTI LOGO
                            </div>
                            <input type="file" accept="image/*" className="hidden" onChange={handleLogoChange} />
                          </label>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest">ALAMAT LENGKAP (HEADER PDF)</label>
                      <textarea 
                        rows={2} 
                        value={pondokAlamat} 
                        onChange={(e) => setPondokAlamat(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-800 outline-none focus:border-emerald-600 focus:bg-white transition resize-none"
                      ></textarea>
                    </div>
                  </div>

                  {/* II. PENGASUH & KETUA */}
                  <div className="space-y-5">
                    <div className="flex items-center gap-2 border-l-4 border-indigo-600 pl-3 py-0.5">
                      <h3 className="text-xs font-black text-slate-800 uppercase tracking-widest">II. PEJABAT BERWENANG (Tanda Tangan)</h3>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      {/* PENGASUH */}
                      <div className="bg-slate-50/50 p-5 rounded-2xl border border-slate-100 space-y-4">
                        <div className="space-y-1.5">
                          <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest">NAMA PENGASUH</label>
                          <input 
                            type="text" 
                            value={pondokPengasuh} 
                            onChange={(e) => setPondokPengasuh(e.target.value)}
                            placeholder="Contoh: KH. Muwafiq Amir"
                            className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-800 outline-none focus:border-indigo-600 transition" 
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest">TANDA TANGAN PENGASUH</label>
                          <div className="h-32 bg-white border-2 border-dashed border-slate-200 rounded-xl flex items-center justify-center overflow-hidden relative group">
                            {pondokPengasuhTtd ? (
                              <img src={pondokPengasuhTtd} alt="TTD Pengasuh" className="max-h-full max-w-full object-contain p-2" />
                            ) : (
                              <div className="text-center p-4">
                                <Printer className="w-6 h-6 text-slate-300 mx-auto mb-1" />
                                <p className="text-[10px] text-slate-400 font-bold uppercase">Belum ada TTD</p>
                              </div>
                            )}
                            <label className="absolute inset-0 bg-indigo-600/90 flex flex-col items-center justify-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer">
                              <PlusCircle className="text-white w-6 h-6" />
                              <span className="text-white text-[10px] font-black uppercase">Upload TTD</span>
                              <input type="file" accept="image/*" className="hidden" onChange={(e) => handleTtdChange(e, 'pengasuh')} />
                            </label>
                          </div>
                        </div>
                      </div>

                      {/* KETUA PONDOK */}
                      <div className="bg-slate-50/50 p-5 rounded-2xl border border-slate-100 space-y-4">
                        <div className="space-y-1.5">
                          <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest">NAMA KETUA PONDOK</label>
                          <input 
                            type="text" 
                            value={pondokKetua} 
                            onChange={(e) => setPondokKetua(e.target.value)}
                            placeholder="Contoh: Ust. Hamdan Syafi'i"
                            className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm font-bold text-slate-800 outline-none focus:border-indigo-600 transition" 
                          />
                        </div>
                        <div className="space-y-2">
                          <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest">TANDA TANGAN KETUA</label>
                          <div className="h-32 bg-white border-2 border-dashed border-slate-200 rounded-xl flex items-center justify-center overflow-hidden relative group">
                            {pondokKetuaTtd ? (
                              <img src={pondokKetuaTtd} alt="TTD Ketua" className="max-h-full max-w-full object-contain p-2" />
                            ) : (
                              <div className="text-center p-4">
                                <Printer className="w-6 h-6 text-slate-300 mx-auto mb-1" />
                                <p className="text-[10px] text-slate-400 font-bold uppercase">Belum ada TTD</p>
                              </div>
                            )}
                            <label className="absolute inset-0 bg-indigo-600/90 flex flex-col items-center justify-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer">
                              <PlusCircle className="text-white w-6 h-6" />
                              <span className="text-white text-[10px] font-black uppercase">Upload TTD</span>
                              <input type="file" accept="image/*" className="hidden" onChange={(e) => handleTtdChange(e, 'ketua')} />
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="pt-6 border-t border-slate-100 flex items-center justify-between">
                    <p className="text-[10px] text-slate-400 font-bold uppercase italic max-w-xs leading-relaxed">
                      *Perubahan ini akan langsung berdampak pada seluruh dokumen PDF yang dicetak.
                    </p>
                    <button 
                      type="submit"
                      className="bg-emerald-600 hover:bg-emerald-700 text-white px-10 py-3 rounded-xl font-black text-sm transition shadow-lg shadow-emerald-600/20 active:scale-95 flex items-center gap-2"
                    >
                      <Check className="w-5 h-5" />
                      SIMPAN PERUBAHAN
                    </button>
                  </div>
                </form>
              </div>
            )}
          </div>
        )}

      </div>

      {/* ========================================================== */}
      {/* 3. LIGHTBOX POPUP - VIEW PHOTOS FULL RESOLUTION (print:hidden) */}
      {lightboxUrl && (
        <div 
          className="fixed inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center z-50 p-4 print:hidden"
          onClick={() => setLightboxUrl(null)}
        >
          <div className="bg-white p-3 rounded-2xl max-w-sm sm:max-w-md w-full relative border border-slate-100 shadow-2xl animate-scale-up" onClick={e => e.stopPropagation()}>
            <button
              className="absolute -top-3 -right-3 bg-slate-800 hover:bg-slate-900 text-white w-7 h-7 rounded-full flex items-center justify-center leading-none text-xs"
              onClick={() => setLightboxUrl(null)}
            >
              ✕
            </button>
            <div className="w-full h-80 rounded-xl bg-slate-200 overflow-hidden border border-slate-100">
              <img src={lightboxUrl} alt="Laporan Absensi Detail" className="w-full h-full object-contain" referrerPolicy="no-referrer" />
            </div>
            <p className="text-center text-[10px] font-mono text-slate-400 mt-2 font-bold uppercase">Foto Bukti Kegiatan Lapangan Musyrif</p>
          </div>
        </div>
      )}

      {/* ========================================================== */}
      {/* 4. MODAL PRINT PREVIEW ENGINE - Triggered via Browser Print Window */}
      {showPrintPreview && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center z-50 p-4 print:static print:inset-auto print:bg-white print:p-0 print:block">
          <div className="bg-white rounded-2xl w-full max-w-4xl max-h-[90vh] overflow-y-auto flex flex-col border border-slate-200 shadow-2xl print:max-w-full print:max-h-full print:shadow-none print:border-none print:rounded-none print:exact-colors print:overflow-visible">
            
            {/* Nav controls - Hidden on Print */}
            <div className="bg-slate-50 border-b border-slate-100 p-4 shrink-0 flex items-center justify-between print:hidden">
              <div className="space-y-0.5">
                <span className="text-[10px] font-black tracking-widest text-teal-700 bg-teal-50 px-2 py-0.5 rounded uppercase">DRAFT PREVIEW CETAK</span>
                <h4 className="text-sm font-extrabold text-slate-800 leading-none mt-1">Laporan Keseluruhan Musyrif</h4>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  className={`py-1.5 px-3.5 ${isGeneratingPdf ? 'bg-slate-300' : 'bg-teal-600 hover:bg-teal-700'} text-white rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer`}
                  onClick={triggerPrintWindow}
                  disabled={isGeneratingPdf}
                >
                  <Printer className={`w-4 h-4 ${isGeneratingPdf ? 'animate-pulse' : ''}`} />
                  <span>{isGeneratingPdf ? 'Menyimpan...' : 'Cetak / Save ke PDF'}</span>
                </button>
                <button
                  type="button"
                  className="py-1.5 px-3.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg text-xs font-bold transition cursor-pointer"
                  onClick={() => setShowPrintPreview(false)}
                >
                  Tutup Preview
                </button>
              </div>
            </div>

            {/* Print Friendly Page Markup - Wrapped in responsive scroll container with fixed aspect layout */}
            <div className="flex-1 overflow-auto bg-slate-100 p-4 sm:p-6 md:p-8 flex justify-center min-h-0 print:p-0 print:bg-white print:overflow-visible">
              <div 
                style={{ 
                  width: previewScale === 1 ? '800px' : `${800 * previewScale}px`, 
                  height: previewScale === 1 ? 'auto' : (typeof previewHeight === 'number' ? `${previewHeight}px` : 'auto'),
                  overflow: 'visible'
                }}
                className="relative print:w-full print:h-auto print:overflow-visible shrink-0 transition-all duration-150"
              >
                <div 
                  ref={sheetRef}
                  id="rekap-print-sheet" 
                  className="p-8 space-y-6 bg-white w-[800px] min-w-[800px] shadow-lg border border-slate-200/50 rounded-2xl print:shadow-none print:border-none print:p-0 print:m-0 print:w-full print:min-w-0 print:rounded-none origin-top-left transition-transform duration-150" 
                  style={{ 
                    WebkitPrintColorAdjust: 'exact', 
                    printColorAdjust: 'exact',
                    transform: previewScale === 1 ? 'none' : `scale(${previewScale})`,
                  }}
                >
              {/* Report Header letterhead - Cleaned up per user request */}
              <div className="flex items-center justify-between border-b-2 border-teal-800 pb-5">
                <div className="flex items-center gap-4 text-left">
                  <div className="w-14 h-14 rounded-full bg-teal-50 p-1 border border-teal-100 flex items-center justify-center overflow-hidden shrink-0">
                    <img src={pondokSettings.logoUrl} crossOrigin="anonymous" alt="Logo" className="w-full h-full object-cover rounded-full" referrerPolicy="no-referrer" />
                  </div>
                  <div>
                    <h2 className="text-lg font-black text-teal-800 tracking-tight leading-6 uppercase">{pondokSettings.namaPondok}</h2>
                    <p className="text-[10px] text-slate-400 font-bold leading-normal font-mono">{pondokSettings.alamat}</p>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <span className="text-[10px] font-mono text-slate-400 block font-bold uppercase">{printType === 'asrama' ? 'REKAP EVALUASI ASRAMA KESELURUHAN' : 'REKAP EVALUASI KINERJA INDIVIDU'}</span>
                  <span className="text-xs bg-slate-150 px-2 py-0.5 font-bold font-mono text-slate-705 text-teal-700 border border-teal-100 block mt-1 rounded-sm">
                    {dateStrToday}
                  </span>
                </div>
              </div>

              {/* Report Body */}
              <div className="space-y-6">
                <div className="space-y-1">
                  <h3 className="text-sm font-extrabold text-slate-800 tracking-tight flex items-center justify-between">
                    <span>{printTitle}</span>
                    <span className="px-2 py-0.5 bg-slate-100 text-[10px] font-mono text-slate-500 rounded">Total: {printType === 'asrama' ? musyrifs.filter(m => m.asrama === printSelectedAsrama).length : 1} Musyrif</span>
                  </h3>
                  <p className="text-[11px] text-slate-400">Dicetak otomatis dari sistem Absensi Musyrif BM tanggal {new Date().toLocaleDateString('id-ID')}.</p>
                </div>

                {(() => {
                  let filteredMusyrifs = musyrifs;
                  if (printType === 'asrama') {
                    filteredMusyrifs = musyrifs.filter(m => m.asrama === printSelectedAsrama);
                  } else {
                    filteredMusyrifs = musyrifs.filter(m => m.id === printSelectedMusyrif);
                  }

                  const printStats = filteredMusyrifs.map(m => {
                    const records = printRecords.filter(r => r.musyrifId === m.id);
                    const total = records.length;
                    const hadir = records.filter(r => r.status === 'Hadir' || r.status === 'Terlambat').length;
                    const percentage = total === 0 ? 0 : Math.round((hadir / total) * 100);
                    
                    let grade = 'D';
                    if (percentage >= 85) grade = 'A';
                    else if (percentage >= 70) grade = 'B';
                    else if (percentage >= 50) grade = 'C';
                    
                    let gradeClass = 'text-rose-700 bg-rose-50 border-rose-300 font-black';
                    if (grade === 'A') gradeClass = 'text-emerald-700 bg-emerald-50 border-emerald-300 font-black';
                    else if (grade === 'B') gradeClass = 'text-blue-700 bg-blue-50 border-blue-300 font-black';
                    else if (grade === 'C') gradeClass = 'text-amber-700 bg-amber-50 border-amber-300 font-black';

                    return { ...m, total, hadir, percentage, grade, gradeClass };
                  });
                  printStats.sort((a, b) => b.percentage - a.percentage);

                  const gradeCounts = {
                    A: printStats.filter(s => s.grade === 'A').length,
                    B: printStats.filter(s => s.grade === 'B').length,
                    C: printStats.filter(s => s.grade === 'C').length,
                    D: printStats.filter(s => s.grade === 'D').length,
                  };

                  let pieData: {name: string, value: number, color: string}[] = [];
                  
                  if (printType === 'asrama') {
                    pieData = [
                      { name: 'Sangat Baik (A)', value: gradeCounts.A, color: '#10b981' },
                      { name: 'Baik (B)', value: gradeCounts.B, color: '#3b82f6' },
                      { name: 'Cukup (C)', value: gradeCounts.C, color: '#f59e0b' },
                      { name: 'Kurang (D)', value: gradeCounts.D, color: '#ef4444' },
                    ].filter(d => d.value > 0);
                  } else {
                    const mstat = printStats[0];
                    if (mstat && mstat.total > 0) {
                      pieData = [
                        { name: 'Kehadiran (Hadir/Telat)', value: mstat.hadir, color: '#10b981' },
                        { name: 'Absen/Izin', value: mstat.total - mstat.hadir, color: '#ef4444' }
                      ].filter(d => d.value > 0);
                    }
                  }

                  return (
                    <>
                      {pieData.length > 0 && (
                        <div className="flex bg-slate-50 border border-slate-100 p-4 rounded-xl items-center gap-6">
                          <div className="w-[200px] h-[160px] flex-shrink-0">
                            <ResponsiveContainer width="100%" height="100%">
                              <PieChart>
                                <Pie
                                  data={pieData}
                                  cx="50%"
                                  cy="50%"
                                  innerRadius={40}
                                  outerRadius={70}
                                  paddingAngle={2}
                                  dataKey="value"
                                >
                                  {pieData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={entry.color} />
                                  ))}
                                </Pie>
                                <RechartsTooltip />
                              </PieChart>
                            </ResponsiveContainer>
                          </div>
                          <div className="flex-1 grid grid-cols-2 gap-3">
                            {pieData.map(d => (
                              <div key={d.name} className="flex items-center gap-3 bg-white p-2.5 rounded-lg border border-slate-200 shadow-sm">
                                 <div className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: d.color }}></div>
                                 <div className="flex-1">
                                   <span className="text-[10px] text-slate-500 font-bold block leading-tight">{d.name}</span>
                                   <span className="text-sm font-black text-slate-800">{d.value} <span className="text-[10px] text-slate-400 font-normal">{printType === 'asrama' ? 'Musyrif' : 'Sesi'}</span></span>
                                 </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {printType === 'asrama' ? (
                        <div className="overflow-hidden border border-slate-200 rounded-lg">
                          <table className="w-full text-left text-xs border-collapse">
                            <thead>
                              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase font-mono text-[9px]">
                                <th className="py-2 px-3 text-center w-10 border-r border-slate-100">No</th>
                                <th className="py-2 px-3 border-r border-slate-100">Nama Lengkap (Asrama)</th>
                                <th className="py-2 px-3 border-r border-slate-100 text-center w-20">Total Sesi</th>
                                <th className="py-2 px-3 border-r border-slate-100 w-48 text-center">Tingkat Kehadiran</th>
                                <th className="py-2 px-3 text-center w-20">Nilai Mutu</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-150 text-slate-700 font-semibold text-[11px]">
                              {printStats.length > 0 ? (
                                printStats.map((item, idx) => (
                                  <tr key={item.id} className="bg-white border-b border-slate-100 last:border-0">
                                    <td className="py-1.5 px-3 text-center font-mono font-bold text-slate-400 border-r border-slate-50">{idx + 1}</td>
                                    <td className="py-1.5 px-3 border-r border-slate-50">
                                      <span className="text-slate-800 font-bold block leading-tight">{item.name}</span>
                                      <span className="text-[8px] text-slate-500 block font-mono uppercase tracking-tighter">Asrama {item.asrama} — {item.kamar}</span>
                                    </td>
                                    <td className="py-1.5 px-3 text-center font-bold font-mono border-r border-slate-50">{item.total}</td>
                                    <td className="py-1.5 px-4 border-r border-slate-50">
                                      <div className="flex items-center gap-2">
                                        <div className="flex-1 h-2.5 bg-slate-100 rounded-full overflow-hidden border border-slate-200/50">
                                          <div 
                                            className={`h-full ${item.percentage >= 85 ? 'bg-emerald-500' : item.percentage >= 70 ? 'bg-blue-500' : item.percentage >= 50 ? 'bg-amber-500' : 'bg-rose-500'}`} 
                                            style={{ width: `${item.percentage}%` }}
                                          ></div>
                                        </div>
                                        <span className="text-[9px] w-8 text-right font-mono font-black">{item.percentage}%</span>
                                      </div>
                                    </td>
                                    <td className="py-1.5 px-3 text-center">
                                      <span className={`inline-block px-2.5 py-0.5 rounded text-[11px] font-black font-mono border shadow-sm ${item.gradeClass}`}>
                                        {item.grade}
                                      </span>
                                    </td>
                                  </tr>
                                ))
                              ) : (
                                <tr>
                                  <td colSpan={5} className="py-12 text-center text-slate-400 font-semibold">
                                    Tidak ada data musyrif.
                                  </td>
                                </tr>
                              )}
                            </tbody>
                          </table>
                        </div>
                      ) : (
                        <div className="overflow-hidden border border-slate-200 rounded-lg">
                          <table className="w-full text-left text-xs border-collapse">
                            <thead>
                              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase font-mono text-[9px]">
                                <th className="py-2 px-3 text-center w-10">No</th>
                                <th className="py-2 px-3">Waktu & Tanggal</th>
                                <th className="py-2 px-3">Kegiatan Wajib</th>
                                <th className="py-2 px-3 text-center">Status Kehadiran</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-150 text-slate-700 font-semibold text-[11px]">
                              {printRecords.length > 0 ? (
                                printRecords.map((item, idx) => (
                                  <tr key={item.id} className="bg-white">
                                    <td className="py-2.5 px-3 text-center font-mono font-bold text-slate-400">{idx + 1}</td>
                                    <td className="py-2.5 px-3">
                                      <span>{item.hari}, {item.tanggal}</span>
                                      <span className="text-[9px] text-slate-400 block font-mono">{item.waktu} WIB</span>
                                    </td>
                                    <td className="py-2.5 px-3 font-medium">
                                      <span>{item.kegiatan}</span>
                                      {item.catatan && (
                                        <span className="block text-[10px] text-slate-400 font-semibold italic mt-0.5">
                                          "{item.catatan}"
                                        </span>
                                      )}
                                    </td>
                                    <td className="py-2.5 px-3 text-center">
                                      <span className={`font-bold border rounded-full px-2 py-0.5 text-[10px] ${item.status === 'Hadir' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : item.status === 'Terlambat' ? 'bg-amber-50 text-amber-700 border-amber-200' : 'bg-red-50 text-red-700 border-red-200'}`}>
                                        {item.status}
                                      </span>
                                    </td>
                                  </tr>
                                ))
                              ) : (
                                <tr>
                                  <td colSpan={4} className="py-12 text-center text-slate-400 font-semibold">
                                    Tidak ditemukan data riwayat laporan absensi.
                                  </td>
                                </tr>
                              )}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </>
                  );
                })()}

                <div className="grid grid-cols-4 gap-3 mt-6 print:mt-4 text-[11px] font-bold border-t border-slate-100 pt-5">
                  <div className="flex flex-col items-center justify-center p-3 rounded-xl bg-emerald-500 text-white shadow-sm border border-emerald-600">
                    <span className="text-lg font-black bg-white/20 w-8 h-8 rounded-full flex items-center justify-center mb-1">A</span>
                    <span className="opacity-90 text-[10px]">Sangat Baik (≥ 85%)</span>
                  </div>
                  <div className="flex flex-col items-center justify-center p-3 rounded-xl bg-blue-500 text-white shadow-sm border border-blue-600">
                    <span className="text-lg font-black bg-white/20 w-8 h-8 rounded-full flex items-center justify-center mb-1">B</span>
                    <span className="opacity-90 text-[10px]">Baik (≥ 70%)</span>
                  </div>
                  <div className="flex flex-col items-center justify-center p-3 rounded-xl bg-amber-500 text-white shadow-sm border border-amber-600">
                    <span className="text-lg font-black bg-white/20 w-8 h-8 rounded-full flex items-center justify-center mb-1">C</span>
                    <span className="opacity-90 text-[10px]">Cukup (≥ 50%)</span>
                  </div>
                  <div className="flex flex-col items-center justify-center p-3 rounded-xl bg-red-500 text-white shadow-sm border border-red-650">
                    <span className="text-lg font-black bg-white/20 w-8 h-8 rounded-full flex items-center justify-center mb-1">D</span>
                    <span className="opacity-90 text-[10px]">Kurang (&lt; 50%)</span>
                  </div>
                </div>

                {/* PDF Signatures Section */}
                <div className="grid grid-cols-2 gap-10 pt-10 mt-10 border-t border-slate-100">
                  <div className="text-center space-y-16">
                    <div className="space-y-1">
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Mengetahui,</p>
                      <p className="text-xs font-black text-slate-800 uppercase tracking-tight">Pengasuh Pesantren</p>
                    </div>
                    <div className="h-20 flex items-center justify-center">
                      {pondokSettings.pengasuhTtdUrl ? (
                        <img src={pondokSettings.pengasuhTtdUrl} alt="TTD Pengasuh" className="max-h-full object-contain" crossOrigin="anonymous" />
                      ) : (
                        <div className="w-32 h-px bg-slate-200" />
                      )}
                    </div>
                    <p className="text-xs font-black text-slate-900 border-b border-slate-900 pb-1 inline-block px-4">
                      {pondokSettings.pengasuh}
                    </p>
                  </div>

                  <div className="text-center space-y-16">
                    <div className="space-y-1">
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Hormat Kami,</p>
                      <p className="text-xs font-black text-slate-800 uppercase tracking-tight">Ketua Pondok / Koordinator</p>
                    </div>
                    <div className="h-20 flex items-center justify-center">
                      {pondokSettings.ketuaPondokTtdUrl ? (
                        <img src={pondokSettings.ketuaPondokTtdUrl} alt="TTD Ketua" className="max-h-full object-contain" crossOrigin="anonymous" />
                      ) : (
                        <div className="w-32 h-px bg-slate-200" />
                      )}
                    </div>
                    <p className="text-xs font-black text-slate-900 border-b border-slate-900 pb-1 inline-block px-4">
                      {pondokSettings.ketuaPondok}
                    </p>
                  </div>
                </div>

              </div>
            </div>
            </div>
            </div>
            </div>
          </div>
        )}

      {confirmModal && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity" onClick={() => setConfirmModal(null)} />
          <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl max-w-md w-full overflow-hidden relative z-10 p-6 space-y-4">
            <div className="flex items-start gap-3">
              <div className={`p-2 rounded-full shrink-0 ${confirmModal.danger ? 'bg-rose-50 text-rose-600' : 'bg-teal-50 text-teal-600'}`}>
                <AlertTriangle size={24} />
              </div>
              <div className="space-y-1.5 flex-1">
                <h3 className="text-sm font-black text-slate-800 tracking-wide uppercase">{confirmModal.title}</h3>
                <p className="text-xs text-slate-500 font-bold leading-relaxed whitespace-pre-wrap">{confirmModal.message}</p>
              </div>
            </div>
            <div className="flex justify-end gap-2.5 pt-2">
              {!confirmModal.isAlert && (
                <button
                  type="button"
                  onClick={() => setConfirmModal(null)}
                  className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl cursor-pointer transition"
                >
                  Batal
                </button>
              )}
              <button
                type="button"
                onClick={async () => {
                  const onConfirm = confirmModal.onConfirm;
                  setConfirmModal(null);
                  if (onConfirm) {
                    await onConfirm();
                  }
                }}
                className={`px-4 py-2 text-xs font-black text-white rounded-xl cursor-pointer transition border-b-2 ${
                  confirmModal.danger
                    ? 'bg-rose-600 hover:bg-rose-700 border-rose-800'
                    : 'bg-teal-600 hover:bg-teal-700 border-teal-800'
                }`}
              >
                {confirmModal.isAlert ? 'OK' : 'Yakin, Lanjutkan'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PRATINJAU PDF REKAPAN DATA ASRAMA & KAMAR MODAL */}
      {showRekapanPdfModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col shadow-2xl">
            <div className="p-4 bg-emerald-950 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Printer className="w-5 h-5 text-emerald-400" />
                <h3 className="font-extrabold text-sm uppercase tracking-wide">
                  Pratinjau Cetak PDF - Rekapan Data Asrama & Kamar
                </h3>
              </div>
              <button
                onClick={() => setShowRekapanPdfModal(false)}
                className="p-1 hover:bg-white/10 rounded-lg text-slate-300 hover:text-white transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto flex-1 bg-slate-50 space-y-4">
              <div className="bg-white p-8 rounded-xl border border-slate-200 shadow-sm space-y-6">
                <div className="text-center border-b pb-4 border-slate-200">
                  <h2 className="text-lg font-black text-slate-900 uppercase tracking-wide">
                    {pondokSettings.namaPondok || 'PONDOK PESANTREN'}
                  </h2>
                  <p className="text-xs text-slate-600 font-medium">{pondokSettings.alamat}</p>
                  <h3 className="text-sm font-extrabold text-emerald-900 mt-3 uppercase tracking-wider">
                    LAPORAN REKAPAN DATA ASRAMA DAN KAMAR
                  </h3>
                </div>

                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-emerald-900 text-white font-extrabold uppercase text-[10px]">
                      <th className="py-2.5 px-3 text-center border border-emerald-900 w-10">NO</th>
                      <th className="py-2.5 px-3 border border-emerald-900">ASRAMA</th>
                      <th className="py-2.5 px-3 border border-emerald-900">KAMAR</th>
                      <th className="py-2.5 px-3 text-center border border-emerald-900">KAPASITAS</th>
                      <th className="py-2.5 px-3 text-center border border-emerald-900">TERISI</th>
                      <th className="py-2.5 px-3 border border-emerald-900">MUSYRIF KAMAR</th>
                      <th className="py-2.5 px-3 border border-emerald-900">MULAHID</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 font-medium text-slate-700">
                    {rekapanKamarList.map((item, idx) => (
                      <tr key={idx} className="border-b border-slate-200">
                        <td className="py-2 px-3 text-center font-mono font-bold text-slate-400 border">{idx + 1}</td>
                        <td className="py-2 px-3 font-bold text-slate-900 border">{item.asrama}</td>
                        <td className="py-2 px-3 font-mono font-bold border">{item.kamar}</td>
                        <td className="py-2 px-3 text-center font-bold border">{item.kapasitas}</td>
                        <td className="py-2 px-3 text-center font-bold border">{item.terisi}</td>
                        <td className="py-2 px-3 border">{item.musyrifNames || '-'}</td>
                        <td className="py-2 px-3 border">{item.mulahidNames || '-'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                {/* PDF Signatures Section */}
                <div className="grid grid-cols-2 gap-10 pt-10 mt-10 border-t border-slate-100">
                  <div className="text-center space-y-16">
                    <div className="space-y-1">
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Mengetahui,</p>
                      <p className="text-xs font-black text-slate-800 uppercase tracking-tight">Pengasuh Pesantren</p>
                    </div>
                    <div className="h-20 flex items-center justify-center">
                      {pondokSettings.pengasuhTtdUrl ? (
                        <img src={pondokSettings.pengasuhTtdUrl} alt="TTD Pengasuh" className="max-h-full object-contain" crossOrigin="anonymous" />
                      ) : (
                        <div className="w-32 h-px bg-slate-200" />
                      )}
                    </div>
                    <p className="text-xs font-black text-slate-900 border-b border-slate-900 pb-1 inline-block px-4">
                      {pondokSettings.pengasuh}
                    </p>
                  </div>

                  <div className="text-center space-y-16">
                    <div className="space-y-1">
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Hormat Kami,</p>
                      <p className="text-xs font-black text-slate-800 uppercase tracking-tight">Ketua Pondok / Koordinator</p>
                    </div>
                    <div className="h-20 flex items-center justify-center">
                      {pondokSettings.ketuaPondokTtdUrl ? (
                        <img src={pondokSettings.ketuaPondokTtdUrl} alt="TTD Ketua" className="max-h-full object-contain" crossOrigin="anonymous" />
                      ) : (
                        <div className="w-32 h-px bg-slate-200" />
                      )}
                    </div>
                    <p className="text-xs font-black text-slate-900 border-b border-slate-900 pb-1 inline-block px-4">
                      {pondokSettings.ketuaPondok}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-4 bg-white border-t border-slate-200 flex items-center justify-end gap-3">
              <button
                onClick={() => setShowRekapanPdfModal(false)}
                className="px-4 py-2 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition cursor-pointer"
              >
                Tutup
              </button>
              <button
                onClick={() => {
                  window.print();
                }}
                className="px-5 py-2 text-xs font-black text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition shadow-xs flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-4 h-4" /> Cetak Sekarang
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PRATINJAU PDF LAPORAN SANTRI / MUSYRIF MODAL */}
      {reportPdfModal.open && (
        <div className="fixed inset-0 z-[100] bg-slate-900/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col shadow-2xl">
            <div className="p-4 bg-[#0B4A3F] text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Printer className="w-5 h-5 text-emerald-400" />
                <h3 className="font-extrabold text-sm uppercase tracking-wide">
                  Pratinjau Cetak PDF - Laporan Absensi {reportPdfModal.type === 'santri' ? 'Santri' : 'Asatidz'}
                </h3>
              </div>
              <button
                onClick={() => setReportPdfModal({ ...reportPdfModal, open: false })}
                className="p-1 hover:bg-white/10 rounded-lg text-slate-300 hover:text-white transition cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto flex-1 bg-slate-100/50">
              <div id="dynamic-report-sheet" className="bg-white p-8 sm:p-12 shadow-md mx-auto w-full max-w-[800px] min-h-[1100px] flex flex-col">
                {/* Header PDF */}
                <div className="flex items-center gap-6 border-b-2 border-slate-900 pb-4 mb-6">
                  <div className="w-20 h-20 shrink-0 flex items-center justify-center border-2 border-slate-100 p-1 rounded-xl">
                    <img src={pondokLogo} alt="Logo" className="max-w-full max-h-full object-contain" />
                  </div>
                  <div className="flex-1">
                    <h1 className="text-xl font-black text-slate-900 uppercase tracking-tighter leading-none mb-1">{pondokName}</h1>
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2 leading-relaxed">{pondokAlamat}</p>
                    <div className="h-px bg-slate-200 w-2/3" />
                    <h2 className="text-xs font-black text-[#0B4A3F] mt-2 uppercase tracking-widest underline underline-offset-4">
                      LAPORAN ABSENSI & KEDISIPLINAN {reportPdfModal.type === 'santri' ? 'SANTRI' : 'ASATIDZ'}
                    </h2>
                  </div>
                </div>

                {/* Content */}
                <div className="flex-1 space-y-4">
                  {reportPdfModal.type === 'santri' ? (
                    laporanSantriSubTab === 'individu' ? (
                      /* Individual Santri Report */
                      (() => {
                        const currentSantri = santris.find(s => s.id === (selectedSantriIdForReport || santris[0]?.id)) || santris[0];
                        const mLogs = absensiMutholaahList.filter(r => r.santriId === currentSantri?.id);
                        const tLogs = absensiTidurList.filter(r => r.santriId === currentSantri?.id);
                        const allLogs = [...mLogs, ...tLogs].sort((a, b) => b.tanggal.localeCompare(a.tanggal));
                        const hCount = allLogs.filter(l => l.status?.includes('Hadir')).length;
                        const perc = allLogs.length > 0 ? Math.round((hCount / allLogs.length) * 100) : 0;

                        return (
                          <div className="space-y-6">
                            <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 grid grid-cols-2 gap-4">
                              <div className="space-y-0.5">
                                <p className="text-[9px] font-black text-slate-400 uppercase">Nama Lengkap Santri</p>
                                <p className="text-sm font-black text-[#0B4A3F] uppercase">{currentSantri?.name}</p>
                              </div>
                              <div className="space-y-0.5">
                                <p className="text-[9px] font-black text-slate-400 uppercase">Kamar & Asrama</p>
                                <p className="text-sm font-black text-slate-700 uppercase">{currentSantri?.kamar} / {currentSantri?.asrama}</p>
                              </div>
                            </div>

                            <div className="grid grid-cols-3 gap-3">
                              <div className="p-3 rounded-xl border border-emerald-100 bg-emerald-50 text-center">
                                <p className="text-[8px] font-black text-emerald-800 uppercase tracking-widest">Total Hadir</p>
                                <p className="text-lg font-black text-emerald-600 mt-0.5">{hCount} Hari</p>
                              </div>
                              <div className="p-3 rounded-xl border border-blue-100 bg-blue-50 text-center">
                                <p className="text-[8px] font-black text-blue-800 uppercase tracking-widest">Persentase</p>
                                <p className="text-lg font-black text-blue-600 mt-0.5">{perc}%</p>
                              </div>
                              <div className="p-3 rounded-xl border border-slate-100 bg-slate-50 text-center">
                                <p className="text-[8px] font-black text-slate-800 uppercase tracking-widest">Predikat</p>
                                {(() => {
                                  const grade = perc >= 90 ? 'A' : perc >= 80 ? 'B' : perc >= 70 ? 'C' : 'D';
                                  const colorClass = grade === 'A' ? 'text-emerald-600' : grade === 'B' ? 'text-blue-600' : grade === 'C' ? 'text-amber-500' : 'text-rose-600';
                                  return <p className={`text-lg font-black mt-0.5 ${colorClass}`}>{grade}</p>;
                                })()}
                              </div>
                            </div>

                            <table className="w-full text-[11px] border-collapse">
                              <thead>
                                <tr className="bg-slate-900 text-white uppercase font-black text-[9px]">
                                  <th className="py-2.5 px-4 text-center border border-slate-900 w-10">NO</th>
                                  <th className="py-2.5 px-4 border border-slate-900">TANGGAL & WAKTU</th>
                                  <th className="py-2.5 px-4 border border-slate-900">KEGIATAN</th>
                                  <th className="py-2.5 px-4 text-center border border-slate-900">STATUS</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-slate-200">
                                {allLogs.map((log, i) => (
                                  <tr key={log.id} className="border-b border-slate-100 last:border-0">
                                    <td className="py-1.5 px-4 text-center font-bold text-slate-400 border">{i + 1}</td>
                                    <td className="py-1.5 px-4 font-bold border leading-tight">{log.hari}, {log.tanggal}<br/><span className="text-[9px] text-slate-400">{log.waktu} WIB</span></td>
                                    <td className="py-1.5 px-4 font-bold border uppercase leading-tight">{log.kegiatan}</td>
                                    <td className="py-1.5 px-4 text-center border">
                                      <span className={`font-black uppercase text-[9px] px-2 py-0.5 rounded border ${log.status?.includes('Hadir') ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-rose-50 text-rose-700 border-rose-200'}`}>
                                        {log.status}
                                      </span>
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        );
                      })()
                    ) : (
                      /* Bulk Santri Report */
                      <table className="w-full text-[11px] border-collapse">
                        <thead>
                          <tr className="bg-slate-900 text-white uppercase font-black text-[9px]">
                            <th className="py-2.5 px-4 text-center border border-slate-900 w-10">NO</th>
                            <th className="py-2.5 px-4 border border-slate-900">NAMA SANTRI</th>
                            <th className="py-2.5 px-4 border border-slate-900">KAMAR</th>
                            <th className="py-2.5 px-4 text-center border border-slate-900 w-24">HADIR</th>
                            <th className="py-2.5 px-4 text-center border border-slate-900 w-24">PERSEN</th>
                            <th className="py-2.5 px-4 text-center border border-slate-900 w-20">NILAI</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200">
                          {santris.map((santri, idx) => {
                            const h = absensiMutholaahList.filter(r => r.santriId === santri.id && r.status?.includes('Hadir')).length + absensiTidurList.filter(r => r.santriId === santri.id && r.status?.includes('Hadir')).length;
                            const t = absensiMutholaahList.filter(r => r.santriId === santri.id).length + absensiTidurList.filter(r => r.santriId === santri.id).length;
                            const p = t > 0 ? Math.round((h/t)*100) : 0;
                            return (
                                <tr key={santri.id} className="border-b border-slate-100 last:border-0">
                                  <td className="py-1.5 px-4 text-center font-bold text-slate-400 border">{idx + 1}</td>
                                  <td className="py-1.5 px-4 font-black text-slate-900 border uppercase">{santri.name}</td>
                                  <td className="py-1.5 px-4 font-bold text-slate-600 border uppercase">{santri.kamar}</td>
                                  <td className="py-1.5 px-4 text-center font-bold border">{h} Hari</td>
                                  <td className="py-1.5 px-4 text-center font-black text-emerald-600 border">{p}%</td>
                                  <td className="py-1.5 px-4 text-center border font-black">
                                    {(() => {
                                      const grade = p >= 90 ? 'A' : p >= 80 ? 'B' : p >= 70 ? 'C' : 'D';
                                      const colorClass = grade === 'A' ? 'text-emerald-700 bg-emerald-50 border-emerald-300' : grade === 'B' ? 'text-blue-700 bg-blue-50 border-blue-300' : grade === 'C' ? 'text-amber-700 bg-amber-50 border-amber-300' : 'text-rose-700 bg-rose-50 border-rose-300';
                                      return <span className={`px-2 py-0.5 rounded border ${colorClass}`}>{grade}</span>;
                                    })()}
                                  </td>
                                </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    )
                  ) : (
                    /* Musyrif Report Content */
                    laporanMusyrifSubTab === 'individu' ? (
                      /* Individual Musyrif Report */
                      (() => {
                        const mId = selectedMusyrifIdForReport || musyrifs[0]?.id;
                        const m = musyrifs.find(x => x.id === mId);
                        const stats = absensiList.filter(r => r.musyrifId === mId);
                        const hCount = stats.filter(r => r.status === 'Hadir').length;
                        const perc = stats.length > 0 ? Math.round((hCount / stats.length) * 100) : 0;
                        
                        return (
                          <div className="space-y-6">
                            <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 grid grid-cols-2 gap-4">
                              <div className="space-y-0.5">
                                <p className="text-[9px] font-black text-slate-400 uppercase">Nama Musyrif / Asatidz</p>
                                <p className="text-sm font-black text-indigo-700 uppercase">{m?.name}</p>
                              </div>
                              <div className="space-y-0.5">
                                <p className="text-[9px] font-black text-slate-400 uppercase">Asrama & Tanggung Jawab</p>
                                <p className="text-sm font-black text-slate-700 uppercase">{m?.asrama}</p>
                              </div>
                            </div>

                            <div className="grid grid-cols-3 gap-3">
                              <div className="p-3 rounded-xl border border-emerald-100 bg-emerald-50 text-center">
                                <p className="text-[8px] font-black text-emerald-800 uppercase tracking-widest">Kehadiran</p>
                                <p className="text-lg font-black text-emerald-600 mt-0.5">{hCount} Laporan</p>
                              </div>
                              <div className="p-3 rounded-xl border border-indigo-100 bg-indigo-50 text-center">
                                <p className="text-[8px] font-black text-indigo-800 uppercase tracking-widest">Disiplin</p>
                                <p className="text-lg font-black text-indigo-600 mt-0.5">{perc}%</p>
                              </div>
                              <div className="p-3 rounded-xl border border-slate-100 bg-slate-50 text-center">
                                <p className="text-[8px] font-black text-slate-800 uppercase tracking-widest">Kinerja</p>
                                {(() => {
                                  const grade = perc >= 85 ? 'A' : perc >= 70 ? 'B' : perc >= 50 ? 'C' : 'D';
                                  const text = grade === 'A' ? 'Sangat Baik' : grade === 'B' ? 'Baik' : grade === 'C' ? 'Cukup' : 'Kurang';
                                  const colorClass = grade === 'A' ? 'text-emerald-600' : grade === 'B' ? 'text-blue-600' : grade === 'C' ? 'text-amber-500' : 'text-rose-600';
                                  return <p className={`text-lg font-black mt-0.5 ${colorClass}`}>{text}</p>;
                                })()}
                              </div>
                            </div>

                            <table className="w-full text-[11px] border-collapse">
                              <thead>
                                <tr className="bg-slate-900 text-white uppercase font-black text-[9px]">
                                  <th className="py-2.5 px-4 text-center border border-slate-900 w-10">NO</th>
                                  <th className="py-2.5 px-4 border border-slate-900">TANGGAL</th>
                                  <th className="py-2.5 px-4 border border-slate-900">KEGIATAN & WAKTU</th>
                                  <th className="py-2.5 px-4 text-center border border-slate-900">STATUS</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-slate-200">
                                {stats.map((log, i) => (
                                  <tr key={log.id}>
                                    <td className="py-2 px-4 text-center font-bold text-slate-400 border">{i + 1}</td>
                                    <td className="py-2 px-4 font-bold border">{log.hari}, {log.tanggal}</td>
                                    <td className="py-2 px-4 font-bold border uppercase">{log.kegiatan}<br/><span className="text-[9px] text-slate-400 font-mono">{log.waktu} WIB</span></td>
                                    <td className="py-2 px-4 text-center border">
                                      <span className={`font-black uppercase text-[9px] ${log.status === 'Hadir' ? 'text-emerald-600' : 'text-rose-600'}`}>
                                        {log.status}
                                      </span>
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        );
                      })()
                    ) : (
                      /* Bulk Musyrif Report */
                      <table className="w-full text-[11px] border-collapse">
                        <thead>
                          <tr className="bg-slate-900 text-white uppercase font-black text-[9px]">
                            <th className="py-2.5 px-4 text-center border border-slate-900 w-10">NO</th>
                            <th className="py-2.5 px-4 border border-slate-900">NAMA ASATIDZ</th>
                            <th className="py-2.5 px-4 border border-slate-900">ASRAMA</th>
                            <th className="py-2.5 px-4 text-center border border-slate-900 w-24">HADIR</th>
                            <th className="py-2.5 px-4 text-center border border-slate-900 w-24">DISIPLIN</th>
                            <th className="py-2.5 px-4 text-center border border-slate-900 w-20">MUTU</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200">
                          {musyrifs
                            .filter(m => {
                              if (laporanMusyrifSubTab === 'musyrif') return !m.name.toLowerCase().includes('mulahid') && !m.kamar.toLowerCase().includes('mulahid');
                              if (laporanMusyrifSubTab === 'mulahid') return m.name.toLowerCase().includes('mulahid') || m.kamar.toLowerCase().includes('mulahid');
                              return true;
                            })
                            .map((m, idx) => {
                              const s = absensiList.filter(r => r.musyrifId === m.id);
                              const h = s.filter(r => r.status === 'Hadir').length;
                              const p = s.length > 0 ? Math.round((h/s.length)*100) : 0;
                              return (
                                <tr key={m.id}>
                                  <td className="py-2.5 px-4 text-center font-bold text-slate-400 border">{idx + 1}</td>
                                  <td className="py-2.5 px-4 font-black text-slate-900 border uppercase">{m.name}</td>
                                  <td className="py-2.5 px-4 font-bold text-slate-600 border uppercase">{m.asrama}</td>
                                  <td className="py-2.5 px-4 text-center font-bold border">{h} Kali</td>
                                  <td className="py-2.5 px-4 text-center font-black text-indigo-600 border">{p}%</td>
                                  <td className="py-2.5 px-4 text-center border font-black">
                                    {(() => {
                                      const grade = p >= 85 ? 'A' : p >= 70 ? 'B' : p >= 50 ? 'C' : 'D';
                                      const colorClass = grade === 'A' ? 'text-emerald-600' : grade === 'B' ? 'text-blue-600' : grade === 'C' ? 'text-amber-500' : 'text-rose-600';
                                      return <span className={colorClass}>{grade}</span>;
                                    })()}
                                  </td>
                                </tr>
                              );
                            })}
                        </tbody>
                      </table>
                    )
                  )}
                </div>

                {/* PDF Signatures Section */}
                <div className="grid grid-cols-2 gap-10 pt-8 mt-8 border-t border-slate-200">
                  <div className="text-center space-y-6">
                    <div className="space-y-0.5">
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Mengetahui,</p>
                      <p className="text-[11px] font-black text-slate-800 uppercase tracking-tight">Pengasuh Pesantren</p>
                    </div>
                    <div className="h-16 flex items-center justify-center">
                      {pondokSettings.pengasuhTtdUrl ? (
                        <img src={pondokSettings.pengasuhTtdUrl} alt="TTD Pengasuh" className="max-h-full object-contain" crossOrigin="anonymous" />
                      ) : (
                        <div className="w-32 h-px bg-slate-200" />
                      )}
                    </div>
                    <p className="text-xs font-black text-slate-900 border-b border-slate-900 pb-0.5 inline-block px-4">
                      {pondokSettings.pengasuh}
                    </p>
                  </div>

                  <div className="text-center space-y-6">
                    <div className="space-y-0.5">
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Hormat Kami,</p>
                      <p className="text-[11px] font-black text-slate-800 uppercase tracking-tight">Ketua Pondok / Koordinator</p>
                    </div>
                    <div className="h-16 flex items-center justify-center">
                      {pondokSettings.ketuaPondokTtdUrl ? (
                        <img src={pondokSettings.ketuaPondokTtdUrl} alt="TTD Ketua" className="max-h-full object-contain" crossOrigin="anonymous" />
                      ) : (
                        <div className="w-32 h-px bg-slate-200" />
                      )}
                    </div>
                    <p className="text-xs font-black text-slate-900 border-b border-slate-900 pb-0.5 inline-block px-4">
                      {pondokSettings.ketuaPondok}
                    </p>
                  </div>
                </div>

                {/* Footer Info */}
                <div className="mt-auto pt-8 flex items-center justify-between text-[8px] font-bold text-slate-400 uppercase tracking-widest">
                  <span>Dicetak pada: {new Date().toLocaleString('id-ID')}</span>
                  <span>Sistem Monitoring Absensi - {pondokName}</span>
                </div>
              </div>
            </div>

            <div className="p-4 bg-white border-t border-slate-200 flex items-center justify-between px-6">
              <p className="text-[10px] font-bold text-slate-400 italic">*Gunakan tombol "Cetak & Download" untuk menyimpan laporan secara permanen.</p>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setReportPdfModal({ ...reportPdfModal, open: false })}
                  className="px-6 py-2.5 text-xs font-black text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition cursor-pointer"
                >
                  BATAL
                </button>
                <button
                  onClick={async () => {
                    const sheet = document.getElementById('dynamic-report-sheet');
                    if (!sheet) return;
                    setIsGeneratingPdf(true);
                    try {
                       const width = sheet.scrollWidth;
                       const height = sheet.scrollHeight;
                       const imgData = await htmlToImage.toPng(sheet, {
                         backgroundColor: '#ffffff',
                         pixelRatio: 2,
                         width,
                         height
                       });
                       const pdf = new jsPDF({ orientation: 'p', unit: 'mm', format: 'a4' });
                       const pdfWidth = pdf.internal.pageSize.getWidth();
                       const pdfHeight = (height * pdfWidth) / width;
                       pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
                       pdf.save(`Laporan_${reportPdfModal.type}_${new Date().getTime()}.pdf`);
                    } catch (e) {
                       console.error(e);
                       alert('Gagal membuat PDF. Silakan coba lagi.');
                    } finally {
                       setIsGeneratingPdf(false);
                    }
                  }}
                  disabled={isGeneratingPdf}
                  className="px-8 py-2.5 text-xs font-black text-white bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-400 rounded-xl transition shadow-lg shadow-emerald-600/20 flex items-center gap-2 cursor-pointer"
                >
                  {isGeneratingPdf ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      <span>PROSES...</span>
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4" />
                      <span>CETAK & DOWNLOAD PDF</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
