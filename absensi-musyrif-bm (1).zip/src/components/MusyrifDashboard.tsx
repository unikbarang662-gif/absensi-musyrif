/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useAppState } from '../context/AppStateContext';
import { SCHEDULES } from '../data';
import { StatusAbsensi } from '../types';
import { Calendar, LayoutList, Image as ImageIcon, Check, X, FileUp, AlertCircle, Trash2, Camera, ClipboardCheck, Edit, Plus, Home, History, User, BookOpen, Moon } from 'lucide-react';
import { compressImage } from '../utils/imageCompressor';


const normalizeAsramaName = (asrama: string): string => {
  if (!asrama) return '';
  return asrama.toLowerCase().replace(/[^a-z0-9]/g, '').trim();
};

const normalizeRoomName = (room: string): string => {
  if (!room) return '';
  let str = room.toLowerCase().trim();
  str = str.replace(/^kamar[\s\-_]*/i, '');
  return str.replace(/[^a-z0-9]/g, '').trim();
};

interface MusyrifDashboardProps {
  initialTab?: 'kegiatan' | 'tidur' | 'mutholaah';
  hideTopBanner?: boolean;
  hideTabs?: boolean;
}

export const MusyrifDashboard: React.FC<MusyrifDashboardProps> = ({ 
  initialTab = 'kegiatan',
  hideTopBanner = false,
  hideTabs = false
}) => {
  const { 
    currentUser, absensiList, submitAbsensi, deleteAbsensi, 
    pondokSettings, logout, firebaseError, isCloudSynced, retrySync, musyrifs,
    santris, fetchFullAbsensi
  } = useAppState();

  // Fetch relevant data on mount for charts/history accuracy
  useEffect(() => {
    if (currentUser?.id) {
      // Fetch last 30 reports for this musyrif specifically (reduced from 100 to save quota)
      fetchFullAbsensi({ musyrifId: currentUser.id, limit: 30 });
    }
  }, [currentUser?.id]);

  const activeMusyrif = musyrifs.find(m => m.id === currentUser?.id) || currentUser;
  const activeAsrama = activeMusyrif?.asrama || '';
  
  // Get all rooms from santris, settings, and musyrifs
  const roomsFromSantris = Array.from(new Set(
    (santris || [])
      .map(s => s.kamar)
      .filter(Boolean)
  ));

  const roomsFromSettings = (pondokSettings?.daftarKamar || []).filter(Boolean);

  const roomsFromMusyrifs = Array.from(new Set(
    (musyrifs || [])
      .map(m => m.kamar)
      .filter(Boolean)
  ));

  // Combine them and deduplicate
  const finalRooms = Array.from(new Set([
    ...roomsFromSettings,
    ...roomsFromSantris,
    ...roomsFromMusyrifs,
    activeMusyrif?.kamar
  ])).filter(Boolean).sort() as string[];

  const [selectedKamar, setSelectedKamar] = useState<string>('');

  // Auto initialize selectedKamar from profile or fallback
  useEffect(() => {
    if (!selectedKamar) {
      if (activeMusyrif?.kamar && finalRooms.includes(activeMusyrif.kamar)) {
        setSelectedKamar(activeMusyrif.kamar);
      } else if (finalRooms.length > 0) {
        setSelectedKamar(finalRooms[0]);
      }
    }
  }, [activeMusyrif?.kamar, activeAsrama, pondokSettings, santris, finalRooms, selectedKamar]);

  const activeKamar = selectedKamar || activeMusyrif?.kamar || (finalRooms.length > 0 ? finalRooms[0] : '');
  
  // Real-time dynamic ticking clock
  const [currentDateTime, setCurrentDateTime] = useState<Date>(new Date());
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentDateTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatIndonesianDateTime = (date: Date) => {
    const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    const months = [
      'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 
      'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ];
    
    const dayName = days[date.getDay()];
    const day = date.getDate();
    const monthName = months[date.getMonth()];
    const year = date.getFullYear();
    
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    
    return `${dayName}, ${day} ${monthName} ${year} • ${hours}:${minutes}:${seconds} WIB`;
  };

  // Colored bars configurations for Day of the Week Chart (warna-warni)
  const DAY_BAR_COLORS = [
    { bg: 'bg-rose-500', hover: 'hover:bg-rose-600' },     // Minggu
    { bg: 'bg-orange-500', hover: 'hover:bg-orange-600' }, // Senin
    { bg: 'bg-amber-500', hover: 'hover:bg-amber-600' },   // Selasa
    { bg: 'bg-emerald-500', hover: 'hover:bg-emerald-600' }, // Rabu
    { bg: 'bg-sky-500', hover: 'hover:bg-sky-600' },       // Kamis
    { bg: 'bg-indigo-500', hover: 'hover:bg-indigo-600' }, // Jumat
    { bg: 'bg-fuchsia-500', hover: 'hover:bg-fuchsia-600' }, // Sabtu
  ];

  // States for the attendance form
  const [selectedKegiatan, setSelectedKegiatan] = useState<string>('');
  const [status, setStatus] = useState<StatusAbsensi>('Hadir');
  const [jenisAbsensi, setJenisAbsensi] = useState<'musyrif' | 'mulahid'>('musyrif');
  const [catatan, setCatatan] = useState<string>('');
  const [mutholaahCatatan, setMutholaahCatatan] = useState<string>('');
  const [image64, setImage64] = useState<string>('');
  const [formError, setFormError] = useState<string | null>(null);
  const [formSuccess, setFormSuccess] = useState<boolean>(false);
  const [previewOpen, setPreviewOpen] = useState<string | null>(null);
  const [isCompressing, setIsCompressing] = useState<boolean>(false);

  // Custom browser-safe confirmation and alert modal
  const [confirmModal, setConfirmModal] = useState<{
    title: string;
    message: string;
    onConfirm?: () => void | Promise<void>;
    danger?: boolean;
    isAlert?: boolean;
  } | null>(null);

  if (!currentUser) return null;

  // Filter schedules matching the current day of the week
  const DAYS_INDONESIAN_LOWER = ['minggu', 'senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu'];
  const now = new Date();
  const currentDayIndex = now.getDay();
  const currentDayName = DAYS_INDONESIAN_LOWER[currentDayIndex];

  // Activities list from settings or defaults
  const activeSchedules = pondokSettings?.schedules || SCHEDULES;

  // Activities filtered for today
  const todaysSchedules = activeSchedules.filter((s) => s.days.includes(currentDayName));

  // Handle Photo input conversion with automatic client-side photo resizing and compression
  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Support big device captures up to 15MB since they will be compressed client-side instantly
      if (file.size > 15 * 1024 * 1024) {
        setFormError('Ukuran file foto terlalu besar (maksimal 15 MB).');
        return;
      }
      setIsCompressing(true);
      setFormError(null);

      const reader = new FileReader();
      reader.onloadend = async () => {
        try {
          const rawBase64 = reader.result as string;
          // Constrain boundaries to 1000px and 70% quality for lightning-fast server synchronization
          const compressed = await compressImage(rawBase64, 1000, 1000, 0.7);
          setImage64(compressed);
          setFormError(null);
        } catch (err) {
          console.error('Error compressing image:', err);
          setFormError('Gagal mengompresi gambar. Coba file lain.');
        } finally {
          setIsCompressing(false);
        }
      };
      reader.onerror = () => {
        setFormError('Gagal membaca file gambar.');
        setIsCompressing(false);
      };
      reader.readAsDataURL(file);
    }
  };

  // Preset Beautiful Simulation Photos for quick, error-free testing in sandboxed browser
  const SIMULATION_PHOTOS = [
    { name: 'Koleksi Santri Membaca Al-Qur\'an', val: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?q=80&w=400&auto=format&fit=crop' },
    { name: 'Musholla Berjamaah Subuh', val: 'https://images.unsplash.com/photo-1518495973542-4542c06a5843?q=80&w=400&auto=format&fit=crop' },
    { name: 'Kegiatan Kebersihan Kamar Santri', val: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?q=80&w=400&auto=format&fit=crop' }
  ];

  const handleSimulatePhoto = (url: string) => {
    setImage64(url);
    setFormError(null);
  };

  // Submit Absensi Form
  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setFormSuccess(false);

    if (!selectedKegiatan) {
      setFormError('Harap pilih kegiatan absensi.');
      return;
    }
    if (!image64) {
      setFormError('Harap lampirkan foto kegiatan sebagai bukti laporan.');
      return;
    }

    submitAbsensi({
      musyrifId: currentUser.id,
      namaMusyrif: currentUser.name,
      asrama: activeAsrama,
      kegiatan: `${selectedKegiatan} (Absen ${jenisAbsensi === 'musyrif' ? 'Musyrif' : 'Mulahid'})`,
      status,
      foto: image64,
      catatan: catatan.trim() || undefined,
    });

    // Reset Form fields
    setCatatan('');
    setImage64('');
    setSelectedKegiatan('');
    setFormSuccess(true);
    setTimeout(() => setFormSuccess(false), 4500);
  };

  // Scope untuk riwayat laporan yang ditampilkan di HP musyrif
  const [historyFilter, setHistoryFilter] = React.useState<'saya' | 'asrama' | 'semua'>('saya');
  const [jenisFilter, setJenisFilter] = useState<'semua' | 'musyrif' | 'mulahid'>('semua');

  // Get only reports filed by the active musyrif
  const myReports = absensiList.filter((r) => r.musyrifId === currentUser.id);

  // Filter laporan berdasarkan pilihan filter aktif
  const displayedReports = absensiList.filter((r) => {
    let passHistory = true;
    if (historyFilter === 'saya') {
      passHistory = r.musyrifId === currentUser.id;
    } else if (historyFilter === 'asrama') {
      passHistory = r.asrama === activeAsrama;
    }
    
    if (!passHistory) return false;
    
    if (jenisFilter === 'musyrif') {
      return r.kegiatan.includes('(Absen Musyrif)');
    } else if (jenisFilter === 'mulahid') {
      return r.kegiatan.includes('(Absen Mulahid)');
    }
    return true;
  });

  const [activeTab, setActiveTab] = useState<'kegiatan' | 'tidur' | 'mutholaah'>(initialTab);
  const [mobileActiveTab, setMobileActiveTab] = useState<'dashboard' | 'riwayat' | 'profil'>('dashboard');

  useEffect(() => {
    setActiveTab(initialTab);
  }, [initialTab]);
  const { 
    absensiTidurList, 
    submitAbsensiTidur, 
    absensiMutholaahList,
    submitAbsensiMutholaah,
    deleteAbsensiMutholaah,
    addSantri, 
    updateSantri, 
    deleteSantri,
  } = useAppState();

  const handleTidurFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedSantrisTidur.length === 0) return;
    selectedSantrisTidur.forEach(sel => {
      submitAbsensiTidur({
        musyrifId: currentUser.id,
        asrama: activeAsrama,
        kamar: activeKamar,
        santriId: sel.santri.id,
        santriName: sel.santri.name,
        status: sel.status
      });
    });
    setConfirmModal({
      title: 'Absensi Tersimpan',
      message: 'Berhasil menyimpan absensi tidur santri.',
      isAlert: true
    });
    setFormSuccess(true);
    setTimeout(() => setFormSuccess(false), 4500);
  };

  const handleMutholaahFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedSantrisMutholaah.length === 0) return;
    selectedSantrisMutholaah.forEach(sel => {
      submitAbsensiMutholaah({
        musyrifId: currentUser.id,
        asrama: activeAsrama,
        kamar: activeKamar,
        santriId: sel.santri.id,
        santriName: sel.santri.name,
        status: sel.status,
        catatan: mutholaahCatatan.trim() || undefined
      });
    });
    setConfirmModal({
      title: 'Absensi Tersimpan',
      message: 'Berhasil menyimpan absensi mutholaah santri.',
      isAlert: true
    });
    setMutholaahCatatan('');
    setFormSuccess(true);
    setTimeout(() => setFormSuccess(false), 4500);
  };
  
  // States for Tidur & Mutholaah Tab
  const [selectedSantrisTidur, setSelectedSantrisTidur] = useState<Array<{santri: any, status: any}>>([]);
  const [selectedSantrisMutholaah, setSelectedSantrisMutholaah] = useState<Array<{santri: any, status: any}>>([]);
  const [editingSantriInKamar, setEditingSantriInKamar] = useState<any | null>(null);
  
  useEffect(() => {
    const mySantris = (santris || []).filter(s => {
      if (!activeKamar) return false;

      const normS = normalizeRoomName(s.kamar);
      const normA = normalizeRoomName(activeKamar);
      const rawS = s.kamar ? s.kamar.toLowerCase().trim() : '';
      const rawA = activeKamar ? activeKamar.toLowerCase().trim() : '';

      const matchKamar = normS === normA ||
        (rawS && rawA && (rawS === rawA || rawS.includes(rawA) || rawA.includes(rawS)));

      const isActive = s.isActive !== false;
      return matchKamar && isActive;
    });
    setSelectedSantrisTidur(mySantris.map(s => ({ santri: s, status: 'Hadir dikamar' })));
    setSelectedSantrisMutholaah(mySantris.map(s => ({ santri: s, status: 'Hadir Mutholaah' })));
  }, [santris, currentUser, activeAsrama, activeKamar]);


  // Capitalize Day name nicely
  const printDayCapitalized = (dayKey: string) => {
    return dayKey.charAt(0).toUpperCase() + dayKey.slice(1);
  };

  const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
  const months = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
  ];
  const dayNameStr = days[currentDateTime.getDay()];
  const dayNum = currentDateTime.getDate();
  const monthNameStr = months[currentDateTime.getMonth()];
  const yearNum = currentDateTime.getFullYear();
  const hoursStr = String(currentDateTime.getHours()).padStart(2, '0');
  const minutesStr = String(currentDateTime.getMinutes()).padStart(2, '0');
  const secondsStr = String(currentDateTime.getSeconds()).padStart(2, '0');

  return (
    <div className="max-w-7xl mx-auto pb-6 px-0 sm:px-1 space-y-4">
      

      
      <div className={`${mobileActiveTab !== 'riwayat' ? 'block' : 'hidden sm:block'}`}>
        {/* 1. TOP TOSCA GREETINGS BANNER - FULL COLOR GRADIENT */}
        {!hideTopBanner && (
          <div className="bg-gradient-to-r from-indigo-600 via-teal-600 to-emerald-500 text-white p-4 sm:p-5 rounded-2xl flex flex-col items-center justify-center relative shadow-sm text-center border border-white/20 overflow-hidden mx-2 sm:mx-0">
          <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/always-grey.png')] opacity-10 pointer-events-none mix-blend-overlay"></div>
          <button 
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="absolute top-3 left-3 bg-white/20 hover:bg-white/30 text-white text-[10px] font-bold px-3 py-1.5 rounded-lg transition duration-150 cursor-pointer backdrop-blur-md border border-white/20 select-none z-10 flex items-center gap-1 shadow-sm"
          >
            <span>🏠</span> Home
          </button>
          <button 
            onClick={logout}
            className="absolute top-3 right-3 bg-white/20 hover:bg-red-500/80 text-white text-[10px] font-bold px-3 py-1.5 rounded-lg transition duration-150 cursor-pointer backdrop-blur-md border border-white/20 select-none z-10 shadow-sm"
          >
            Logout
          </button>
          <div className="relative z-10 flex flex-col items-center justify-center gap-1.5 mt-2 sm:mt-0">
            <h2 className="text-lg sm:text-2xl font-black tracking-tight font-sans drop-shadow-xs">
              Selamat Datang, {currentUser.name}
            </h2>
            {/* Real-time Date & Time Indicator Capsules */}
            <div className="flex flex-wrap items-center justify-center gap-1.5 mt-1.5 text-[10px] sm:text-xs font-black text-white text-center">
              <span className="px-2.5 py-0.5 rounded-full bg-rose-500 text-white border border-rose-400 shadow-xs flex items-center gap-1">
                <Calendar className="w-3 h-3" /> {dayNameStr}
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-amber-500 text-slate-900 border border-amber-400 shadow-xs flex items-center gap-1">
                <span>📅</span> {dayNum} {monthNameStr} {yearNum}
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-cyan-500 text-white border border-cyan-400 shadow-xs flex items-center gap-1">
                <span>⏰</span> {hoursStr}:{minutesStr}:{secondsStr} WIB
              </span>
            </div>
            <div className="flex flex-col items-center gap-0.5 mt-1.5">
              <p className="text-teal-50 text-[10px] font-black tracking-widest uppercase opacity-80">
                ASRAMA {activeAsrama}
              </p>
              {finalRooms.length > 0 && (
                <div className="flex items-center gap-1.5 bg-white/10 px-2.5 py-0.5 rounded-lg border border-white/10 shadow-inner">
                  <span className="text-[9px] font-bold text-teal-100">Kamar Aktif:</span>
                  <select
                    value={activeKamar}
                    onChange={(e) => setSelectedKamar(e.target.value)}
                    className="bg-transparent text-white font-black text-[10px] outline-none border-none cursor-pointer focus:ring-0 py-0"
                  >
                    {finalRooms.map(room => (
                      <option key={room} value={room} className="text-slate-800 font-bold bg-white">
                        {room}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>
            <div className="mt-1.5 flex items-center justify-center gap-1 px-2.5 py-0.5 rounded-full bg-white/10 border border-white/5 text-[8px] font-bold select-none text-white shadow-xs">
              {isCloudSynced ? (
                <>
                  <span className="w-1 h-1 rounded-full bg-emerald-400 animate-pulse"></span>
                  <span className="text-emerald-100">Awan Terhubung & Sinkron</span>
                </>
              ) : (
                <>
                  <span className="w-1 h-1 rounded-full bg-rose-400 animate-pulse"></span>
                  <span className="text-rose-100">Mode Lokal (Offline)</span>
                </>
              )}
            </div>
          </div>
        </div>
      )}
      </div>

      <div className={`${mobileActiveTab === 'dashboard' ? 'block' : 'hidden sm:block'} pt-2`}>
        {!hideTabs && (
        <div className="flex gap-2 mx-2 sm:mx-0 overflow-x-auto pb-2 scrollbar-none items-center justify-center">
          <button
            onClick={() => setActiveTab('kegiatan')}
            className={`px-3 sm:px-4 py-2 rounded-full font-bold text-[10px] sm:text-xs uppercase tracking-wider border transition-all shadow-xs flex items-center gap-1 sm:gap-1.5 cursor-pointer whitespace-nowrap ${
              activeTab === 'kegiatan'
                ? 'border-[#0B4A3F] bg-[#0B4A3F] text-white font-black'
                : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
            }`}
          >
            <ClipboardCheck className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate max-w-[80px] sm:max-w-none block">Laporan Kegiatan</span>
          </button>
          <button
            onClick={() => setActiveTab('mutholaah')}
            className={`px-3 sm:px-4 py-2 rounded-full font-bold text-[10px] sm:text-xs uppercase tracking-wider border transition-all shadow-xs flex items-center gap-1 sm:gap-1.5 cursor-pointer whitespace-nowrap ${
              activeTab === 'mutholaah'
                ? 'border-[#0B4A3F] bg-[#0B4A3F] text-white font-black'
                : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate max-w-[80px] sm:max-w-none block">Absensi Mutholaah</span>
          </button>
          <button
            onClick={() => setActiveTab('tidur')}
            className={`px-3 sm:px-4 py-2 rounded-full font-bold text-[10px] sm:text-xs uppercase tracking-wider border transition-all shadow-xs flex items-center gap-1 sm:gap-1.5 cursor-pointer whitespace-nowrap ${
              activeTab === 'tidur'
                ? 'border-[#0B4A3F] bg-[#0B4A3F] text-white font-black'
                : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
            }`}
          >
            <Moon className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate max-w-[85px] sm:max-w-none block">Absensi Tidur</span>
          </button>
        </div>
      )}
      </div>

      <div className={`${mobileActiveTab === 'dashboard' ? 'block' : 'hidden sm:block'}`}>
        {activeTab === 'kegiatan' ? (
          <div className="grid grid-cols-1 xl:grid-cols-12 gap-4 items-start w-full">
            <div className="xl:col-span-12 flex flex-col space-y-4">
            
            {/* 2. JADWAL HARI INI CARD LISTING */}
          <div className="bg-white rounded-xl border-t-4 border-t-[#0B4A3F] border border-slate-100 shadow-xs p-3.5 space-y-2.5">
            <div className="flex justify-between items-center border-b border-slate-100 pb-2">
              <h2 className="text-xs font-black text-[#0B4A3F] flex items-center gap-1.5 uppercase tracking-wide">
                <Calendar className="w-4 h-4" /> JADWAL HARI INI ({currentDayName.toUpperCase()})
              </h2>
              <span className="text-[10px] font-bold text-[#0B4A3F] bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-100">
                {todaysSchedules.length} Kegiatan Wajib
              </span>
            </div>
            <div className="space-y-1.5">
              {todaysSchedules.length > 0 ? todaysSchedules.map((schedule) => {
                  const [startStr, endStr] = schedule.time.split(' - ');
                  let isActiveNow = false;
                  if (startStr && endStr) {
                    const startMin = parseInt(startStr.split(':')[0]) * 60 + parseInt(startStr.split(':')[1]);
                    const endMin = parseInt(endStr.split(':')[0].replace('.', '')) * 60 + parseInt(endStr.split('.')[1] || endStr.split(':')[1] || '0');
                    const nowMin = now.getHours() * 60 + now.getMinutes();
                    isActiveNow = nowMin >= startMin && nowMin <= endMin;
                  }
                  
                  return (
                    <div key={schedule.id} className="flex items-center justify-between gap-1.5 py-1.5 border-b border-slate-100/50 last:border-0 min-w-0">
                      <div className="flex items-center gap-2 min-w-0 flex-1">
                        <span className={`shrink-0 text-[10px] sm:text-xs font-black font-mono px-2 py-0.5 rounded-lg border ${
                          isActiveNow 
                            ? 'bg-amber-50 text-amber-700 border-amber-200' 
                            : 'bg-[#F4F7FB] text-slate-500 border-slate-200/50'
                        }`}>
                          {schedule.time}
                        </span>
                       <h4 className="text-xs sm:text-sm font-bold text-slate-700 truncate">{schedule.title}</h4>
                      </div>
                      <div className="shrink-0 pl-1">
                        <span className={`text-[9px] font-extrabold px-1.5 py-0.5 rounded border tracking-wider uppercase whitespace-nowrap ${
                          isActiveNow 
                            ? 'bg-emerald-50 text-emerald-650 border-emerald-200 font-black animate-pulse' 
                            : 'text-slate-400 bg-slate-50 border-slate-200/40'
                        }`}>
                          {isActiveNow ? 'AKTIF' : 'BELUM WAKTUNYA'}
                        </span>
                      </div>
                    </div>
                  );
                }) : (
                <div className="text-center py-2 text-xs text-slate-400 font-medium">Tidak ada jadwal untuk hari ini</div>
              )}
            </div>
          </div>
          {/* 3. INPUT ABSENSI CARD BLOCK */}
          <div className="bg-white rounded-xl border-t-4 border-t-[#0B4A3F] border border-slate-100 shadow-xs p-3.5 space-y-3.5">
            <h2 className="text-xs font-black text-[#0B4A3F] flex items-center gap-1.5 uppercase tracking-wide border-b border-slate-100 pb-2">
              <ClipboardCheck className="w-4 h-4" /> INPUT ABSENSI
            </h2>

            {formSuccess && (
              <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-2.5 rounded-lg text-xs flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                <span className="font-bold">Laporan berhasil terkirim ke server asrama!</span>
              </div>
            )}
            {formError && (
              <div className="bg-rose-50 border border-rose-200 text-rose-800 p-2.5 rounded-lg text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleFormSubmit} className="space-y-4">
              
              {/* Jenis Absensi */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-black text-slate-800 uppercase tracking-wide">JENIS ABSENSI</label>
                <div className="flex gap-6 pt-0.5">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="radio" name="jenis_absensi" value="musyrif" checked={jenisAbsensi === 'musyrif'} onChange={() => setJenisAbsensi('musyrif')} className="text-[#0B4A3F] focus:ring-[#0B4A3F] w-4 h-4 accent-[#0B4A3F]" />
                    <span className="text-xs font-bold text-slate-700">Absen Musyrif</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="radio" name="jenis_absensi" value="mulahid" checked={jenisAbsensi === 'mulahid'} onChange={() => setJenisAbsensi('mulahid')} className="text-[#0B4A3F] focus:ring-[#0B4A3F] w-4 h-4 accent-[#0B4A3F]" />
                    <span className="text-xs font-bold text-slate-700">Absen Mulahid</span>
                  </label>
                </div>
              </div>

              {/* Dropdown kegiatan */}
              <div className="space-y-1">
                <label className="text-[11px] font-black text-slate-800 uppercase tracking-wide">KEGIATAN</label>
                <select
                  id="form-activity-select"
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-[#0B4A3F] appearance-none cursor-pointer"
                  value={selectedKegiatan}
                  onChange={(e) => setSelectedKegiatan(e.target.value)}
                >
                  <option value="">-- Pilih Kegiatan Hari Ini ({currentDayName.toUpperCase()}) --</option>
                  {(todaysSchedules.length > 0 ? todaysSchedules : activeSchedules).map((s) => (
                    <option key={s.id} value={s.title}>
                      {s.title} ({s.time})
                    </option>
                  ))}
                </select>
                <p className="text-[10px] text-slate-500 font-medium pt-0.5">
                  {todaysSchedules.length > 0
                    ? `* Menampilkan ${todaysSchedules.length} kegiatan sesuai jadwal hari ${currentDayName}.`
                    : `* Menampilkan seluruh daftar kegiatan aktif.`}
                </p>
              </div>

              {/* Status attendance choice */}
              <div className="space-y-1.5">
                <label className="text-[11px] font-black text-slate-800 uppercase tracking-wide">HASIL / STATUS KEHADIRAN</label>
                <div className="grid grid-cols-3 gap-2.5">
                  {(['Hadir', 'Sakit', 'Izin'] as StatusAbsensi[]).map((st) => {
                    let isSelected = status === st;
                    let btnStyle = '';
                    if (st === 'Hadir') {
                      btnStyle = isSelected 
                        ? 'bg-[#0B4A3F] border-[#0B4A3F] text-white shadow-xs' 
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50';
                    } else if (st === 'Sakit') {
                      btnStyle = isSelected
                        ? 'bg-amber-500 border-amber-500 text-white shadow-xs'
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50';
                    } else {
                      btnStyle = isSelected
                        ? 'bg-sky-600 border-sky-600 text-white shadow-xs'
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50';
                    }
                    
                    return (
                      <button
                        key={st}
                        type="button"
                        className={`py-2 px-2.5 rounded-lg text-xs font-bold text-center border transition-all cursor-pointer flex items-center justify-center gap-1.5 ${btnStyle}`}
                        onClick={() => setStatus(st)}
                      >
                        {st === 'Hadir' && <Check className="w-3.5 h-3.5" />}
                        {st === 'Sakit' && <span className="text-sm leading-none">😋</span>}
                        {st === 'Izin' && <span className="w-3 h-3 rounded-full border border-current inline-block"></span>}
                        <span>{st}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Catatan Area */}
              <div className="space-y-1">
                <label className="text-[11px] font-black text-slate-800 uppercase tracking-wide">CATATAN TAMBAHAN (OPSIONAL)</label>
                <textarea
                  id="form-notes-area"
                  placeholder="Berikan informasi kondisi riil, ustadz/ustadzah."
                  rows={2}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-[#0B4A3F] font-medium text-slate-700 resize-none"
                  value={catatan}
                  onChange={(e) => setCatatan(e.target.value)}
                />
              </div>

              {/* Foto Bukti Section */}
              <div className="space-y-2">
                <label className="text-[11px] font-black text-slate-800 uppercase tracking-wide">FOTO KEGIATAN (WAJIB)</label>
                <div className="grid grid-cols-2 gap-2.5">
                   <button type="button" className="py-2 px-3 bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 hover:bg-emerald-100 transition relative">
                     <Camera className="w-3.5 h-3.5" /> Gunakan Kamera
                     <input type="file" accept="image/*" capture="environment" className="absolute inset-0 opacity-0 cursor-pointer w-full h-full" onChange={handlePhotoChange} />
                   </button>
                   <button type="button" className="py-2 px-3 bg-white border border-slate-200 text-slate-700 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 hover:bg-slate-50 transition relative">
                     <ImageIcon className="w-3.5 h-3.5" /> Pilih File
                     <input type="file" accept="image/*" className="absolute inset-0 opacity-0 cursor-pointer w-full h-full" onChange={handlePhotoChange} />
                   </button>
                </div>
                
                <div className="border border-dashed border-slate-200 rounded-lg p-3 flex flex-col items-center justify-center text-center mt-2">
                  {isCompressing ? (
                    <span className="text-teal-600 font-bold flex items-center gap-1.5 text-xs animate-pulse">
                      ⏳ Sedang mengompres berkas...
                    </span>
                  ) : image64 ? (
                    <div className="space-y-1">
                       <img src={image64} alt="Preview" className="h-24 object-contain mx-auto rounded border border-slate-200" />
                       <span className="text-emerald-600 font-bold block text-xs">Foto Berhasil Dilampirkan</span>
                    </div>
                  ) : (
                    <div className="py-1">
                      <span className="text-xs font-bold text-slate-600 block">Belum ada foto yang dipilih</span>
                      <span className="text-[10px] text-slate-400">Laporan membutuhkan bukti foto</span>
                    </div>
                  )}
                </div>
              </div>

              <button
                id="form-kirim-laporan"
                type="submit"
                disabled={isCompressing}
                className={`w-full cursor-pointer py-2.5 text-white rounded-lg text-xs font-black tracking-wide transition-all duration-150 shadow-xs flex items-center justify-center gap-2 mt-2 ${
                  isCompressing ? 'bg-slate-400 cursor-not-allowed opacity-60' : 'bg-[#0B4A3F] hover:bg-[#07362e]'
                }`}
              >
                {isCompressing ? <span>⏳</span> : <Check className="w-4 h-4" />} 
                {isCompressing ? 'Sedang Mengompres Gambar...' : 'Kirim Laporan Absensi'}
              </button>
            </form>
          </div>

          {/* 4. GRAFIK KEHADIRAN ANDA UNIT CARD */}
          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-4 sm:p-5 space-y-4">
            <h3 className="text-[13px] font-black text-[#0B4A3F] flex items-center gap-2 uppercase tracking-wide border-b border-slate-100 pb-2.5">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
              GRAFIK KEHADIRAN ANDA
            </h3>
            
            {/* Legend with colorful daily dots */}
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs border-b border-dashed border-slate-100 pb-2.5">
              <span className="text-slate-600 font-bold text-[10px] uppercase tracking-wider">HARIAN:</span>
              <div className="flex flex-wrap gap-x-2 gap-y-1 font-bold">
                <span className="flex items-center gap-1 text-[10px] text-slate-700 uppercase"><span className="w-2 h-2 bg-rose-500 rounded-full inline-block"></span> MIN</span>
                <span className="flex items-center gap-1 text-[10px] text-slate-700 uppercase"><span className="w-2 h-2 bg-orange-500 rounded-full inline-block"></span> SEN</span>
                <span className="flex items-center gap-1 text-[10px] text-slate-700 uppercase"><span className="w-2 h-2 bg-amber-500 rounded-full inline-block"></span> SEL</span>
                <span className="flex items-center gap-1 text-[10px] text-slate-700 uppercase"><span className="w-2 h-2 bg-emerald-500 rounded-full inline-block"></span> RAB</span>
                <span className="flex items-center gap-1 text-[10px] text-slate-700 uppercase"><span className="w-2 h-2 bg-sky-500 rounded-full inline-block"></span> KAM</span>
                <span className="flex items-center gap-1 text-[10px] text-slate-700 uppercase"><span className="w-2 h-2 bg-indigo-500 rounded-full inline-block"></span> JUM</span>
                <span className="flex items-center gap-1 text-[10px] text-slate-700 uppercase"><span className="w-2 h-2 bg-fuchsia-500 rounded-full inline-block"></span> SAB</span>
              </div>
            </div>

            {/* Dynamic Grid Chart (Adapts cleanly and responsive) */}
            <div className="relative w-full h-40 sm:h-48 pb-5 pt-1">
              {/* Y Grid Lines & Axis */}
              <div className="absolute left-0 top-0 bottom-5 w-6 flex flex-col justify-between text-[9px] font-bold text-slate-400 select-none pb-0">
                {['1', '0.8', '0.6', '0.4', '0.2', '0'].map((val) => (
                  <div key={val} className="text-right h-0 flex items-center justify-end">
                    {val}
                  </div>
                ))}
              </div>

              {/* Grid Rows line overlay */}
              <div className="absolute inset-x-8 top-0 bottom-5 grid grid-rows-5 pointer-events-none">
                {Array.from({ length: 6 }).map((_, i) => (
                  <div key={i} className="border-t border-slate-100 border-dashed w-full h-full" />
                ))}
              </div>
              
              {/* Render Bars matching days of the week (warna-warni) */}
              <div className="grid grid-cols-7 absolute inset-x-8 top-0 bottom-5 items-end px-1 z-10 gap-1.5 sm:gap-4">
                {['minggu', 'senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu'].map((dayName, idx) => {
                  const recordsOnDay = myReports.filter((r) => r.hari.toLowerCase() === dayName).length;
                  const heightPct = recordsOnDay > 0 ? Math.min(100, 30 + recordsOnDay * 35) : 0;
                  const colors = DAY_BAR_COLORS[idx];
                  return (
                    <div key={dayName} className="h-full flex flex-col justify-end items-center relative group w-full max-w-[32px] mx-auto">
                      {recordsOnDay > 0 && (
                        <div 
                          className={`w-full ${colors.bg} rounded-t-sm transition-all duration-300 relative shadow-xs`}
                          style={{ height: `${heightPct}%` }}
                        >
                          <div className="absolute -top-7 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-[9px] font-bold px-1.5 py-0.5 rounded opacity-0 group-hover:opacity-100 transition whitespace-nowrap z-30">
                            {recordsOnDay} Lapor
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
              
              {/* X Axis Indonesian Days Labels */}
              <div className="absolute bottom-0 inset-x-8 h-5 grid grid-cols-7 text-[10px] font-bold text-slate-600 text-center select-none pt-1">
                {['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'].map((lbl) => (
                  <div key={lbl}>{lbl}</div>
                ))}
              </div>
            </div>

            {/* Triple Percentage KPI Cards Aligned Below Chart */}
            <div className="grid grid-cols-3 gap-2 sm:gap-3 pt-2">
              
              {/* Harian Card */}
              <div className="bg-[#0B4A3F] p-2.5 sm:p-3 rounded-xl shadow-xs flex flex-col justify-center text-left text-white relative overflow-hidden">
                <span className="text-[9px] text-teal-100 font-black uppercase tracking-wider">Harian</span>
                {(() => {
                  const todayReports = myReports.filter(r => r.hari.toLowerCase() === currentDayName);
                  const schedLength = todaysSchedules.length;
                  const pct = schedLength > 0 ? Math.round((todayReports.length / schedLength) * 100) : 0;
                  const normalizedPct = Math.min(100, pct);
                  return (
                    <>
                      <strong className="text-base sm:text-lg font-black mt-0.5 text-white">{normalizedPct}%</strong>
                      <div className="w-full bg-teal-900/50 h-1 rounded-full overflow-hidden mt-1.5">
                        <div className="bg-emerald-400 h-full rounded-full transition-all duration-300" style={{ width: `${normalizedPct}%` }} />
                      </div>
                    </>
                  );
                })()}
              </div>

              {/* Mingguan Card */}
              <div className="bg-[#d97706] p-2.5 sm:p-3 rounded-xl shadow-xs flex flex-col justify-center text-left text-white relative overflow-hidden">
                <span className="text-[9px] text-amber-100 font-black uppercase tracking-wider">Mingguan</span>
                {(() => {
                  const weekTotal = myReports.length;
                  const targetWeekCount = Math.max(7, SCHEDULES.length * 4);
                  const pct = Math.min(100, Math.round((weekTotal / targetWeekCount) * 100));
                  const displayPct = weekTotal > 0 ? Math.max(pct, 15) : 0;
                  return (
                    <>
                      <strong className="text-base sm:text-lg font-black mt-0.5 text-white">{displayPct}%</strong>
                      <div className="w-full bg-amber-900/50 h-1 rounded-full overflow-hidden mt-1.5">
                        <div className="bg-white h-full rounded-full transition-all duration-300" style={{ width: `${displayPct}%` }} />
                      </div>
                    </>
                  );
                })()}
              </div>

              {/* Bulanan Card */}
              <div className="bg-[#5a67d8] p-2.5 sm:p-3 rounded-xl shadow-xs flex flex-col justify-center text-left text-white relative overflow-hidden">
                <span className="text-[9px] text-indigo-100 font-black uppercase tracking-wider">Bulanan</span>
                {(() => {
                  const displayPct = myReports.length > 0 ? Math.min(100, Math.max(35, Math.round(myReports.length * 1.5))) : 0;
                  return (
                    <>
                      <strong className="text-base sm:text-lg font-black mt-0.5 text-white">{displayPct}%</strong>
                      <div className="w-full bg-indigo-900/50 h-1 rounded-full overflow-hidden mt-1.5">
                        <div className="bg-white h-full rounded-full transition-all duration-300" style={{ width: `${displayPct}%` }} />
                      </div>
                    </>
                  );
                })()}
              </div>
            </div>
          </div>

            {/* 5. DYNAMIC RIWAYAT ABSENSI CARD TABLE WITH SCOPE TOGGLE */}
            <div className="bg-white rounded-xl border-t-4 border-t-[#0B4A3F] border border-slate-100 shadow-xs p-3.5 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center">
                  <LayoutList className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="text-[11px] font-black text-slate-800 uppercase tracking-wide">
                    RIWAYAT LAPORAN ABSENSI
                  </h2>
                  <p className="text-[9px] font-bold text-slate-400 mt-0.5">
                    {historyFilter === 'saya' && 'Menampilkan laporan khusus yang Anda kirimkan saja'}
                    {historyFilter === 'asrama' && `Laporan Musyrif di Asrama ${activeAsrama}`}
                    {historyFilter === 'semua' && 'Seluruh laporan lintas asrama pondok'}
                  </p>
                </div>
              </div>
              
              <div className="flex bg-[#F4F7FB] p-1.5 rounded-full border border-[#E2E8F0] self-end sm:self-auto items-center">
                <button
                  type="button"
                  onClick={() => setHistoryFilter('saya')}
                  className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer ${
                    historyFilter === 'saya' ? 'bg-white shadow-sm text-slate-800 font-extrabold border border-slate-200/50' : 'text-slate-500 hover:text-slate-700'
                  }`}
                >
                  Saya
                </button>
                <button
                  type="button"
                  onClick={() => setHistoryFilter('asrama')}
                  className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer ${
                    historyFilter === 'asrama' ? 'bg-white shadow-sm text-slate-800 font-extrabold border border-slate-200/50' : 'text-slate-500 hover:text-slate-700'
                  }`}
                >
                  Satu Asrama
                </button>
                <button
                  type="button"
                  onClick={() => setHistoryFilter('semua')}
                  className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all cursor-pointer ${
                    historyFilter === 'semua' ? 'bg-white shadow-sm text-slate-800 font-extrabold border border-slate-200/50' : 'text-slate-500 hover:text-slate-700'
                  }`}
                >
                  Semua Laporan
                </button>
              </div>
            </div>

            {/* Sub-Filters for Musyrif/Mulahid */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
               {([
                 { id: 'semua', label: 'Semua' },
                 { id: 'musyrif', label: 'Musyrif' },
                 { id: 'mulahid', label: 'Mulahid' }
               ] as const).map((sub) => (
                 <button
                   key={sub.id}
                   onClick={() => setJenisFilter(sub.id)}
                   className={`px-4 py-1.5 rounded-full text-[10px] font-black border transition-all whitespace-nowrap shadow-xs ${
                     jenisFilter === sub.id 
                       ? 'bg-[#8b5cf6] border-[#8b5cf6] text-white scale-105' 
                       : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50'
                   }`}
                 >
                   {sub.label}
                 </button>
               ))}
            </div>

            <div className="border border-slate-100 rounded-xl overflow-hidden bg-white">
              <div className="grid grid-cols-12 bg-slate-50 border-b border-slate-100 text-[9px] font-black text-slate-500 py-2.5 px-3 uppercase tracking-widest">
                <div className="col-span-4 text-left">Waktu Lapor</div>
                <div className="col-span-6 text-left">Kegiatan & Pelapor</div>
                <div className="col-span-2 text-right">Foto</div>
              </div>
              <div className="divide-y divide-slate-50 max-h-[500px] overflow-y-auto">
                {displayedReports.length > 0 ? (
                  [...displayedReports].map((item) => {
                    const isMyOwn = item.musyrifId === currentUser.id;
                    return (
                      <div 
                        key={item.id}
                        className={`grid grid-cols-12 items-center text-xs py-3 px-3 hover:bg-slate-50 transition duration-150 ${
                          isMyOwn ? 'bg-emerald-50/10' : ''
                        }`}
                      >
                        <div className="col-span-4 text-left flex flex-col gap-0.5">
                          <span className="font-black text-slate-800 text-[10px] leading-tight">{item.hari}, {item.tanggal}</span>
                          <span className="text-[10px] font-black text-[#0B4A3F]">{item.waktu} WIB</span>
                        </div>
                        <div className="col-span-6 text-left pr-2 space-y-1">
                          <span className="font-black text-slate-900 block text-[11px] leading-tight">
                            {item.kegiatan.replace(' (Absen Musyrif)', '').replace(' (Absen Mulahid)', '')}
                          </span>
                          <div className="flex items-center gap-1.5 flex-wrap">
                             <span className={`text-[8px] font-black px-1.5 py-0.5 rounded border leading-none tracking-tighter ${
                               item.kegiatan.includes('Mulahid') ? 'bg-amber-50 text-amber-700 border-amber-200' : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                             }`}>
                               {item.kegiatan.includes('Mulahid') ? 'MULAHID' : 'MUSYRIF'}
                             </span>
                             <span className={`text-[8px] font-black px-1.5 py-0.5 rounded border leading-none ${
                               item.status === 'Hadir' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-rose-50 text-rose-600 border-rose-100'
                             }`}>
                               {item.status.toUpperCase()}
                             </span>
                             {historyFilter !== 'saya' && (
                               <span className="text-[8px] font-bold text-slate-400 uppercase tracking-tighter">
                                 {item.namaMusyrif} ({item.asrama})
                               </span>
                             )}
                          </div>
                        </div>
                        <div className="col-span-2 flex justify-end items-center">
                          <button
                            type="button"
                            className="w-10 h-10 rounded-lg border border-slate-100 overflow-hidden shrink-0 cursor-zoom-in relative hover:scale-110 active:scale-95 transition-all shadow-xs"
                            onClick={() => setPreviewOpen(item.foto)}
                          >
                            <img src={item.foto} alt="Absensi" className="w-full h-full object-cover" />
                          </button>
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <div className="text-center py-10 text-[11px] font-bold text-slate-400 bg-white">
                    Belum ada riwayat laporan
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
        ) : activeTab === 'tidur' ? (
          <div className="xl:col-span-12">
            <div className="bg-white/80 backdrop-blur-md p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-sm space-y-4">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-3">
                <div>
                  <h3 className="text-lg font-black text-[#0f766e] tracking-tight flex items-center gap-2 uppercase">
                    <span>🛏️</span> Form Absensi Tidur Santri
                  </h3>
                  <p className="text-[11px] text-slate-500 font-bold mt-1">
                    Asrama {activeAsrama} • Kamar {activeKamar}
                  </p>
                </div>
                
                {/* SELECT KAMAR SEBAGAI FITUR UTAMA PADA ABSENSI */}
                <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 px-3 py-2 rounded-2xl shadow-xs">
                  <label htmlFor="kamar-tidur-select" className="text-xs font-bold text-slate-600 whitespace-nowrap">Pilih Kamar:</label>
                  <select
                    id="kamar-tidur-select"
                    value={activeKamar}
                    onChange={(e) => setSelectedKamar(e.target.value)}
                    className="bg-white border border-slate-300 rounded-xl px-2.5 py-1.5 text-xs font-black text-slate-700 outline-none focus:ring-2 focus:ring-teal-500 cursor-pointer"
                  >
                    {finalRooms.map(room => (
                      <option key={room} value={room}>
                        {room}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <p className="text-xs text-slate-500 font-medium">Sistem absensi malam santri. Harap pastikan setiap santri sesuai dengan kondisinya saat menjelang tidur.</p>
              
              {selectedSantrisTidur.length === 0 ? (
                <div className="text-sm text-amber-600 bg-amber-50 p-4 rounded-xl font-medium border border-amber-200 text-center">
                  Belum ada santri aktif yang terdaftar di kamar ini. Silakan tambahkan santri menggunakan menu "Kelola Data Santri".
                </div>
              ) : (
                <form onSubmit={handleTidurFormSubmit} className="space-y-4">
                  <div className="overflow-x-auto border border-slate-150 rounded-2xl bg-white shadow-xs">
                    <table className="w-full text-left border-collapse min-w-[500px]">
                      <thead>
                        <tr className="bg-slate-50/80 border-b border-slate-150">
                          <th className="py-2 px-3 text-[10px] font-black text-slate-400 tracking-wider text-center uppercase w-12">No</th>
                          <th className="py-2 px-3 text-[10px] font-black text-slate-400 tracking-wider uppercase">Nama Lengkap</th>
                          <th className="py-2 px-1.5 text-[10px] font-black text-emerald-600 tracking-wider text-center uppercase w-12">H</th>
                          <th className="py-2 px-1.5 text-[10px] font-black text-amber-600 tracking-wider text-center uppercase w-12">S</th>
                          <th className="py-2 px-1.5 text-[10px] font-black text-slate-500 tracking-wider text-center uppercase w-12">I</th>
                          <th className="py-2 px-1.5 text-[10px] font-black text-rose-600 tracking-wider text-center uppercase w-12">A</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {selectedSantrisTidur.map((item, index) => (
                          <tr key={item.santri.id} className="hover:bg-slate-50/40 transition-colors">
                            <td className="py-2 px-3 text-xs font-bold text-slate-400 text-center">{index + 1}</td>
                            <td className="py-2 px-3">
                              <div className="flex flex-col">
                                <span className="font-extrabold text-slate-800 text-xs tracking-tight">{item.santri.name}</span>
                                <span className="text-[9px] font-mono text-slate-400 font-bold mt-0.5">NIS: -</span>
                              </div>
                            </td>
                            {/* H (Hadir dikamar) */}
                            <td className="py-1.5 px-1.5 text-center">
                              <button
                                type="button"
                                onClick={() => {
                                  const newArr = [...selectedSantrisTidur];
                                  newArr[index].status = 'Hadir dikamar';
                                  setSelectedSantrisTidur(newArr);
                                }}
                                className={`w-8 h-8 rounded-full flex items-center justify-center font-black text-xs transition-all active:scale-90 cursor-pointer ${
                                  item.status === 'Hadir dikamar'
                                    ? 'bg-emerald-500 text-white shadow-xs border-2 border-emerald-400'
                                    : 'bg-white text-emerald-600 border border-slate-200 hover:border-emerald-300 hover:bg-emerald-50/10'
                                }`}
                                title="Hadir di kamar"
                              >
                                H
                              </button>
                            </td>
                            {/* S (Sakit) */}
                            <td className="py-1.5 px-1.5 text-center">
                              <button
                                type="button"
                                onClick={() => {
                                  const newArr = [...selectedSantrisTidur];
                                  newArr[index].status = 'Sakit';
                                  setSelectedSantrisTidur(newArr);
                                }}
                                className={`w-8 h-8 rounded-full flex items-center justify-center font-black text-xs transition-all active:scale-90 cursor-pointer ${
                                  item.status === 'Sakit'
                                    ? 'bg-amber-400 text-white shadow-xs border-2 border-amber-300'
                                    : 'bg-white text-amber-500 border border-slate-200 hover:border-amber-300 hover:bg-amber-50/10'
                                }`}
                                title="Sakit"
                              >
                                S
                              </button>
                            </td>
                            {/* I (Pulang / Izin) */}
                            <td className="py-1.5 px-1.5 text-center">
                              <button
                                type="button"
                                onClick={() => {
                                  const newArr = [...selectedSantrisTidur];
                                  newArr[index].status = 'Pulang';
                                  setSelectedSantrisTidur(newArr);
                                }}
                                className={`w-8 h-8 rounded-full flex items-center justify-center font-black text-xs transition-all active:scale-90 cursor-pointer ${
                                  item.status === 'Pulang'
                                    ? 'bg-slate-400 text-white shadow-xs border-2 border-slate-300'
                                    : 'bg-white text-slate-500 border border-slate-200 hover:border-slate-300 hover:bg-slate-50/10'
                                }`}
                                title="Pulang / Izin"
                              >
                                I
                              </button>
                            </td>
                            {/* A (Tidak ada dikamar) */}
                            <td className="py-1.5 px-1.5 text-center">
                              <button
                                type="button"
                                onClick={() => {
                                  const newArr = [...selectedSantrisTidur];
                                  newArr[index].status = 'Tidak ada dikamar';
                                  setSelectedSantrisTidur(newArr);
                                }}
                                className={`w-8 h-8 rounded-full flex items-center justify-center font-black text-xs transition-all active:scale-90 cursor-pointer ${
                                  item.status === 'Tidak ada dikamar'
                                    ? 'bg-rose-500 text-white shadow-xs border-2 border-rose-400'
                                    : 'bg-white text-rose-500 border border-slate-200 hover:border-rose-300 hover:bg-rose-50/10'
                                }`}
                                title="Tidak ada di kamar"
                              >
                                A
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <button
                    type="submit"
                    className="mt-4 w-full py-2.5 rounded-lg bg-[#0f766e] hover:bg-teal-700 text-white font-black text-xs uppercase tracking-wider transition-all active:scale-[0.98] shadow-xs border-b-2 border-teal-800 cursor-pointer"
                  >
                    Kirim Absensi Tidur Santri
                  </button>
                </form>
              )}



              <div className="mt-10 border-t border-dashed border-slate-200 pt-6 font-sans">
                <h3 className="text-sm font-extrabold text-slate-700 uppercase tracking-wider mb-4 flex gap-1.5 items-center"><span>📜</span> Riwayat Laporan Tidur (Hari Ini)</h3>
                {absensiTidurList.filter(r => r.musyrifId === currentUser.id && r.tanggal === `${new Date().getFullYear()}-${String(new Date().getMonth()+1).padStart(2, '0')}-${String(new Date().getDate()).padStart(2, '0')}`).length === 0 ? (
                  <div className="text-center py-5 text-xs text-slate-400 font-bold bg-slate-50 rounded-xl border border-slate-100 border-dashed">Belum ada data tidur yang disubmit hari ini.</div>
                ) : (
                  <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
                    <div className="overflow-x-auto max-h-[385px] overflow-y-auto">
                      <table className="w-full text-left text-[11px] border-collapse min-w-[700px]">
                        <thead>
                          <tr className="bg-teal-500/10 text-teal-800 font-extrabold uppercase text-[10px] border-b border-teal-500/20 sticky top-0 bg-teal-50/95 backdrop-blur-xs z-10">
                            <th className="py-3 px-4 text-center w-12">No</th>
                            <th className="py-3 px-4 text-left">Nama Santri</th>
                            <th className="py-3 px-4">Hari, Tanggal</th>
                            <th className="py-3 px-4 font-mono">Waktu / Jam</th>
                            <th className="py-3 px-4">Asrama</th>
                            <th className="py-3 px-4">Kamar</th>
                            <th className="py-3 px-4">Musyrif</th>
                            <th className="py-3 px-4">Absen</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 font-bold text-slate-700">
                          {absensiTidurList
                            .filter(r => r.musyrifId === currentUser.id && r.tanggal === `${new Date().getFullYear()}-${String(new Date().getMonth()+1).padStart(2, '0')}-${String(new Date().getDate()).padStart(2, '0')}`)
                            .sort((a, b) => a.santriName.localeCompare(b.santriName))
                            .map((r, idx) => {
                              const musyrifName = musyrifs?.find(m => m.id === r.musyrifId)?.name || currentUser.name;
                              return (
                                <tr key={r.id} className="hover:bg-teal-50/20 transition">
                                  <td className="py-3 px-4 text-center text-slate-400 font-mono">{idx + 1}</td>
                                  <td className="py-3 px-4 text-slate-900 font-extrabold max-w-[150px] truncate" title={r.santriName}>
                                    {r.santriName}
                                  </td>
                                  <td className="py-3 px-4 text-slate-700">
                                    <span className="font-extrabold text-[#0f766e]">{r.hari}</span>, {r.tanggal}
                                  </td>
                                  <td className="py-3 px-4 font-mono text-[10px] text-slate-500">{r.waktu} WIB</td>
                                  <td className="py-3 px-4 text-slate-600">{r.asrama}</td>
                                  <td className="py-3 px-4">
                                    <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded text-[10px] font-mono">{r.kamar}</span>
                                  </td>
                                  <td className="py-3 px-4 text-slate-600 text-xs font-medium">{musyrifName}</td>
                                  <td className="py-3 px-4">
                                    <span className={`inline-block text-[9px] uppercase font-extrabold px-1.5 py-0.5 rounded ${
                                      r.status === 'Hadir' || r.status === 'Hadir dikamar' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                                      r.status === 'Pulang' ? 'bg-sky-50 text-sky-700 border border-sky-200' :
                                      r.status === 'Sakit' ? 'bg-amber-50 text-amber-700 border border-amber-200' :
                                      'bg-rose-50 text-rose-700 border border-rose-200'
                                    }`}>
                                      {r.status}
                                    </span>
                                  </td>
                                </tr>
                              );
                            })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
          ) : (
            /* Column 1: Form Absensi Mutholaah Santri & Riwayat (xl:col-span-12) */
            <div className="xl:col-span-12 bg-white/90 backdrop-blur-md p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-sm space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-3">
                <div>
                  <h3 className="text-lg font-black text-[#c2410c] tracking-tight flex items-center gap-2 uppercase">
                    <span>📖</span> FORM ABSENSI MUTHOLAAH SANTRI
                  </h3>
                  <p className="text-[11px] text-slate-500 font-bold mt-1">
                    Asrama {activeAsrama} • Kamar {activeKamar}
                  </p>
                </div>
                
                {/* SELECT KAMAR SEBAGAI FITUR UTAMA PADA ABSENSI & SET SEMUA HADIR */}
                <div className="flex flex-wrap items-center gap-2">
                  <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 px-3 py-2 rounded-xl shadow-xs">
                    <label htmlFor="kamar-mutholaah-select" className="text-xs font-bold text-slate-600 whitespace-nowrap">Pilih Kamar:</label>
                    <select
                      id="kamar-mutholaah-select"
                      value={activeKamar}
                      onChange={(e) => setSelectedKamar(e.target.value)}
                      className="bg-white border border-slate-300 rounded-lg px-2.5 py-1 text-xs font-black text-slate-700 outline-none focus:ring-2 focus:ring-amber-500 cursor-pointer"
                    >
                      {finalRooms.map(room => (
                        <option key={room} value={room}>
                          {room}
                        </option>
                      ))}
                    </select>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedSantrisMutholaah(prev => prev.map(item => ({ ...item, status: 'Hadir Mutholaah' })));
                    }}
                    className="bg-[#c2410c] hover:bg-amber-800 text-white font-black text-xs px-3.5 py-2 rounded-xl transition shadow-xs flex items-center gap-1.5 active:scale-95 cursor-pointer uppercase tracking-wide"
                  >
                    <Check className="w-4 h-4" /> SET SEMUA HADIR
                  </button>
                </div>
              </div>

              <p className="text-xs text-slate-500 font-medium">
                Sistem absensi Muthola'ah (belajar malam) santri. Harap pastikan setiap santri tertib belajar.
              </p>

              {/* DAFTAR SANTRI BADGES HEADER */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-slate-50/80 p-3 rounded-xl border border-slate-100">
                <span className="text-xs font-black text-slate-700 uppercase tracking-wide">
                  Daftar Santri ({selectedSantrisMutholaah.length})
                </span>
                <div className="flex flex-wrap items-center gap-1.5 text-[11px] font-extrabold">
                  <span className="bg-emerald-100 text-emerald-800 px-2.5 py-0.5 rounded-md border border-emerald-200">
                    H = Hadir ({selectedSantrisMutholaah.filter(s => s.status === 'Hadir Mutholaah' || s.status === 'Hadir').length})
                  </span>
                  <span className="bg-amber-100 text-amber-800 px-2.5 py-0.5 rounded-md border border-amber-200">
                    S = Sakit ({selectedSantrisMutholaah.filter(s => s.status === 'Sakit').length})
                  </span>
                  <span className="bg-slate-100 text-slate-700 px-2.5 py-0.5 rounded-md border border-slate-200">
                    I = Izin ({selectedSantrisMutholaah.filter(s => s.status === 'Pulang' || s.status === 'Izin').length})
                  </span>
                  <span className="bg-rose-100 text-rose-800 px-2.5 py-0.5 rounded-md border border-rose-200">
                    A = Alpha ({selectedSantrisMutholaah.filter(s => s.status === 'Tidak Hadir/Alpha' || s.status === 'Tidak ada dikamar').length})
                  </span>
                </div>
              </div>
              
              {selectedSantrisMutholaah.length === 0 ? (
                <div className="text-sm text-rose-600 bg-rose-50 p-4 rounded-xl font-medium border border-rose-200 text-center">
                  Belum ada santri aktif yang terdaftar di kamar ini. Silakan tambahkan santri menggunakan menu "Kelola Data Santri".
                </div>
              ) : (
                <form onSubmit={handleMutholaahFormSubmit} className="space-y-5">
                  <div className="overflow-x-auto border border-slate-200 rounded-xl bg-white shadow-xs">
                    <table className="w-full text-left border-collapse min-w-[500px]">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-200 text-slate-700 font-extrabold text-[10px] uppercase tracking-wider">
                          <th className="py-2 px-3 text-center w-12">NO</th>
                          <th className="py-2 px-3">NAMA SANTRI</th>
                          <th className="py-2 px-3 text-center">STATUS ABSENSI</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {selectedSantrisMutholaah.map((item, index) => {
                          const isHadir = item.status === 'Hadir Mutholaah' || item.status === 'Hadir';
                          const isSakit = item.status === 'Sakit';
                          const isIzin = item.status === 'Pulang' || item.status === 'Izin';
                          const isAlpha = item.status === 'Tidak Hadir/Alpha' || item.status === 'Tidak ada dikamar';

                          return (
                            <tr key={item.santri.id} className="hover:bg-amber-50/10 transition-colors">
                              <td className="py-2 px-3 text-xs font-bold text-slate-400 text-center">{index + 1}</td>
                              <td className="py-2 px-3">
                                <div className="flex flex-col">
                                  <span className="font-extrabold text-slate-800 text-xs tracking-tight">{item.santri.name}</span>
                                  <div className="flex items-center gap-2 mt-0.5">
                                    <span className="text-[9px] font-mono text-slate-400 font-bold">NIS: {item.santri.nis || (1000 + index + 1)}</span>
                                    <span className={`text-[8px] font-black px-1.5 py-0.5 rounded uppercase tracking-wider ${
                                      isHadir ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' :
                                      isSakit ? 'bg-amber-100 text-amber-800 border border-amber-200' :
                                      isIzin ? 'bg-slate-100 text-slate-700 border border-slate-200' :
                                      'bg-rose-100 text-rose-800 border border-rose-200'
                                    }`}>
                                      {isHadir ? 'HADIR' : isSakit ? 'SAKIT' : isIzin ? 'IZIN' : 'ALPHA'}
                                    </span>
                                  </div>
                                </div>
                              </td>
                              <td className="py-2 px-3">
                                <div className="flex items-center justify-center gap-1.5">
                                  {/* H Button */}
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const newArr = [...selectedSantrisMutholaah];
                                      newArr[index].status = 'Hadir Mutholaah';
                                      setSelectedSantrisMutholaah(newArr);
                                    }}
                                    className={`w-8 h-8 rounded-full flex items-center justify-center font-black text-xs transition-all active:scale-90 cursor-pointer ${
                                      isHadir
                                        ? 'bg-emerald-600 text-white shadow-xs border-2 border-emerald-500'
                                        : 'bg-white text-emerald-600 border border-slate-200 hover:border-emerald-400 hover:bg-emerald-50'
                                    }`}
                                    title="Hadir Mutholaah"
                                  >
                                    H
                                  </button>
                                  {/* S Button */}
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const newArr = [...selectedSantrisMutholaah];
                                      newArr[index].status = 'Sakit';
                                      setSelectedSantrisMutholaah(newArr);
                                    }}
                                    className={`w-8 h-8 rounded-full flex items-center justify-center font-black text-xs transition-all active:scale-90 cursor-pointer ${
                                      isSakit
                                        ? 'bg-amber-500 text-white shadow-xs border-2 border-amber-400'
                                        : 'bg-white text-amber-600 border border-slate-200 hover:border-amber-400 hover:bg-amber-50'
                                    }`}
                                    title="Sakit"
                                  >
                                    S
                                  </button>
                                  {/* I Button */}
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const newArr = [...selectedSantrisMutholaah];
                                      newArr[index].status = 'Pulang';
                                      setSelectedSantrisMutholaah(newArr);
                                    }}
                                    className={`w-8 h-8 rounded-full flex items-center justify-center font-black text-xs transition-all active:scale-90 cursor-pointer ${
                                      isIzin
                                        ? 'bg-slate-600 text-white shadow-xs border-2 border-slate-500'
                                        : 'bg-white text-slate-600 border border-slate-200 hover:border-slate-400 hover:bg-slate-50'
                                    }`}
                                    title="Pulang / Izin"
                                  >
                                    I
                                  </button>
                                  {/* A Button */}
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const newArr = [...selectedSantrisMutholaah];
                                      newArr[index].status = 'Tidak Hadir/Alpha';
                                      setSelectedSantrisMutholaah(newArr);
                                    }}
                                    className={`w-8 h-8 rounded-full flex items-center justify-center font-black text-xs transition-all active:scale-90 cursor-pointer ${
                                      isAlpha
                                        ? 'bg-rose-600 text-white shadow-xs border-2 border-rose-500'
                                        : 'bg-white text-rose-600 border border-slate-200 hover:border-rose-400 hover:bg-rose-50'
                                    }`}
                                    title="Tidak Hadir / Alpha"
                                  >
                                    A
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>

                  {/* CATATAN TAMBAHAN (OPSIONAL) */}
                  <div className="space-y-1 pt-1.5">
                    <label className="text-[10px] font-black text-slate-700 uppercase tracking-wide">
                      Catatan Tambahan (Opsional)
                    </label>
                    <textarea
                      value={mutholaahCatatan}
                      onChange={(e) => setMutholaahCatatan(e.target.value)}
                      placeholder="Tuliskan catatan khusus atau keterangan mengenai absensi..."
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-xs font-medium focus:bg-white focus:ring-2 focus:ring-amber-500 outline-none h-16 resize-none transition shadow-2xs"
                    />
                  </div>

                  {/* KIRIM ABSENSI MUTHOLAAH SANTRI BUTTON */}
                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-lg bg-[#c2410c] hover:bg-amber-800 text-white font-black text-xs uppercase tracking-wider transition-all active:scale-[0.98] shadow-xs border-b-2 border-amber-900 cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    KIRIM ABSENSI MUTHOLAAH SANTRI
                  </button>
                </form>
              )}



              {/* RIWAYAT LAPORAN MUTHOLA'AH (HARI INI) */}
              <div className="mt-10 border-t border-dashed border-slate-200 pt-6 font-sans space-y-4">
                <h3 className="text-xs font-extrabold text-slate-800 uppercase tracking-wider flex gap-2 items-center">
                  <span>📄</span> RIWAYAT LAPORAN MUTHOLA'AH (HARI INI)
                </h3>
                {absensiMutholaahList.filter(r => r.tanggal === `${new Date().getFullYear()}-${String(new Date().getMonth()+1).padStart(2, '0')}-${String(new Date().getDate()).padStart(2, '0')}`).length === 0 ? (
                  <div className="text-center py-8 text-xs text-slate-400 font-bold bg-slate-50/70 rounded-2xl border border-slate-100 border-dashed">
                    Belum ada riwayat laporan muthola'ah hari ini.
                  </div>
                ) : (
                  <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
                    <div className="overflow-x-auto max-h-[385px] overflow-y-auto">
                      <table className="w-full text-left text-[11px] border-collapse min-w-[750px]">
                        <thead>
                          <tr className="bg-amber-500/10 text-amber-900 font-extrabold uppercase text-[10px] border-b border-amber-500/20 sticky top-0 bg-amber-50/95 backdrop-blur-xs z-10">
                            <th className="py-3 px-3 text-center w-10">NO</th>
                            <th className="py-3 px-3 text-left">NAMA SANTRI</th>
                            <th className="py-3 px-3">HARI, TANGGAL</th>
                            <th className="py-3 px-3 font-mono">WAKTU / JAM</th>
                            <th className="py-3 px-3">ASRAMA</th>
                            <th className="py-3 px-3">KAMAR</th>
                            <th className="py-3 px-3">MUSYRIF</th>
                            <th className="py-3 px-3 text-center">ABSEN</th>
                            <th className="py-3 px-3">CATATAN</th>
                            <th className="py-3 px-3 text-center">AKSI</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 font-bold text-slate-700">
                          {absensiMutholaahList
                            .filter(r => r.tanggal === `${new Date().getFullYear()}-${String(new Date().getMonth()+1).padStart(2, '0')}-${String(new Date().getDate()).padStart(2, '0')}`)
                            .sort((a, b) => a.santriName.localeCompare(b.santriName))
                            .map((r, idx) => {
                              const musyrifName = musyrifs?.find(m => m.id === r.musyrifId)?.name || currentUser.name;
                              return (
                                <tr key={r.id} className="hover:bg-amber-50/20 transition">
                                  <td className="py-3 px-3 text-center text-slate-400 font-mono">{idx + 1}</td>
                                  <td className="py-3 px-3 text-slate-900 font-extrabold max-w-[140px] truncate" title={r.santriName}>
                                    {r.santriName}
                                  </td>
                                  <td className="py-3 px-3 text-slate-700">
                                    <span className="font-extrabold text-[#c2410c]">{r.hari}</span>, {r.tanggal}
                                  </td>
                                  <td className="py-3 px-3 font-mono text-[10px] text-slate-500">{r.waktu} WIB</td>
                                  <td className="py-3 px-3 text-slate-600">{r.asrama}</td>
                                  <td className="py-3 px-3">
                                    <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded text-[10px] font-mono">{r.kamar}</span>
                                  </td>
                                  <td className="py-3 px-3 text-slate-600 text-xs font-medium">{musyrifName}</td>
                                  <td className="py-3 px-3 text-center">
                                    <span className={`inline-block text-[9px] uppercase font-extrabold px-2 py-0.5 rounded ${
                                      r.status === 'Hadir' || r.status === 'Hadir Mutholaah' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                                      r.status === 'Pulang' ? 'bg-sky-50 text-sky-700 border border-sky-200' :
                                      r.status === 'Sakit' ? 'bg-amber-50 text-amber-700 border border-amber-200' :
                                      'bg-rose-50 text-rose-700 border border-rose-200'
                                    }`}>
                                      {r.status === 'Hadir Mutholaah' ? 'HADIR' : r.status === 'Pulang' ? 'IZIN' : r.status === 'Tidak Hadir/Alpha' ? 'ALPHA' : r.status.toUpperCase()}
                                    </span>
                                  </td>
                                  <td className="py-3 px-3 text-slate-500 text-[10px] italic max-w-[120px] truncate" title={r.catatan || '-'}>
                                    {r.catatan || '-'}
                                  </td>
                                  <td className="py-3 px-3 text-center">
                                    <button
                                      type="button"
                                      onClick={() => {
                                        if (window.confirm('Hapus laporan mutholaah ini?')) {
                                          deleteAbsensiMutholaah(r.id);
                                        }
                                      }}
                                      className="p-1 text-rose-500 hover:bg-rose-50 rounded-lg transition"
                                      title="Hapus"
                                    >
                                      <Trash2 className="w-4 h-4" />
                                    </button>
                                  </td>
                                </tr>
                              );
                            })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      
      {/* 2. RIWAYAT TAB CONTENT (MOBILE ONLY) */}
      <div className={`${mobileActiveTab === 'riwayat' ? 'block' : 'hidden'} sm:hidden space-y-4 px-2`}>
        <div className="bg-white rounded-3xl border border-slate-100 shadow-sm p-5">
          <h2 className="text-sm font-black text-slate-800 uppercase flex items-center gap-2 mb-4">
            <History className="w-5 h-5 text-teal-600" /> Riwayat Laporan Saya
          </h2>
          <div className="space-y-3">
            {myReports.length > 0 ? myReports.slice(0, 15).map((r) => (
              <div key={r.id} className="p-3 bg-slate-50 rounded-2xl border border-slate-100 flex gap-3">
                <div className="w-12 h-12 rounded-xl overflow-hidden shrink-0 bg-slate-200">
                  <img src={r.foto} className="w-full h-full object-cover" alt="Laporan" />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-[11px] font-black text-slate-800 truncate">{r.kegiatan}</h4>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-[9px] font-bold text-slate-500 uppercase">{r.hari}, {r.waktu}</span>
                    <span className={`text-[8px] font-black px-1.5 py-0.5 rounded ${
                      r.status === 'Hadir' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
                    }`}>
                      {r.status.toUpperCase()}
                    </span>
                  </div>
                </div>
              </div>
            )) : (
              <p className="text-center py-10 text-xs font-bold text-slate-400">Belum ada riwayat laporan</p>
            )}
          </div>
        </div>
      </div>

      {/* 3. PROFIL TAB CONTENT (MOBILE ONLY) */}
      <div className={`${mobileActiveTab === 'profil' ? 'block' : 'hidden'} sm:hidden space-y-4 px-2 pb-10`}>
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-100 shadow-sm space-y-4">
          <div className="flex flex-col items-center text-center space-y-3">
             <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-teal-500 to-emerald-600 flex items-center justify-center text-white text-3xl font-black shadow-lg">
                {currentUser.name.charAt(0)}
             </div>
             <div>
                <h3 className="text-lg font-black text-slate-800">{currentUser.name}</h3>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">{currentUser.role}</p>
             </div>
          </div>
          
          <div className="grid grid-cols-2 gap-3">
             <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
                <p className="text-[10px] font-black text-slate-400 uppercase">Asrama</p>
                <p className="text-sm font-black text-slate-800 mt-1">{activeAsrama}</p>
             </div>
             <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
                <p className="text-[10px] font-black text-slate-400 uppercase">Kamar</p>
                <p className="text-sm font-black text-slate-800 mt-1">{activeKamar}</p>
             </div>
          </div>

          <div className="space-y-3 pt-2">
             <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100">
                <div className="flex items-center gap-3">
                   <div className={`w-2 h-2 rounded-full ${isCloudSynced ? 'bg-emerald-500' : 'bg-rose-500'}`}></div>
                   <span className="text-xs font-bold text-slate-700">Status Basis Data</span>
                </div>
                <span className={`text-[10px] font-black uppercase ${isCloudSynced ? 'text-emerald-600' : 'text-rose-600'}`}>
                   {isCloudSynced ? 'Sinkron' : 'Lokal'}
                </span>
             </div>
             
             <button 
               onClick={logout}
               className="w-full py-4 bg-rose-50 text-rose-600 rounded-2xl font-black text-sm border border-rose-100 hover:bg-rose-100 transition flex items-center justify-center gap-2"
             >
               <X className="w-4 h-4" /> Keluar dari Aplikasi
             </button>
          </div>
        </div>
      </div>

      {/* Lightbox / Expanded Photo Preview modal */}
      {previewOpen && (
        <div 
          className="fixed inset-0 bg-black/75 backdrop-blur-xs flex items-center justify-center z-50 p-4"
          onClick={() => setPreviewOpen(null)}
        >
          <div className="bg-white rounded-2xl p-3 max-w-md w-full relative border border-slate-150 shadow-2xl animate-scale-up" onClick={e => e.stopPropagation()}>
            <button
              id="close-lightbox"
              className="absolute -top-3 -right-3 bg-slate-800 hover:bg-slate-900 text-white w-7 h-7 rounded-full flex items-center justify-center leading-none text-xs shadow-lg transition"
              onClick={() => setPreviewOpen(null)}
            >
              ✕
            </button>
            <div className="h-64 sm:h-80 w-full overflow-hidden rounded-xl border border-slate-100 bg-slate-100">
              <img src={previewOpen} alt="Bukti Absensi Full" className="w-full h-full object-contain referrerPolicy" referrerPolicy="no-referrer" />
            </div>
            <div className="py-2 text-center">
              <p className="text-[10px] font-mono text-slate-400 font-bold uppercase tracking-wider animate-pulse">Bukti Foto Dokumentasi Kegiatan Musyrif</p>
            </div>
          </div>
        </div>
      )}

      {confirmModal && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity" onClick={() => setConfirmModal(null)} />
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xl max-w-md w-full overflow-hidden relative z-10 p-4 sm:p-5 space-y-3">
            <div className="flex items-start gap-3">
              <div className={`p-2 rounded-full shrink-0 ${confirmModal.danger ? 'bg-rose-50 text-rose-600' : 'bg-teal-50 text-teal-600'}`}>
                <AlertCircle size={24} />
              </div>
              <div className="space-y-1.5 flex-1">
                <h3 className="text-sm font-black text-slate-800 tracking-wide uppercase">{confirmModal.title}</h3>
                <p className="text-xs text-slate-500 font-bold leading-relaxed whitespace-pre-wrap">{confirmModal.message}</p>
              </div>
            </div>
            <div className="flex justify-end gap-2.5 pt-2">
              {!confirmModal.isAlert && (
                <button
                  type="button"
                  onClick={() => setConfirmModal(null)}
                  className="px-4 py-2 text-xs font-bold text-slate-500 hover:text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl cursor-pointer transition"
                >
                  Batal
                </button>
              )}
              <button
                type="button"
                onClick={async () => {
                  const onConfirm = confirmModal.onConfirm;
                  setConfirmModal(null);
                  if (onConfirm) {
                    await onConfirm();
                  }
                }}
                className={`px-4 py-2 text-xs font-black text-white rounded-xl cursor-pointer transition border-b-2 ${
                  confirmModal.danger
                    ? 'bg-rose-600 hover:bg-rose-700 border-rose-800'
                    : 'bg-teal-600 hover:bg-teal-700 border-teal-800'
                }`}
              >
                {confirmModal.isAlert ? 'OK' : 'Yakin, Lanjutkan'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Navigation Bar for Mobile */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-100 flex justify-around items-center py-2 px-4 sm:hidden z-50 pb-safe shadow-[0_-4px_10px_rgba(0,0,0,0.03)]">
        <button 
          onClick={() => {
            setMobileActiveTab('dashboard');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className={`flex flex-col items-center gap-1 transition-all py-1 cursor-pointer ${mobileActiveTab === 'dashboard' ? 'text-[#0B4A3F]' : 'text-[#94A3B8]'}`}
        >
          <Home size={22} strokeWidth={mobileActiveTab === 'dashboard' ? 2.5 : 2} />
          <span className={`text-[10px] tracking-tight ${mobileActiveTab === 'dashboard' ? 'font-black text-[#0B4A3F]' : 'font-bold text-[#94A3B8]'}`}>Dashboard</span>
        </button>
        <button 
          onClick={() => {
            setMobileActiveTab('riwayat');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className={`flex flex-col items-center gap-1 transition-all py-1 cursor-pointer ${mobileActiveTab === 'riwayat' ? 'text-[#0B4A3F]' : 'text-[#94A3B8]'}`}
        >
          <History size={22} strokeWidth={mobileActiveTab === 'riwayat' ? 2.5 : 2} />
          <span className={`text-[10px] tracking-tight ${mobileActiveTab === 'riwayat' ? 'font-black text-[#0B4A3F]' : 'font-bold text-[#94A3B8]'}`}>Riwayat</span>
        </button>
        <button 
          onClick={() => {
            setMobileActiveTab('profil');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className={`flex flex-col items-center gap-1 transition-all py-1 cursor-pointer ${mobileActiveTab === 'profil' ? 'text-[#0B4A3F]' : 'text-[#94A3B8]'}`}
        >
          <User size={22} strokeWidth={mobileActiveTab === 'profil' ? 2.5 : 2} />
          <span className={`text-[10px] tracking-tight ${mobileActiveTab === 'profil' ? 'font-black text-[#0B4A3F]' : 'font-bold text-[#94A3B8]'}`}>Profil</span>
        </button>
      </div>

    </div>
  );
};
