/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppStateProvider, useAppState } from './context/AppStateContext';
import { Login } from './components/Login';
import { MusyrifDashboard } from './components/MusyrifDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { BookOpen, ShieldCheck, UserCheck, Star } from 'lucide-react';

const AppContent: React.FC = () => {
  const { currentUser, loading, pondokSettings } = useAppState();

  // Show a gorgeous, custom load spinner aligned with Pondok branding
  if (loading) {
    return (
      <div className="min-h-screen bg-teal-50/20 flex flex-col justify-center items-center p-4">
        <div className="flex flex-col items-center gap-4">
          <div className="relative w-16 h-16">
            <div className="absolute inset-0 rounded-full border-4 border-teal-100 animate-pulse"></div>
            <div className="absolute inset-0 rounded-full border-4 border-t-teal-600 animate-spin"></div>
            <div className="absolute inset-0 flex items-center justify-center">
              <BookOpen className="w-6 h-6 text-teal-600" />
            </div>
          </div>
          <div className="text-center space-y-1">
            <h3 className="text-sm font-black text-slate-800 tracking-tight">Memuat Aplikasi</h3>
            <p className="text-[10px] text-slate-400 font-mono">ABSENSI MUSYRIF PP BAHRUL MAGHFIROH</p>
          </div>
        </div>
      </div>
    );
  }

  // Not logged in -> Show login
  if (!currentUser) {
    return <Login />;
  }

  const isUserAdmin = currentUser?.role === 'admin';
  const backgroundGradient = isUserAdmin 
    ? "min-h-screen bg-gradient-to-br from-slate-50 via-sky-50/40 to-teal-50/30 flex flex-col font-sans" 
    : "min-h-screen bg-gradient-to-br from-slate-50 via-emerald-50/40 to-indigo-50/30 flex flex-col font-sans";

  return (
    <div className={backgroundGradient}>
      {/* Main Workspace Frame */}
      {currentUser.role !== 'admin' ? (
        <div className="flex-1 w-full max-w-7xl mx-auto px-2 sm:px-4 py-2 sm:py-3 space-y-3">
          <main className="transition-all duration-300">
            <MusyrifDashboard />
          </main>
        </div>
      ) : (
        <main className="flex-1 w-full bg-slate-50 h-full">
          <AdminDashboard />
        </main>
      )}

      {/* Footer copyright */}
      <footer className="py-6 border-t border-slate-200/50 text-center text-xs text-slate-400 bg-white print:hidden">
        <div className="max-w-7xl mx-auto px-4 space-y-1">
          <p className="font-bold text-slate-500">© 2026 {pondokSettings.namaPondok}</p>
          <p className="text-[10px] font-mono leading-relaxed">Sistem Integrasi Laporan Absensi Musyrif Asrama • Hak Cipta Dilindungi Undang-Undang</p>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <AppStateProvider>
      <AppContent />
    </AppStateProvider>
  );
}
