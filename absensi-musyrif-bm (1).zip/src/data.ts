/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Musyrif, ActivitySchedule, AbsensiRecord, PondokSettings, Santri, AbsensiTidurRecord } from './types';

export const INITIAL_SANTRI_LIST: Santri[] = [
  { id: 's-1', name: 'M. Ali Fikri', nis: '1001', asrama: 'Al Hakim', kamar: 'Khondak', status: 'Reguler', isActive: true },
  { id: 's-2', name: 'Ahmad Raihan', nis: '1002', asrama: 'Al Hakim', kamar: 'Khondak', status: 'Reguler', isActive: true },
  { id: 's-3', name: 'Fikri Haikal', nis: '1003', asrama: 'Al Hakim', kamar: 'Khondak', status: 'Reguler', isActive: true },
  { id: 's-4', name: 'Badrus Sholeh', nis: '1004', asrama: 'Al Hakim', kamar: 'Al Hakim-1', status: 'Reguler', isActive: true },
  { id: 's-5', name: 'Muhammad Farhan', nis: '1005', asrama: 'Al Hakim', kamar: 'Al Hakim-1', status: 'Reguler', isActive: true },
  { id: 's-6', name: 'Zaidan Alwy', nis: '1006', asrama: 'Al Fattah', kamar: 'Al Fattah-1', status: 'Yatim', isActive: true },
  { id: 's-7', name: 'Rizky Ramadhan', nis: '1007', asrama: 'Al Karim', kamar: 'Al Karim-1', status: 'Piatu', isActive: true },
];

export const INITIAL_ABSENSI_TIDUR_DATA: AbsensiTidurRecord[] = [];

export const INITIAL_MUSYRIF_LIST: Musyrif[] = [
  {
    id: 'hakim-1',
    name: 'Ust Ali Mashuri',
    asrama: 'Al Hakim',
    kamar: 'Kamar 101',
    password: '1234',
    isActive: true,
    phoneNumber: '081234567890'
  },
  {
    id: 'hakim-2',
    name: 'Ahmad Mashuri',
    asrama: 'Al Hakim',
    kamar: 'Kamar 101',
    password: '1234',
    isActive: true,
    phoneNumber: '081234567891'
  },
  {
    id: 'fattah-1',
    name: 'Fatkhul Fahmi',
    asrama: 'Al Fattah',
    kamar: 'Kamar 102',
    password: '1234',
    isActive: true,
    phoneNumber: '081234567892'
  },
  {
    id: 'fattah-2',
    name: 'Ust Ridwan',
    asrama: 'Al Fattah',
    kamar: 'Kamar 102',
    password: '1234',
    isActive: true,
    phoneNumber: '081234567893'
  },
  {
    id: 'karim-1',
    name: 'Ust Zulfi',
    asrama: 'Al Karim',
    kamar: 'Kamar 103',
    password: '1234',
    isActive: true,
    phoneNumber: '081234567894'
  }
];

export const SCHEDULES: ActivitySchedule[] = [
  {
    id: 'act-1',
    title: 'Membangunkan Santri',
    time: '03:30-04:30',
    days: ['senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu', 'minggu'],
    icon: '⏰'
  },
  {
    id: 'act-2',
    title: 'Pendampingan Pengajian Subuh',
    time: '04:30-05:45',
    days: ['senin', 'selasa', 'rabu', 'kamis', 'sabtu', 'minggu'],
    icon: '⏰'
  },
  {
    id: 'act-3',
    title: 'Menggobraki Sekolah',
    time: '06:00-07:30',
    days: ['senin', 'selasa', 'rabu', 'kamis', 'sabtu'],
    icon: '⏰'
  },
  {
    id: 'act-4',
    title: 'Piket Kamar & Persiapan Jamaah Maghrib',
    time: '16:30-17:30',
    days: ['senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu', 'minggu'],
    icon: '⏰'
  },
  {
    id: 'act-5',
    title: 'Pendampingan Dalail',
    time: '18:00-19:30',
    days: ['senin'],
    icon: '⏰'
  },
  {
    id: 'act-6',
    title: 'Muthola\'ah',
    time: '19:30-20:30',
    days: ['selasa', 'rabu', 'sabtu', 'minggu'],
    icon: '⏰'
  },
  {
    id: 'act-7',
    title: 'Pendampingan Tawasulan',
    time: '21:00-23:30',
    days: ['kamis'],
    icon: '⏰'
  },
  {
    id: 'act-8',
    title: 'Menertibkan jam Tidur Malam',
    time: '21:30-22:30',
    days: ['senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu', 'minggu'],
    icon: '⏰'
  }
];

export const DEFAULT_PONDOK_SETTINGS: PondokSettings = {
  namaPondok: 'Ponpes Bahrul Maghfiroh',
  alamat: 'Jl. KH. Imam Syafi\'i No. 05, Genteng, Banyuwangi, Jawa Timur',
  pengasuh: 'KH. Muwafiq Amir',
  ketuaPondok: 'Ust. Hamdan Syafi\'i',
  logoUrl: 'https://absensi-musyrif-bm.vercel.app/logo.png',
  pengasuhTtdUrl: '',
  ketuaPondokTtdUrl: '',
  pengumuman: '📢 INFORMASI PENTING: Kepada segenap Musyrif Ponpes Bahrul Maghfiroh agar melampirkan foto bukti orisinil pada setiap laporan absensi. Evaluasi kedisiplinan dan rapor performa asrama akan dilaporkan kepada Romo KH. Muwafiq Amir setiap akhir pekan.',
  daftarKamar: [
    'Al Hakim-1', 'Al Hakim-2', 'Al Hakim-3',
    'Al Fattah-1', 'Al Fattah-2', 'Al Fattah-3', 'Al Fattah-4', 'Al Fattah-5',
    'Al Karim-1', 'Al Karim-2', 'Al Karim-3',
    'Khondak'
  ],
  schedules: SCHEDULES
};

// Generates high-fidelity mock reports for the last 5 days
// Dates: 2026-05-17 (Minggu), 2026-05-18 (Senin), 2026-05-19 (Selasa), 2026-05-20 (Rabu), 2026-05-21 (Kamis)
export const INITIAL_ABSENSI_DATA: AbsensiRecord[] = [
  {
    id: 'rec-1',
    waktu: '07:04',
    tanggal: '25/07/2026',
    hari: 'Sab',
    musyrifId: 'hakim-1',
    namaMusyrif: 'Ust Ali Mashuri',
    asrama: 'Al Hakim',
    kegiatan: 'Menertibkan berangkat sekolah Formal (Absen Musyrif)',
    status: 'Hadir',
    foto: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=300&auto=format&fit=crop&q=60',
    catatan: 'Seluruh santri sudah berangkat sekolah formal'
  },
  {
    id: 'rec-2',
    waktu: '07:04',
    tanggal: '25/07/2026',
    hari: 'Sab',
    musyrifId: 'hakim-1',
    namaMusyrif: 'Ust Ali Mashuri',
    asrama: 'Al Hakim',
    kegiatan: 'Menertibkan berangkat sekolah Formal (Absen Musyrif)',
    status: 'Hadir',
    foto: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=300&auto=format&fit=crop&q=60',
    catatan: 'Kondisi asrama rapi'
  },
  {
    id: 'rec-3',
    waktu: '21:07',
    tanggal: '24/07/2026',
    hari: 'Jum',
    musyrifId: 'fattah-1',
    namaMusyrif: 'Fatkhul Fahmi',
    asrama: 'Al Fattah',
    kegiatan: 'Membangunkan Mulahid dan membantu mengobrak i santri (Absen Mulahid)',
    status: 'Hadir',
    foto: 'https://images.unsplash.com/photo-1518495973542-4542c06a5843?w=300&auto=format&fit=crop&q=60',
    catatan: 'Santri telah dibangunkan tepat waktu'
  }
];
/*
  // --- Kamis, 21 Mei 2026 ---
  {
    id: 'rec-1',
    waktu: '03:45',
    tanggal: '2026-05-21',
    hari: 'Kamis',
    musyrifId: 'hakim-1',
    namaMusyrif: 'Ali Mashuri',
    asrama: 'Al Hakim',
    kegiatan: 'Membangunkan Santri ⏰ 03:30-04:30',
    status: 'Hadir',
    foto: 'https://images.unsplash.com/photo-1518495973542-4542c06a5843?w=300&auto=format&fit=crop&q=60',
    catatan: 'Santri asrama Al Hakim bangun tepat waktu'
  },
  {
    id: 'rec-2',
    waktu: '04:55',
    tanggal: '2026-05-21',
    hari: 'Kamis',
    musyrifId: 'hakim-1',
    namaMusyrif: 'Ali Mashuri',
    asrama: 'Al Hakim',
    kegiatan: 'Pendampingan Pengajian Subuh ⏰ 04:30-05:45',
    status: 'Hadir',
    foto: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=300&auto=format&fit=crop&q=60',
    catatan: 'Hadir mendampingi di barisan depan'
  },
  {
    id: 'rec-3',
    waktu: '03:40',
    tanggal: '2026-05-21',
    hari: 'Kamis',
    musyrifId: 'fattah-1',
    namaMusyrif: 'Fattahilah',
    asrama: 'Al Fattah',
    kegiatan: 'Membangunkan Santri ⏰ 03:30-04:30',
    status: 'Hadir',
    foto: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=300&auto=format&fit=crop&q=60',
    catatan: 'Laporan asrama Al Fattah kondusif'
  },
  {
    id: 'rec-4',
    waktu: '03:55',
    tanggal: '2026-05-21',
    hari: 'Kamis',
    musyrifId: 'karim-1',
    namaMusyrif: 'Bima Julian',
    asrama: 'Al Karim',
    kegiatan: 'Membangunkan Santri ⏰ 03:30-04:30',
    status: 'Hadir',
    foto: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=300&auto=format&fit=crop&q=60'
  },
  {
    id: 'rec-5',
    waktu: '04:50',
    tanggal: '2026-05-21',
    hari: 'Kamis',
    musyrifId: 'karim-1',
    namaMusyrif: 'Bima Julian',
    asrama: 'Al Karim',
    kegiatan: 'Pendampingan Pengajian Subuh ⏰ 04:30-05:45',
    status: 'Hadir',
    foto: 'https://images.unsplash.com/photo-1518495973542-4542c06a5843?w=300&auto=format&fit=crop&q=60'
  },
  {
    id: 'rec-6',
    waktu: '06:15',
    tanggal: '2026-05-21',
    hari: 'Kamis',
    musyrifId: 'hakim-2',
    namaMusyrif: 'Ali Zahid',
    asrama: 'Al Hakim',
    kegiatan: 'Menggobraki Sekolah ⏰ 06:00-07:30',
    status: 'Hadir',
    foto: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=300&auto=format&fit=crop&q=60',
    catatan: 'Santri sudah berangkat sekolah semua'
  },
  {
    id: 'rec-7',
    waktu: '06:10',
    tanggal: '2026-05-21',
    hari: 'Kamis',
    musyrifId: 'fattah-2',
    namaMusyrif: 'Brian Adi Waskito',
    asrama: 'Al Fattah',
    kegiatan: 'Menggobraki Sekolah ⏰ 06:00-07:30',
    status: 'Hadir',
    foto: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=300&auto=format&fit=crop&q=60'
  },
  
  // --- Rabu, 20 Mei 2026 ---
  {
    id: 'rec-8',
    waktu: '03:40',
    tanggal: '2026-05-20',
    hari: 'Rabu',
    musyrifId: 'hakim-1',
    namaMusyrif: 'Ali Mashuri',
    asrama: 'Al Hakim',
    kegiatan: 'Membangunkan Santri ⏰ 03:30-04:30',
    status: 'Hadir',
    foto: 'https://images.unsplash.com/photo-1518495973542-4542c06a5843?w=300&auto=format&fit=crop&q=60'
  },
  {
    id: 'rec-9',
    waktu: '04:40',
    tanggal: '2026-05-20',
    hari: 'Rabu',
    musyrifId: 'hakim-1',
    namaMusyrif: 'Ali Mashuri',
    asrama: 'Al Hakim',
    kegiatan: 'Pendampingan Pengajian Subuh ⏰ 04:30-05:45',
    status: 'Hadir',
    foto: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=300&auto=format&fit=crop&q=60'
  },
  {
    id: 'rec-10',
    waktu: '06:12',
    tanggal: '2026-05-20',
    hari: 'Rabu',
    musyrifId: 'hakim-1',
    namaMusyrif: 'Ali Mashuri',
    asrama: 'Al Hakim',
    kegiatan: 'Menggobraki Sekolah ⏰ 06:00-07:30',
    status: 'Hadir',
    foto: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=300&auto=format&fit=crop&q=60'
  },
  {
    id: 'rec-11',
    waktu: '19:40',
    tanggal: '2026-05-20',
    hari: 'Rabu',
    musyrifId: 'hakim-1',
    namaMusyrif: 'Ali Mashuri',
    asrama: 'Al Hakim',
    kegiatan: 'Muthola\'ah ⏰ 19:30-20:30',
    status: 'Hadir',
    foto: 'https://images.unsplash.com/photo-1518495973542-4542c06a5843?w=300&auto=format&fit=crop&q=60'
  },
  {
    id: 'rec-12',
    waktu: '03:50',
    tanggal: '2026-05-20',
    hari: 'Rabu',
    musyrifId: 'fattah-3',
    namaMusyrif: 'Babil Yasar Asrama',
    asrama: 'Al Fattah',
    kegiatan: 'Membangunkan Santri ⏰ 03:30-04:30',
    status: 'Izin',
    foto: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=300&auto=format&fit=crop&q=60',
    catatan: 'Sedang ada tugas kuliah di luar pondok'
  },
  {
    id: 'rec-13',
    waktu: '16:45',
    tanggal: '2026-05-20',
    hari: 'Rabu',
    musyrifId: 'karim-2',
    namaMusyrif: 'Irfan Khoirul Aziz',
    asrama: 'Al Karim',
    kegiatan: 'Piket Kamar & Persiapan Jamaah Maghrib ⏰ 16:30-17:30',
    status: 'Hadir',
    foto: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=300&auto=format&fit=crop&q=60'
  },

  // --- Selasa, 19 Mei 2026 ---
  {
    id: 'rec-14',
    waktu: '03:40',
    tanggal: '2026-05-19',
    hari: 'Selasa',
    musyrifId: 'hakim-2',
    namaMusyrif: 'Ali Zahid',
    asrama: 'Al Hakim',
    kegiatan: 'Membangunkan Santri ⏰ 03:30-04:30',
    status: 'Sakit',
    foto: 'https://images.unsplash.com/photo-1518495973542-4542c06a5843?w=300&auto=format&fit=crop&q=60',
    catatan: 'Kurang enak badan, digantikan oleh Ali Mashuri'
  },
  {
    id: 'rec-15',
    waktu: '21:45',
    tanggal: '2026-05-19',
    hari: 'Selasa',
    musyrifId: 'karim-3',
    namaMusyrif: 'Rizki Alfian',
    asrama: 'Al Karim',
    kegiatan: 'Menertibkan jam Tidur Malam ⏰ 21:30-22:30',
    status: 'Hadir',
    foto: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=300&auto=format&fit=crop&q=60'
  },

  // --- Senin, 18 Mei 2026 ---
  {
    id: 'rec-16',
    waktu: '18:10',
    tanggal: '2026-05-18',
    hari: 'Senin',
    musyrifId: 'fattah-4',
    namaMusyrif: 'Fahmi',
    asrama: 'Al Fattah',
    kegiatan: 'Pendampingan Dalail ⏰ 18:00-19:30',
    status: 'Hadir',
    foto: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=300&auto=format&fit=crop&q=60'
  },
  {
    id: 'rec-17',
    waktu: '21:35',
    tanggal: '2026-05-18',
    hari: 'Senin',
    musyrifId: 'fattah-5',
    namaMusyrif: 'Wawan Febi Asrama',
    asrama: 'Al Fattah',
    kegiatan: 'Menertibkan jam Tidur Malam ⏰ 21:30-22:30',
    status: 'Hadir',
    foto: 'https://images.unsplash.com/photo-1518495973542-4542c06a5843?w=300&auto=format&fit=crop&q=60'
  }
];
*/
