/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type AsramaName = 'Al Hakim' | 'Al Fattah' | 'Al Karim';

export interface Musyrif {
  id: string;
  name: string;
  asrama: AsramaName;
  kamar: string;
  password?: string;
  isActive: boolean;
  phoneNumber?: string;
}

export type StatusAbsensi = 'Hadir' | 'Sakit' | 'Izin';

export interface Santri {
  id: string;
  name: string;
  asrama: AsramaName;
  kamar: string;
  isActive: boolean;
  status?: string;
  nis?: string;
}

export type StatusAbsensiSantri = 'Hadir' | 'Pulang' | 'Sakit' | 'Tidak ada di kamar' | 'Hadir dikamar' | 'Tidak ada dikamar' | 'Hadir Mutholaah' | 'Tidak Hadir/Alpha';

export interface AbsensiTidurRecord {
  id: string;
  waktu: string;
  tanggal: string;
  hari: string;
  musyrifId: string;
  asrama: AsramaName;
  kamar: string;
  santriId: string;
  santriName: string;
  status: StatusAbsensiSantri;
  catatan?: string;
}

export interface AbsensiMutholaahRecord {
  id: string;
  waktu: string;
  tanggal: string;
  hari: string;
  musyrifId: string;
  asrama: AsramaName;
  kamar: string;
  santriId: string;
  santriName: string;
  status: StatusAbsensiSantri;
  catatan?: string;
}

export interface AbsensiRecord {
  id: string;
  waktu: string; // e.g., "04:45"
  tanggal: string; // e.g., "2026-05-21"
  hari: string; // e.g., "Kamis"
  musyrifId: string;
  namaMusyrif: string;
  asrama: AsramaName;
  kegiatan: string;
  status: StatusAbsensi;
  foto: string; // Base64 or url
  catatan?: string;
}

export interface ActivitySchedule {
  id: string;
  title: string;
  time: string; // e.g., "03:30-04:30"
  days: string[]; // ['senin', 'selasa', ...]
  icon?: string;
}

export interface PondokSettings {
  namaPondok: string;
  alamat: string;
  pengasuh: string;
  ketuaPondok: string;
  logoUrl: string; // Base64 or stock image URL
  pengumuman?: string; // Broadcast announcement to Musyrifs
  daftarKamar?: string[];
  schedules?: ActivitySchedule[]; // Master list of extra/custom room names
  pengasuhTtdUrl?: string;
  ketuaPondokTtdUrl?: string;
}

export interface ActiveUser {
  id: string;
  name: string;
  asrama?: AsramaName;
  kamar?: string;
  role: 'admin' | 'musyrif';
}
