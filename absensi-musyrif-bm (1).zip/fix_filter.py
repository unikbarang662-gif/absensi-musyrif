import re

with open('src/components/MusyrifDashboard.tsx', 'r') as f:
    content = f.read()

# Add jenisAbsensi state
if "const [jenisAbsensi, setJenisAbsensi]" not in content:
    content = content.replace("const [status, setStatus] = useState<StatusAbsensi>('Hadir');", "const [status, setStatus] = useState<StatusAbsensi>('Hadir');\n  const [jenisAbsensi, setJenisAbsensi] = useState<'musyrif' | 'mulahid'>('musyrif');")

if "const [jenisFilter, setJenisFilter]" not in content:
    content = content.replace("const [historyFilter, setHistoryFilter] = React.useState<'saya' | 'asrama' | 'semua'>('asrama');", "const [historyFilter, setHistoryFilter] = React.useState<'saya' | 'asrama' | 'semua'>('asrama');\n  const [jenisFilter, setJenisFilter] = useState<'semua' | 'musyrif' | 'mulahid'>('semua');")

with open('src/components/MusyrifDashboard.tsx', 'w') as f:
    f.write(content)
