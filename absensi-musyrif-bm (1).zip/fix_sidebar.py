import re

with open('src/components/AdminDashboard.tsx', 'r') as f:
    content = f.read()

bad_sidebar_pattern = r'<button\s*className="w-full flex items-center justify-between px-5 py-2\.5 transition cursor-pointer text-xs font-medium text-left text-slate-200 hover:bg-\[#0f766e\]"\s*>\s*<div className="flex items-center gap-3"><ClipboardCheck className="w-4 h-4" /> <span>Absensi Kegiatan Musyrif<\/span><\/div>'

good_sidebar_replacement = """<button
              onClick={() => { setExpandedZone('kegiatan'); setIsMobileMenuOpen(false); }}
              className={`w-full flex items-center justify-between px-5 py-2.5 transition cursor-pointer text-xs font-medium text-left ${expandedZone === 'kegiatan' ? 'bg-[#0f766e] text-white border-l-2 border-emerald-400' : 'text-slate-200 hover:bg-[#0f766e]'}`}
            >
               <div className="flex items-center gap-3"><ClipboardCheck className="w-4 h-4" /> <span>Absensi Kegiatan Musyrif</span></div>"""

content = re.sub(bad_sidebar_pattern, good_sidebar_replacement, content, flags=re.DOTALL)

with open('src/components/AdminDashboard.tsx', 'w') as f:
    f.write(content)
print("Fixed sidebar!")
