import re

with open('src/components/AdminDashboard.tsx', 'r') as f:
    content = f.read()

# Update Kegiatan Musyrif to set expandedZone to 'kegiatan_musyrif'
content = content.replace(
    "onClick={() => { setExpandedZone('kegiatan'); setIsMobileMenuOpen(false); }}\n              className={`w-full flex items-center justify-between px-5 py-2.5 transition cursor-pointer text-xs font-medium text-left ${expandedZone === 'kegiatan' ? 'bg-[#0f766e] text-white border-l-2 border-emerald-400' : 'text-slate-200 hover:bg-[#0f766e]'}`}\n            >\n               <div className=\"flex items-center gap-3\"><ClipboardCheck className=\"w-4 h-4\" /> <span>Absensi Kegiatan Musyrif</span></div>",
    "onClick={() => { setExpandedZone('kegiatan_musyrif'); setIsMobileMenuOpen(false); }}\n              className={`w-full flex items-center justify-between px-5 py-2.5 transition cursor-pointer text-xs font-medium text-left ${expandedZone === 'kegiatan_musyrif' ? 'bg-[#0f766e] text-white border-l-2 border-emerald-400' : 'text-slate-200 hover:bg-[#0f766e]'}`}\n            >\n               <div className=\"flex items-center gap-3\"><ClipboardCheck className=\"w-4 h-4\" /> <span>Absensi Kegiatan Musyrif</span></div>"
)

# Update text mapping for header
content = content.replace(
    "expandedZone === 'settings' ? '⚙️ Profil Lembaga' : ''}",
    "expandedZone === 'settings' ? '⚙️ Profil Lembaga' : \n               expandedZone === 'kegiatan_musyrif' ? '📋 Absensi Kegiatan Musyrif' : ''}"
)

with open('src/components/AdminDashboard.tsx', 'w') as f:
    f.write(content)
print("Updated sidebar links")
