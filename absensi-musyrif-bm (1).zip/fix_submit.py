import re

with open('src/components/MusyrifDashboard.tsx', 'r') as f:
    content = f.read()

submit_pattern = r'submitAbsensi\(\{\s*musyrifId: currentUser\.id,\s*namaMusyrif: currentUser\.name,\s*asrama: activeAsrama,\s*kegiatan: selectedKegiatan,\s*status,\s*foto: image64,\s*catatan: catatan\.trim\(\) \|\| undefined,\s*\}\);'
submit_replacement = """submitAbsensi({
      musyrifId: currentUser.id,
      namaMusyrif: currentUser.name,
      asrama: activeAsrama,
      kegiatan: `${selectedKegiatan} (Absen ${jenisAbsensi === 'musyrif' ? 'Musyrif' : 'Mulahid'})`,
      status,
      foto: image64,
      catatan: catatan.trim() || undefined,
    });"""

content = re.sub(submit_pattern, submit_replacement, content, flags=re.DOTALL)

with open('src/components/MusyrifDashboard.tsx', 'w') as f:
    f.write(content)
