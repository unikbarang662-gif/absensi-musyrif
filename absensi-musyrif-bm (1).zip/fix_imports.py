import re

with open('src/components/MusyrifDashboard.tsx', 'r') as f:
    content = f.read()

content = content.replace("import React, { useState, useEffect } from 'react';", "import React, { useState, useEffect } from 'react';\nimport { useAppState } from '../context/AppStateContext';\nimport { SCHEDULES } from '../data';\nimport { StatusAbsensi } from '../types';")

with open('src/components/MusyrifDashboard.tsx', 'w') as f:
    f.write(content)
